<!-- image -->

Based on the image provided, here is a description:

This is the official logo for the **City of Logan**.

The logo consists of:
*   A stylized, multi-colored floral or lotus-like symbol. The colors include dark blue, magenta, and yellow/orange.
*   The text "CITY OF" in a smaller, lighter-weight font, positioned above the word "LOGAN".
*   The name "**LOGAN**" in a large, bold, dark blue, sans-serif font.

There are no project names, budget figures, specific locations (other than the City of Logan itself), procurement indicators, or council decisions visible in this image. It is purely a brand identity logo.

## City Shape, Economic Transformation &amp; Transport Committee Meeting Minutes

Meeting #:

Date:

Time:

Location:

846

10 June 2026

9:00 am

Council Chambers

Level 3, Logan City Council Administration Centre

150 Wembley Road, Logan Central

Present:

Deputy Mayor, Councillor Bannan (Chairperson)

Councillor St Ledger (Deputy Chairperson) (left from 10:02 am to 10:05 am)

Mayor Raven

Councillor Bradley (left from 9:28 am to 9:32 am)

Councillor Lane (left from 9:59 am to 10:03 am)

Councillor Russell

Councillor Jackson

Councillor Hall

Councillor Frazer

Councillor Heremaia

Councillor Stemp

Councillor Willcocks

Councillor Murphy

In Attendance:

Chief Executive Officer -D Scott

Executive General Manager , Growth, Economy and Sustainability – D Hansen

Executive General Manager , Transport Services - D Reilly

Chief of Staff to the Mayor - B Hill

City Solicitor - C Watt

General Manager Development Assessment - J Bougoure

A/General Manager Transport Planning and Assets - C Bayer

Manager Planning Assessment and Technical Services - L Gleeson

Manager Transport and Infrastructure Planning - C McCanna

Corporate Meetings Coordinator - K Jack

Corporate Meetings Officer - L Crawford

Corporate Meetings Officer - G Winspear

A/Corporate Meetings Officer - C Giallourakis

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

## 1. Acknowledgement of Country

The Chairperson, Councillor Bannan, opened the meeting by acknowledging the Traditional Custodians of the land on which the meeting was gathered, including Elders past, present and emerging.

## 2. Welcome

The Chairperson, Councillor Bannan, welcomed attendees to the City Shape, Economic Transformation and Transport Committee and declared the meeting open at 9:00 am.

Councillor Bannan advised meeting attendees that the meeting was being webcast and audio recorded.

## 3. Attendances and Leaves of Absence

There were no Leaves of Absence recorded.

## 4. Confirmation of Previous Committee Meeting Minutes

| Moved    | Deputy Mayor Bannan   |
|----------|-----------------------|
| Seconded | Councillor Stemp      |

That the minutes of the City Infrastructure Committee meeting held on 12 May 2026, be confirmed.

|                      | For    |   Against  |   Abstain  |   Absent |
|----------------------|--------|------------|------------|----------|
| Mayor Raven          | X      |            |            |          |
| Councillor Bradley   | X      |            |            |          |
| Councillor Lane      | X      |            |            |          |
| Councillor Russell   | X      |            |            |          |
| Councillor St Ledger | X      |            |            |          |
| Councillor Jackson   | X      |            |            |          |
| Councillor Hall      | X      |            |            |          |
| Councillor Frazer    | X      |            |            |          |
| Councillor Heremaia  | X      |            |            |          |
| Deputy Mayor Bannan  | X      |            |            |          |
| Councillor Stemp     | X      |            |            |          |
| Councillor Willcocks | X      |            |            |          |
| Councillor Murphy    | X      |            |            |          |
| Results              | 13     |          0 |          0 |        0 |

Carried (13 to 0)

## 5. Declarations of Conflicts of Interest

There were no conflicts of interest declared.

## UNCONFIRMED

## 6. Committee Reports

## 6.1 COM/63/2023 -Proposed Variation Request and Reconfiguring a lot at School Road, Logan Reserve

Councillor Bradley left the meeting at 9:28 am.

Moved

Councillor Jackson

Seconded

Councillor Murphy

That the PowerPoint, as presented to the meeting in relation to Item 6.1 of the City Shape, Economic Transformation and Transport Committee meeting held on 10 June 2026, be tabled.

|                      | For    |   Against  |   Abstain  | Absent   |
|----------------------|--------|------------|------------|----------|
| Mayor Raven          | X      |            |            |          |
| Councillor Bradley   |        |            |            | X        |
| Councillor Lane      | X      |            |            |          |
| Councillor Russell   | X      |            |            |          |
| Councillor St Ledger | X      |            |            |          |
| Councillor Jackson   | X      |            |            |          |
| Councillor Hall      | X      |            |            |          |
| Councillor Frazer    | X      |            |            |          |
| Councillor Heremaia  | X      |            |            |          |
| Deputy Mayor Bannan  | X      |            |            |          |
| Councillor Stemp     | X      |            |            |          |
| Councillor Willcocks | X      |            |            |          |
| Councillor Murphy    | X      |            |            |          |
| Results              | 12     |          0 |          0 | 1        |

Carried (12 to 0)

| Moved    | Mayor Raven        |
|----------|--------------------|
| Seconded | Councillor Jackson |

That the development application COM/63/2023 for a Material Change of Use for a Variation Request to Vary the Effect of the Logan Planning Scheme 2015; and Reconfiguring a Lot (2 Lots Into 109 Lots, New Roads and Basin) at 99 School Road and 107 -113 School Road, Logan Reserve, otherwise described as Lot 23 SP348488 and Lot 24 SP348489, be approved, subject to the conditions detailed in Attachment 2 -Proposed Development Conditions.

|                      | For    | Against    | Abstain          | Absent           |
|----------------------|--------|------------|------------------|------------------|
| Mayor Raven          | X      |            |                  |                  |
| Councillor Bradley   |        |            |                  | X                |
| Councillor Lane      |        | X          |                  |                  |
| Councillor Russell   | X      |            |                  |                  |
| Councillor St Ledger | X      |            |                  |                  |
| Councillor Jackson   | X      |            |                  |                  |
| Councillor Hall      |        | X          |                  |                  |
| Councillor Frazer    | X      |            |                  |                  |
| Councillor Heremaia  |        | X          |                  |                  |
| Deputy Mayor Bannan  | X      |            |                  |                  |
| Councillor Stemp     | X      |            |                  |                  |
| Councillor Willcocks | X      |            |                  |                  |
| Councillor Murphy    | X      |            |                  |                  |
| Results              | 9      | 3          | 0                | 1                |
|                      |        |            | Carried (9 to 3) | Carried (9 to 3) |

Councillor Bradley returned to the meeting 9:32 am.

## 6.2 MCUI/44/2024 -Proposed Material Change of Use for a Place of Worship and Community Use at Logan Reserve Road

| Moved    | Councillor Murphy   |
|----------|---------------------|
| Seconded | Councillor Jackson  |

That the PowerPoint, as presented to the meeting in relation to Item 6.2 of the City Shape, Economic Transformation and Transport Committee meeting held on 10 June 2026, be tabled.

|                      | For    |   Against  |   Abstain  |   Absent |
|----------------------|--------|------------|------------|----------|
| Mayor Raven          | X      |            |            |          |
| Councillor Bradley   | X      |            |            |          |
| Councillor Lane      | X      |            |            |          |
| Councillor Russell   | X      |            |            |          |
| Councillor St Ledger | X      |            |            |          |
| Councillor Jackson   | X      |            |            |          |
| Councillor Hall      | X      |            |            |          |
| Councillor Frazer    | X      |            |            |          |
| Councillor Heremaia  | X      |            |            |          |
| Deputy Mayor Bannan  | X      |            |            |          |
| Councillor Stemp     | X      |            |            |          |
| Councillor Willcocks | X      |            |            |          |
| Councillor Murphy    | X      |            |            |          |
| Results              | 13     |          0 |          0 |        0 |

Carried (13 to 0)

| Moved    | Mayor Raven        |
|----------|--------------------|
| Seconded | Councillor Jackson |

That the development application MCUI/44/2024 for a Material Change of Use for a Place of Worship and Community Use at 283-293 Logan Reserve Road, Logan Reserve QLD 4133 otherwise described as Lot 1 RP 162124 be approved subject to the conditions detailed in Attachment 2 Proposed Development Conditions.

|                      | For    | Against    |   Abstain  |   Absent |
|----------------------|--------|------------|------------|----------|
| Mayor Raven          | X      |            |            |          |
| Councillor Bradley   |        | X          |            |          |
| Councillor Lane      | X      |            |            |          |
| Councillor Russell   | X      |            |            |          |
| Councillor St Ledger | X      |            |            |          |
| Councillor Jackson   | X      |            |            |          |
| Councillor Hall      |        | X          |            |          |
| Councillor Frazer    | X      |            |            |          |
| Councillor Heremaia  |        | X          |            |          |
| Deputy Mayor Bannan  | X      |            |            |          |
| Councillor Stemp     | X      |            |            |          |
| Councillor Willcocks | X      |            |            |          |
| Councillor Murphy    | X      |            |            |          |
| Results              | 10     | 3          |          0 |        0 |

Carried (10 to 3)

## 6.3 2027 -28 Federal Blackspot Program Submissions

Councillor Lane left the meeting at 9:59 am.

Councillor St Ledger left the meeting at 10:02 am.

| Moved    | Councillor Jackson   |
|----------|----------------------|
| Seconded | Councillor Stemp     |

That the projects nominated in the report titled 2027/28 Federal Blackspot Program Submissions, subject to project feasibility, be submitted for funding as part of the Federal Government's 2027/28 Black Spot Program.

|                      | For    |   Against  |   Abstain  | Absent   |
|----------------------|--------|------------|------------|----------|
| Mayor Raven          | X      |            |            |          |
| Councillor Bradley   | X      |            |            |          |
| Councillor Lane      |        |            |            | X        |
| Councillor Russell   | X      |            |            |          |
| Councillor St Ledger |        |            |            | X        |
| Councillor Jackson   | X      |            |            |          |
| Councillor Hall      | X      |            |            |          |
| Councillor Frazer    | X      |            |            |          |
| Councillor Heremaia  | X      |            |            |          |
| Deputy Mayor Bannan  | X      |            |            |          |
| Councillor Stemp     | X      |            |            |          |
| Councillor Willcocks | X      |            |            |          |
| Councillor Murphy    | X      |            |            |          |
| Results              | 11     |          0 |          0 | 2        |

Carried (11 to 0)

## 6.4 Local Roads Statement of Intent -Amendment to include Veresdale Scrub Road

Councillor Lane returned to the meeting at 10:03 am.

Councillor St Ledger returned to the meeting at 10:05 am.

| Moved    | Deputy Mayor Bannan   |
|----------|-----------------------|
| Seconded | Councillor Jackson    |

That Veresdale Scrub Road, Veresdale Scrub be included in the Local Roads Statement of Intent 2022 with ranking of Priority No. 2.

|                      | For    |   Against  |   Abstain  |   Absent |
|----------------------|--------|------------|------------|----------|
| Mayor Raven          | X      |            |            |          |
| Councillor Bradley   | X      |            |            |          |
| Councillor Lane      | X      |            |            |          |
| Councillor Russell   | X      |            |            |          |
| Councillor St Ledger | X      |            |            |          |
| Councillor Jackson   | X      |            |            |          |
| Councillor Hall      | X      |            |            |          |
| Councillor Frazer    | X      |            |            |          |
| Councillor Heremaia  | X      |            |            |          |
| Deputy Mayor Bannan  | X      |            |            |          |
| Councillor Stemp     | X      |            |            |          |
| Councillor Willcocks | X      |            |            |          |
| Councillor Murphy    | X      |            |            |          |
| Results              | 13     |          0 |          0 |        0 |

Carried (13 to 0)

## 6.5 Local Roads (Kerb and Channel) Statement of Intent (SOI) 2026

## Moved

Councillor Jackson

Seconded

Councillor St Ledger

1. That the Statement of Intent for Local Roads (Kerb and Channel), as detailed in this report at Table 1, be adopted as the basis for funding and programming of the Local Roads (Kerb and Channel) Program of Council's Capital Roadworks and Drainage Program.
2. That the projects in the Statement of Intent for Local Roads (Kerb and Channel), as detailed in this report at Table 1, be delivered in the prioritised order outlined.
3. That the General Manager Transport Planning and Assets be authorised to add, remove or reprioritise projects in the Statement of Intent for Local Roads (Kerb and Channel), as detailed in this report at Table 1, where there are notable changes to scoring or project viability relevant to the selection and prioritisation criteria outlined in this report.
4. That the General Manager Transport Delivery be authorised to amend the prioritised delivery order of projects in the Statement of Intent for Local Roads (Kerb and Channel), as detailed in this report at Table 1, where operational and construction efficiencies can be gained.
5. That the General Manager Transport Planning and Assets or General Manager Transport Delivery notify elected members in writing when projects are added or removed in accordance with clauses 3 and 4. If an elected member has concerns about the changes made, the relevant General Manager may be requested to prepare a report to the City Shape, Economic Transformation and Transport Committee for Council's consideration.

|                      | For    |   Against  |   Abstain  |   Absent |
|----------------------|--------|------------|------------|----------|
| Mayor Raven          | X      |            |            |          |
| Councillor Bradley   | X      |            |            |          |
| Councillor Lane      | X      |            |            |          |
| Councillor Russell   | X      |            |            |          |
| Councillor St Ledger | X      |            |            |          |
| Councillor Jackson   | X      |            |            |          |
| Councillor Hall      | X      |            |            |          |
| Councillor Frazer    | X      |            |            |          |
| Councillor Heremaia  | X      |            |            |          |
| Deputy Mayor Bannan  | X      |            |            |          |
| Councillor Stemp     | X      |            |            |          |
| Councillor Willcocks | X      |            |            |          |
| Councillor Murphy    | X      |            |            |          |
| Results              | 13     |          0 |          0 |        0 |

Carried (13 to 0)

## 7. Late Reports

There were no late reports to discuss.

## 8. Clarification in Relation to a Matter Arising Outside of Meetings

There were no items to discuss.

## 9. General Business

## 9.1 Refinement of the Draft Logan Plan

| Moved    | Councillor Stemp   |
|----------|--------------------|
| Seconded | Councillor Bradley |

That as part of the ongoing refinement of the Draft Logan Plan, options be considered addressing the feasibility of removing the Flood Investigation Area from the overlay maps, flood awareness mapping and associated property reports, and these options be presented to a future City Shape, Economic Transformation and Transport Committee.

|                      | For    |   Against  | Abstain           | Absent            |
|----------------------|--------|------------|-------------------|-------------------|
| Mayor Raven          | X      |            |                   |                   |
| Councillor Bradley   | X      |            |                   |                   |
| Councillor Lane      | X      |            |                   |                   |
| Councillor Russell   | X      |            |                   |                   |
| Councillor St Ledger | X      |            |                   |                   |
| Councillor Jackson   | X      |            |                   |                   |
| Councillor Hall      | X      |            |                   |                   |
| Councillor Frazer    | X      |            |                   |                   |
| Councillor Heremaia  | X      |            |                   |                   |
| Deputy Mayor Bannan  | X      |            |                   |                   |
| Councillor Stemp     | X      |            |                   |                   |
| Councillor Willcocks | X      |            |                   |                   |
| Councillor Murphy    | X      |            |                   |                   |
| Results              | 13     |          0 | 0                 | 0                 |
|                      |        |            | Carried (13 to 0) | Carried (13 to 0) |

The meeting concluded at 10:13 am.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

Chairperson of the City Shape, Economic Transformation &amp; Transport Committee