<!-- image -->

Based on the image provided, here is a description focusing on the requested elements:

This is the official logo for the **City of Logan**.

The logo consists of a stylized, multi-colored flower icon above the text. The text reads "CITY OF" in a smaller font, positioned above the word "LOGAN" in a larger, bold, sans-serif font.

From the visual information in this logo alone:

*   **Locations:** The only location identified is the **City of Logan**.
*   **Project Names:** There are no project names visible.
*   **Budget Figures:** There are no budget figures, costs, or monetary values visible.
*   **Procurement Indicators:** There are no procurement indicators, such as tender numbers, contract details, or requests for proposal.
*   **Council Decisions:** There are no council decisions, motion numbers, or meeting dates visible.

## Special Budget Committee

## Meeting Minutes

Meeting #:

Date:

Time:

Location:

845

28 and 29 April 2026

8:30 am

Logan Meeting Room

Level 3, Logan City Council Administration Centre

150 Wembley Road, Logan Central

Present:

Councillor Murphy (Chairperson) (Left the meeting on 28 April from 11:57 am to 12:00 pm)

Councillor Jackson (Deputy Chairperson) (Left the meeting on 28 April from 10:09 am to 10:12 am and 12:00 pm to 12:02 pm) 10:30

Mayor Raven (Left the meeting on 28 April from 9:32 am to 9:34 am) (Left the meeting on 29 April from 9:09 am to 9:14 am , am to 10:35 am and 12:38 pm to 12:50 pm)

via Audio Visual Link

Councillor Bradley (Left the meeting on 29 April from 11:16 am to 11:17 am and 1:33 pm to 1:35 pm)

via Audio Visual Link

Councillor Lane (Left the meeting on 28 April from 9:01 am to 9:06 am, 9:08 am to 9:10 am and 9:30 am to 9:31 am. (Joined the meeting on 29 April at 8:34 am, left from 9:48 am to 9:53 am, 1:04 pm to 1:06 pm and left the meeting at 3:10 pm)

Councillor Russell (Left the meeting on 29 April from 9:37 am to 9:41 am)

Councillor St Ledger (left the meeting on 28 April from 9:26 am to 9:27 am, 10:37 am to 10:39 am, 10:50 am to 10:53 am, 12:22 pm to 12:25 pm, 1:06 pm to 1:09 pm and 2:04 pm to 2:31 pm) (Left the meeting on 29 April from 8:45 am to 8:48 am, 9:51 am to 9:53 am, 2:19 pm to 2:21 pm and 3:31 pm to 3:36 pm)

Councillor Hall (Joined the meeting on 28 April at 8:35 am , left from 8:54 am to 8:59 am and 11:33 am to 11:36 am) (Joined the meeting on 29 April at 9:04 am and left from 11:49 to 11:51 am)

via Audio Visual Link

Councillor Frazer (Left the meeting on 28 April 9:50 am and re- joined the meeting at 12:22 pm) (Joined the meeting on 29 April at 8:42 am and left from 9:54 am to 10:25 am, 12:33 pm to 12:34 pm and left the meeting at 1:30 pm)

Councillor Heremaia

Deputy Mayor, Councillor Bannan (Left the meeting on 28 April from 9:39 am to 9:41 am, 10:45 am to 10:50 am, 10:50 am to 10:53 am, 11:21 am to 11:24 am, 11:52 am to 12:01 pm, 12:19 pm to 12:23 pm, 1:50 pm to 1:51 pm, 2:35 pm to 2:39 pm and 2:40 pm to 2:42 pm) (Left the meeting on 29 April from 8:41 am to 8:44 am, 8:57 am to 9:01 am, 9:09 am to 9:10 am, 10:55 am to 10:58 am, 12:44 pm to

12:45 pm and 2:17 pm to 2:21 pm)

Councillor Stemp (Left the meeting on 28 April from 9:42 am to 9:43 am)

Councillor Willcocks (Left the meeting on 28 April from 12:32 pm to 12:34 pm.) (Left the meeting on 29 April from 10:56 am to 10:58 am, 1:31 pm to 1:33 pm, 2:15 pm to 2:18 pm and left the meeting at 2:31 pm.)

In Attendance:

Chief Executive Officer - D Scott

Executive General Manager, Organisational Services - R Strachan

Executive General Manager, Growth, Economy and Sustainability -

D Hansen

Executive General Manager, Community and Lifestyle - B White

Executive General Manager, Transport Services - D Reilly

Executive General Manager Logan Water - G Brierley

Finance Manager - M Barnett

General Manager People and Culture - G Watson

Corporate Meetings Coordinator - K Jack

Corporate Meetings Officer - G Winspear

Corporate Meetings Officer - L Crawford

A/Corporate Meetings Officer - C Giallourakis

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

## 1. Acknowledgement of Country

The Chairperson, Councillor Murphy, opened the meeting by acknowledging the Traditional Custodians of the land on which the meeting was gathered, including Elders past, present and emerging.

## 2. Welcome

The Chairperson, Councillor Murphy, welcomed attendees to the Special Budget Committee and declared the meeting open at 8:30 am.

Councillor Murphy advised meeting attendees that the meeting was being webcast and audio recorded.

## 3. Attendances and Leaves of Absence

There were no Leaves of Absence recorded.

## UNCONFIRMED

## 4. Confirmation of Previous Committee Meeting Minutes

Moved

Mayor Raven

Seconded

Deputy Mayor Bannan

That the Minutes of the Special Budget Committee meeting held on 12 November 2025, be confirmed .

|                      | For    |   Against  |   Abstain  | Absent   |
|----------------------|--------|------------|------------|----------|
| Mayor Raven          | X      |            |            |          |
| Councillor Bradley   | X      |            |            |          |
| Councillor Lane      | X      |            |            |          |
| Councillor Russell   | X      |            |            |          |
| Councillor St Ledger | X      |            |            |          |
| Councillor Jackson   | X      |            |            |          |
| Councillor Hall      |        |            |            | X        |
| Councillor Frazer    | X      |            |            |          |
| Councillor Heremaia  | X      |            |            |          |
| Deputy Mayor Bannan  | X      |            |            |          |
| Councillor Stemp     | X      |            |            |          |
| Councillor Willcocks | X      |            |            |          |
| Councillor Murphy    | X      |            |            |          |
| Results              | 12     |          0 |          0 | 1        |

Carried (12 to 0)

## 5. Committee Reports

## 5.1 2026 -27 Budget - Financial Challenges and Opportunities

Councillor Hall joined the meeting at 8:35 am.

| Moved    | Councillor Willcocks   |
|----------|------------------------|
| Seconded | Councillor Jackson     |

That the PowerPoint, as presented to the meeting in relation to Item 5.1 of the Special Budget Committee meeting held on 28 April 2026, be tabled.

|                      | For    |   Against  |   Abstain  |   Absent |
|----------------------|--------|------------|------------|----------|
| Mayor Raven          | X      |            |            |          |
| Councillor Bradley   | X      |            |            |          |
| Councillor Lane      | X      |            |            |          |
| Councillor Russell   | X      |            |            |          |
| Councillor St Ledger | X      |            |            |          |
| Councillor Jackson   | X      |            |            |          |
| Councillor Hall      | X      |            |            |          |
| Councillor Frazer    | X      |            |            |          |
| Councillor Heremaia  | X      |            |            |          |
| Deputy Mayor Bannan  | X      |            |            |          |
| Councillor Stemp     | X      |            |            |          |
| Councillor Willcocks | X      |            |            |          |
| Councillor Murphy    | X      |            |            |          |
| Results              | 13     |          0 |          0 |        0 |

Carried (13 to 0)

Moved

Councillor Willcocks

Seconded

Councillor Jackson

That the meeting move into Closed Session at 8:51 am, pursuant to Section 254J(3) of the Local Government Regulation 2012, for the consideration of the following items for the reasons shown:

|   Item  | Matter to be  discussed                                       | Statutory basis for  closing meeting                                          | Overview of what is to  be discussed                                                                                                                                   |
|---------|---------------------------------------------------------------|-------------------------------------------------------------------------------|------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
|     5.1 | 2026 - 27 Budget  -  Financial  Challenges and  Opportunities | The matter relates  to Section  254J(3):(c) the  local  government’s  budget. | It is considered  necessary to take the  discussion of the  confidential attachment  into a closed session  as it contains  information relating to  Council’s budget. |

The general discussions, opinions of others and documentation presented to the closed meeting are to be kept confidential until otherwise resolved by Council.

## UNCONFIRMED

|                      | For    | Against    |   Abstain  |   Absent |
|----------------------|--------|------------|------------|----------|
| Mayor Raven          | X      |            |            |          |
| Councillor Bradley   | X      |            |            |          |
| Councillor Lane      | X      |            |            |          |
| Councillor Russell   | X      |            |            |          |
| Councillor St Ledger | X      |            |            |          |
| Councillor Jackson   | X      |            |            |          |
| Councillor Hall      |        | X          |            |          |
| Councillor Frazer    | X      |            |            |          |
| Councillor Heremaia  |        | X          |            |          |
| Deputy Mayor Bannan  | X      |            |            |          |
| Councillor Stemp     | X      |            |            |          |
| Councillor Willcocks | X      |            |            |          |
| Councillor Murphy    | X      |            |            |          |
| Results              | 11     | 2          |          0 |        0 |

Carried (11 to 2)

Councillor Heremaia provided the following reason for voting against the motion:

" The motion states that "it is considered necessary to take the discussion of the confidential attachment into a closed session". Now I don't think that it is necessary to take this discussion into confidential I have reviewed the attachment there is a lot of public information there and I think as much of the conversation of the city budget should be in public. "

Councillor Hall left the meeting from 8:54 am to 8:59 am.

Councillor Lane left the meeting from 9:01 am to 9:06 am.

Councillor Lane left the meeting from 9:08 am to 9:10 am.

Councillor St Ledger left the meeting from 9:26 am to 9:27 am.

Councillor Lane left the meeting from 9:30 am to 9:31 am.

Mayor Raven left the meeting from 9:32 am to 9:34 am.

Councillor Bannan left the meeting from 9:39 am to 9:41 am.

Councillor Stemp left the meeting from 9:42 am to 9:43 am.

Councillor Frazer left the meeting at 9:50 am.

Councillor Jackson left the meeting 10:09 am to 10:12 am.

## Moved

Deputy Mayor Bannan

That the meeting be re ‑ opened to the public in accordance with Section 254J of the Local Government Regulation 2012 at 10:15 am.

Carried (12 to 0)

|                      | For    |   Against  |   Abstain  | Absent   |
|----------------------|--------|------------|------------|----------|
| Mayor Raven          | X      |            |            |          |
| Councillor Bradley   | X      |            |            |          |
| Councillor Lane      | X      |            |            |          |
| Councillor Russell   | X      |            |            |          |
| Councillor St Ledger | X      |            |            |          |
| Councillor Jackson   | X      |            |            |          |
| Councillor Hall      | X      |            |            |          |
| Councillor Frazer    |        |            |            | X        |
| Councillor Heremaia  | X      |            |            |          |
| Deputy Mayor Bannan  | X      |            |            |          |
| Councillor Stemp     | X      |            |            |          |
| Councillor Willcocks | X      |            |            |          |
| Councillor Murphy    | X      |            |            |          |
| Results              | 12     |          0 |          0 | 1        |

Moved

Deputy Mayor Bannan

Seconded

Councillor Jackson

1. That the report titled 2026/27 Budget -Financial Challenges and Opportunities and associated attachment, be noted.
2. That the confidential attachment, as attached to the report titled 2026/27 Budget - Financial Challenges and Opportunities, be deemed confidential and be treated as such in accordance with sections 171 and 200 of the Local Government Act 2009 and that the confidential attachment remains confidential.

|                      | For    |   Against  | Abstain *    | Absent   |
|----------------------|--------|------------|--------------|----------|
| Mayor Raven          | X      |            |              |          |
| Councillor Bradley   | X      |            |              |          |
| Councillor Lane      |        |            | X            |          |
| Councillor Russell   | X      |            |              |          |
| Councillor St Ledger | X      |            |              |          |
| Councillor Jackson   | X      |            |              |          |
| Councillor Hall      | X      |            |              |          |
| Councillor Frazer    |        |            |              | X        |
| Councillor Heremaia  | X      |            |              |          |
| Deputy Mayor Bannan  | X      |            |              |          |
| Councillor Stemp     | X      |            |              |          |
| Councillor Willcocks |        |            | X            |          |
| Councillor Murphy    | X      |            |              |          |
| Results              | 10     |          0 | 2            | 1        |

Carried (10 to 2)

Councillor Lane provided the following reason for abstaining from voting:

"I "I missed the first 35 minutes due to IT issues . I want to review the confidential tapes to make sure I am across everything before I vote "

Councillor Willcocks provided the following reason for abstaining from voting:

"I "I am still waiting on answers to some questions"

## 5.2 2026 -27 Budget - Proposed Annual Budget

Moved

Councillor Willcocks

Seconded

Mayor Raven

That the meeting move into Closed Session at 10:18 am, pursuant to Section 254J(3) of the Local Government Regulation 2012, for the consideration of the following items for the reasons shown:

|   Item  | Matter to be  discussed                      | Statutory basis for  closing meeting                                         | Overview of what is to be  discussed                                                                                                                                   |
|---------|----------------------------------------------|------------------------------------------------------------------------------|------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
|     5.2 | 2026 - 27  Budget - Proposed  Annual  Budget | The matter relates  to Section  254J(3):(c) the  local government’s  budget. | It is considered necessary  to take the discussion of  the confidential  attachments into a closed  session as it contains  information relating to  Council’s budget. |

## UNCONFIRMED

The general discussions, opinions of others and documentation presented to the closed meeting are to be kept confidential until otherwise resolved by Council .

|                      | For    | Against    |   Abstain  | Absent   |
|----------------------|--------|------------|------------|----------|
| Mayor Raven          | X      |            |            |          |
| Councillor Bradley   | X      |            |            |          |
| Councillor Lane      | X      |            |            |          |
| Councillor Russell   | X      |            |            |          |
| Councillor St Ledger | X      |            |            |          |
| Councillor Jackson   | X      |            |            |          |
| Councillor Hall      |        | X          |            |          |
| Councillor Frazer    |        |            |            | X        |
| Councillor Heremaia  |        | X          |            |          |
| Deputy Mayor Bannan  | X      |            |            |          |
| Councillor Stemp     | X      |            |            |          |
| Councillor Willcocks | X      |            |            |          |
| Councillor Murphy    | X      |            |            |          |
| Results              | 10     | 2          |          0 | 1        |

Carried (10 to 2)

Councillor St Ledger left the meeting from 10:37 am to 10:39 am.

Deputy Mayor, Councillor Bannan left the meeting from 10:45 am to 10:50 am and from 10:50 am to 10:53 am.

Councillor St Ledger left the meeting from 10:50 am to 10:53 am.

Deputy Mayor, Councillor Bannan left the meeting from 11:21 am to 11:24 am.

Councillor Hall left the meeting from 11:33 am to 11:36 am.

Deputy Mayor, Councillor Bannan left the meeting from 11:52 am to 12:01 pm.

Councillor Murphy left the meeting at 11:57 am.

Councillor Jackson assumed the chair at 11:57 am in Councillor Murphy's absence.

Councillor Jackson relinquished chair at 12:00 pm.

Councillor Murphy returned to the meeting and resumed responsibility as Chair at 12:00 pm.

Councillor Jackson left the meeting from 12:00 pm to 12:02 pm.

Deputy Mayor, Councillor Bannan left the meeting from 12:19 pm to 12:23 pm.

Councillor Frazer joined the meeting at 12:22 pm.

Councillor St Ledger left the meeting from 12:22 pm to 12:25 pm.

Councillor Willcocks left the meeting from 12:32 pm to 12:34 pm .

Moved

Councillor Hall

That the meeting be re ‑ opened to the public in accordance with Section 254J of the Local Government Regulation 2012 at 12:36 pm.

|                      | For    |   Against  |   Abstain  |   Absent |
|----------------------|--------|------------|------------|----------|
| Mayor Raven          | X      |            |            |          |
| Councillor Bradley   | X      |            |            |          |
| Councillor Lane      | X      |            |            |          |
| Councillor Russell   | X      |            |            |          |
| Councillor St Ledger | X      |            |            |          |
| Councillor Jackson   | X      |            |            |          |
| Councillor Hall      | X      |            |            |          |
| Councillor Frazer    | X      |            |            |          |
| Councillor Heremaia  | X      |            |            |          |
| Deputy Mayor Bannan  | X      |            |            |          |
| Councillor Stemp     | X      |            |            |          |
| Councillor Willcocks | X      |            |            |          |
| Councillor Murphy    | X      |            |            |          |
| Results              | 13     |          0 |          0 |        0 |

Carried (13 to 0)

Moved

Mayor Raven

Seconded

Councillor Willcocks

That, in accordance with Section 261 of the Local Government Regulation 2012, the meeting be adjourned from 12:36 pm, until 1:06 pm.

|                      | For    |   Against  |   Abstain  |   Absent |
|----------------------|--------|------------|------------|----------|
| Mayor Raven          | X      |            |            |          |
| Councillor Bradley   | X      |            |            |          |
| Councillor Lane      | X      |            |            |          |
| Councillor Russell   | X      |            |            |          |
| Councillor St Ledger | X      |            |            |          |
| Councillor Jackson   | X      |            |            |          |
| Councillor Hall      | X      |            |            |          |
| Councillor Frazer    | X      |            |            |          |
| Councillor Heremaia  | X      |            |            |          |
| Deputy Mayor Bannan  | X      |            |            |          |
| Councillor Stemp     | X      |            |            |          |
| Councillor Willcocks | X      |            |            |          |
| Councillor Murphy    | X      |            |            |          |
| Results              | 13     |          0 |          0 |        0 |

Carried (13 to 0)

Councillor St Ledger left the meeting at 1:06 pm .

| Moved    | Mayor Raven          |
|----------|----------------------|
| Seconded | Councillor Willcocks |

That, in accordance with Section 261 of the Local Government Regulation 2012, the meeting be recommenced at 1:06 pm.

|                      | For    |   Against  |   Abstain  | Absent   |
|----------------------|--------|------------|------------|----------|
| Mayor Raven          | X      |            |            |          |
| Councillor Bradley   | X      |            |            |          |
| Councillor Lane      | X      |            |            |          |
| Councillor Russell   | X      |            |            |          |
| Councillor St Ledger |        |            |            | X        |
| Councillor Jackson   | X      |            |            |          |
| Councillor Hall      | X      |            |            |          |
| Councillor Frazer    | X      |            |            |          |
| Councillor Heremaia  | X      |            |            |          |
| Deputy Mayor Bannan  | X      |            |            |          |
| Councillor Stemp     | X      |            |            |          |
| Councillor Willcocks | X      |            |            |          |
| Councillor Murphy    | X      |            |            |          |
| Results              | 12     |          0 |          0 | 1        |

Carried (12 to 0)

| Moved    | Mayor Raven      |
|----------|------------------|
| Seconded | Councillor Stemp |

That the meeting move into Closed Session at 1:07 pm, pursuant to Section 254J(3) of the Local Government Regulation 2012, for the consideration of the following items for the reasons shown:

|   Item  | Matter to be  discussed                      | Statutory basis for  closing meeting                                         | Overview of what is to be  discussed                                                                                                                                   |
|---------|----------------------------------------------|------------------------------------------------------------------------------|------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
|     5.2 | 2026 - 27  Budget - Proposed  Annual  Budget | The matter relates  to Section  254J(3):(c) the  local government’s  budget. | It is considered necessary  to take the discussion of  the confidential  attachments into a closed  session as it contains  information relating to  Council’s budget. |

The general discussions, opinions of others and documentation presented to the closed meeting are to be kept confidential until otherwise resolved by Council.

## UNCONFIRMED

|                      | For    | Against    |   Abstain  | Absent   |
|----------------------|--------|------------|------------|----------|
| Mayor Raven          | X      |            |            |          |
| Councillor Bradley   | X      |            |            |          |
| Councillor Lane      | X      |            |            |          |
| Councillor Russell   | X      |            |            |          |
| Councillor St Ledger |        |            |            | X        |
| Councillor Jackson   | X      |            |            |          |
| Councillor Hall      |        | X          |            |          |
| Councillor Frazer    | X      |            |            |          |
| Councillor Heremaia  |        | X          |            |          |
| Deputy Mayor Bannan  | X      |            |            |          |
| Councillor Stemp     | X      |            |            |          |
| Councillor Willcocks | X      |            |            |          |
| Councillor Murphy    | X      |            |            |          |
| Results              | 10     | 2          |          0 | 1        |

Councillor St Ledger joined the meeting at 1:09 pm

Deputy Mayor, Councillor Bannan left the meeting from 1:50 pm to 1:51 pm.

Councillor St Ledger left the meeting from 2:04 pm to 2:31 pm

Deputy Mayor, Councillor Bannan left the meeting from 2:35 pm to 2:39 pm.

Deputy Mayor, Councillor Bannan left the meeting from 2:40 pm to 2:42 pm.

Carried (10 to 2)

Moved

Councillor Hall

That the meeting be re ‑ opened to the public in accordance with Section 254J of the Local Government Regulation 2012 at 3:01 pm.

|                      | For    |   Against  |   Abstain  |   Absent |
|----------------------|--------|------------|------------|----------|
| Mayor Raven          | X      |            |            |          |
| Councillor Bradley   | X      |            |            |          |
| Councillor Lane      | X      |            |            |          |
| Councillor Russell   | X      |            |            |          |
| Councillor St Ledger | X      |            |            |          |
| Councillor Jackson   | X      |            |            |          |
| Councillor Hall      | X      |            |            |          |
| Councillor Frazer    | X      |            |            |          |
| Councillor Heremaia  | X      |            |            |          |
| Deputy Mayor Bannan  | X      |            |            |          |
| Councillor Stemp     | X      |            |            |          |
| Councillor Willcocks | X      |            |            |          |
| Councillor Murphy    | X      |            |            |          |
| Results              | 13     |          0 |          0 |        0 |

Carried (13 to 0)

Moved

Councillor Hall

Seconded

Mayor Raven

That, in accordance with Section 261 of the Local Government Regulation 2012, the meeting be adjourned from 3:01 pm, until 8:30 am , 29 April 2026.

|                      | For    |   Against  |   Abstain  |   Absent |
|----------------------|--------|------------|------------|----------|
| Mayor Raven          | X      |            |            |          |
| Councillor Bradley   | X      |            |            |          |
| Councillor Lane      | X      |            |            |          |
| Councillor Russell   | X      |            |            |          |
| Councillor St Ledger | X      |            |            |          |
| Councillor Jackson   | X      |            |            |          |
| Councillor Hall      | X      |            |            |          |
| Councillor Frazer    | X      |            |            |          |
| Councillor Heremaia  | X      |            |            |          |
| Deputy Mayor Bannan  | X      |            |            |          |
| Councillor Stemp     | X      |            |            |          |
| Councillor Willcocks | X      |            |            |          |
| Councillor Murphy    | X      |            |            |          |
| Results              | 13     |          0 |          0 |        0 |

Carried (13 to 0)

Moved

Councillor Willcocks

Seconded

Deputy Mayor Bannan

That, in accordance with Section 261 of the Local Government Regulation 2012, the meeting be recommenced at 8:31 am , 29 April 2026.

|                      | For    |   Against  |   Abstain  | Absent   |
|----------------------|--------|------------|------------|----------|
| Mayor Raven          | X      |            |            |          |
| Councillor Bradley   | X      |            |            |          |
| Councillor Lane      |        |            |            | X        |
| Councillor Russell   | X      |            |            |          |
| Councillor St Ledger | X      |            |            |          |
| Councillor Jackson   | X      |            |            |          |
| Councillor Hall      |        |            |            | X        |
| Councillor Frazer    |        |            |            | X        |
| Councillor Heremaia  | X      |            |            |          |
| Deputy Mayor Bannan  | X      |            |            |          |
| Councillor Stemp     | X      |            |            |          |
| Councillor Willcocks | X      |            |            |          |
| Councillor Murphy    | X      |            |            |          |
| Results              | 10     |          0 |          0 | 3        |

Carried (10 to 0)

Councillor Lane joined the meeting at 8:34 am.

Moved

Deputy Mayor Bannan

Seconded

Councillor Jackson

That the meeting move into Closed Session at 8:34 am, pursuant to Section 254J(3) of the Local Government Regulation 2012, for the consideration of the following items for the reasons shown:

|   Item  | Matter to be  discussed                      | Statutory basis for  closing meeting                                         | Overview of what is to be  discussed                                                                                                                                   |
|---------|----------------------------------------------|------------------------------------------------------------------------------|------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
|     5.2 | 2026 - 27  Budget - Proposed  Annual  Budget | The matter relates  to Section  254J(3):(c) the  local government’s  budget. | It is considered necessary  to take the discussion of  the confidential  attachments into a closed  session as it contains  information relating to  Council’s budget. |

## UNCONFIRMED

The general discussions, opinions of others and documentation presented to the closed meeting are to be kept confidential until otherwise resolved by Council.

|                      | For    | Against    |   Abstain  | Absent   |
|----------------------|--------|------------|------------|----------|
| Mayor Raven          | X      |            |            |          |
| Councillor Bradley   | X      |            |            |          |
| Councillor Lane      | X      |            |            |          |
| Councillor Russell   | X      |            |            |          |
| Councillor St Ledger | X      |            |            |          |
| Councillor Jackson   | X      |            |            |          |
| Councillor Hall      |        |            |            | X        |
| Councillor Frazer    |        |            |            | X        |
| Councillor Heremaia  |        | X          |            |          |
| Deputy Mayor Bannan  | X      |            |            |          |
| Councillor Stemp     | X      |            |            |          |
| Councillor Willcocks | X      |            |            |          |
| Councillor Murphy    | X      |            |            |          |
| Results              | 10     | 1          |          0 | 2        |

Carried (10 to 1)

Councillor Frazer joined the meeting at 8:42 am.

Deputy Mayor, Councillor Bannan left the meeting from 8:41 am to 8:44 am.

Councillor St Ledger left the meeting from 8:45 am to 8:48 am.

Deputy Mayor, Councillor Bannan left the meeting from 8:57 am to 9:01 am.

Councillor Hall joined the meeting at 9:04 am.

Mayor Raven left the meeting from 9:09 am to 9:14 am

Deputy Mayor, Councillor Bannan left the meeting from 9:09 am to 9:10 am.

Councillor Russell left the meeting from 9:37 am to 9:41 am.

Councillor Lane left the meeting from 9:48 am to 9:53 am.

Councillor St Ledger left the meeting from 9:51 am to 9:53 am.

Councillor Frazer left the meeting from 9:54 am to 10:25 am.

Mayor Raven left the meeting from 10:30 am to 10:35 am.

Deputy Mayor, Councillor Bannan left the meeting from 10:55 am to 10:58 am.

Councillor Willcocks left the meeting from 10:56 am to 10:58 am.

Councillor Bradley left the meeting from 11:16 am to 11:17 am.

Councillor Hall left the meeting from 11:49 am to 11:51 am.

| Moved    | Councillor Hall    |
|----------|--------------------|
| Seconded | Councillor Bradley |

That the meeting be re ‑ opened to the public in accordance with Section 254J of the Local Government Regulation 2012 at 12:00 pm.

|                      | For    |   Against  |   Abstain  |   Absent |
|----------------------|--------|------------|------------|----------|
| Mayor Raven          | X      |            |            |          |
| Councillor Bradley   | X      |            |            |          |
| Councillor Lane      | X      |            |            |          |
| Councillor Russell   | X      |            |            |          |
| Councillor St Ledger | X      |            |            |          |
| Councillor Jackson   | X      |            |            |          |
| Councillor Hall      | X      |            |            |          |
| Councillor Frazer    | X      |            |            |          |
| Councillor Heremaia  | X      |            |            |          |
| Deputy Mayor Bannan  | X      |            |            |          |
| Councillor Stemp     | X      |            |            |          |
| Councillor Willcocks | X      |            |            |          |
| Councillor Murphy    | X      |            |            |          |
| Results              | 13     |          0 |          0 |        0 |

Carried (13 to 0)

| Moved    | Deputy Mayor Bannan   |
|----------|-----------------------|
| Seconded | Councillor Hall       |

That, in accordance with Section 261 of the Local Government Regulation 2012, the meeting be adjourned from 12:01 pm, until 12:31 pm.

|                      | For    |   Against  |   Abstain  |   Absent |
|----------------------|--------|------------|------------|----------|
| Mayor Raven          | X      |            |            |          |
| Councillor Bradley   | X      |            |            |          |
| Councillor Lane      | X      |            |            |          |
| Councillor Russell   | X      |            |            |          |
| Councillor St Ledger | X      |            |            |          |
| Councillor Jackson   | X      |            |            |          |
| Councillor Hall      | X      |            |            |          |
| Councillor Frazer    | X      |            |            |          |
| Councillor Heremaia  | X      |            |            |          |
| Deputy Mayor Bannan  | X      |            |            |          |
| Councillor Stemp     | X      |            |            |          |
| Councillor Willcocks | X      |            |            |          |
| Councillor Murphy    | X      |            |            |          |
| Results              | 13     |          0 |          0 |        0 |

Carried (13 to 0)

| Moved    | Mayor Raven     |
|----------|-----------------|
| Seconded | Councillor Hall |

That, in accordance with Section 261 of the Local Government Regulation 2012, the meeting be recommenced at 12:32 pm.

|                      | For    |   Against  |   Abstain  |   Absent |
|----------------------|--------|------------|------------|----------|
| Mayor Raven          | X      |            |            |          |
| Councillor Bradley   | X      |            |            |          |
| Councillor Lane      | X      |            |            |          |
| Councillor Russell   | X      |            |            |          |
| Councillor St Ledger | X      |            |            |          |
| Councillor Jackson   | X      |            |            |          |
| Councillor Hall      | X      |            |            |          |
| Councillor Frazer    | X      |            |            |          |
| Councillor Heremaia  | X      |            |            |          |
| Deputy Mayor Bannan  | X      |            |            |          |
| Councillor Stemp     | X      |            |            |          |
| Councillor Willcocks | X      |            |            |          |
| Councillor Murphy    | X      |            |            |          |
| Results              | 13     |          0 |          0 |        0 |

Carried (13 to 0)

Councillor Frazer left the meeting from 12:33 pm.

Moved

Deputy Mayor Bannan

Seconded

Councillor Stemp

That the meeting move into Closed Session at 12:34 pm, pursuant to Section 254J(3) of the Local Government Regulation 2012, for the consideration of the following items for the reasons shown:

|   Item  | Matter to be  discussed                      | Statutory basis for  closing meeting                                         | Overview of what is to be  discussed                                                                                                                                   |
|---------|----------------------------------------------|------------------------------------------------------------------------------|------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
|     5.2 | 2026 - 27  Budget - Proposed  Annual  Budget | The matter relates  to Section  254J(3):(c) the  local government’s  budget. | It is considered necessary  to take the discussion of  the confidential  attachments into a closed  session as it contains  information relating to  Council’s budget. |

## UNCONFIRMED

The general discussions, opinions of others and documentation presented to the closed meeting are to be kept confidential until otherwise resolved by Council.

|                      | For    | Against *    |   Abstain  | Absent   |
|----------------------|--------|--------------|------------|----------|
| Mayor Raven          | X      |              |            |          |
| Councillor Bradley   | X      |              |            |          |
| Councillor Lane      | X      |              |            |          |
| Councillor Russell   | X      |              |            |          |
| Councillor St Ledger | X      |              |            |          |
| Councillor Jackson   | X      |              |            |          |
| Councillor Hall      |        | X            |            |          |
| Councillor Frazer    |        |              |            | X        |
| Councillor Heremaia  |        | X            |            |          |
| Deputy Mayor Bannan  | X      |              |            |          |
| Councillor Stemp     | X      |              |            |          |
| Councillor Willcocks | X      |              |            |          |
| Councillor Murphy    | X      |              |            |          |
| Results              | 10     | 2            |          0 | 1        |

Carried (10 to 2)

Councillor Frazer joined the meeting at 12:34 pm.

Mayor Raven left the meeting from 12:38 pm to 12:50 pm.

Deputy Mayor, Councillor Bannan left the meeting from 12:44 pm to 12:45 pm.

Mayor Raven assumed the chair at 12:51 pm.

Councillor Lane left the meeting from 1:04 pm to 1:06 pm.

Councillor Frazer left the meeting at 1:30 pm

Councillor Willcocks left from 1:31 pm to 1:33 pm.

Councillor Bradley left from 1:33 pm to 1:35 pm.

Councillor Willcocks left the meeting from 2:15 pm to 2:18 pm.

Deputy Mayor, Councillor Bannan left the meeting from 2:17 pm to 2:21 pm.

Councillor St Ledger left the meeting from 2:19 pm to 2:21 pm.

Councillor Willcocks left the meeting at 2:31 pm.

Councillor Mayor relinquished chair at 3:00 pm.

Councillor Murphy resumed responsibility as Chair at 3:00 pm.

Councillor Lane left the meeting at 3:10 pm.

Councillor St Ledger left the meeting at 3:31 pm.

| Moved    | Councillor Bradley   |
|----------|----------------------|
| Seconded | Councillor Hall      |

That the meeting be re ‑ opened to the public in accordance with Section 254J of the Local Government Regulation 2012 at 3:32 pm.

|                      | For    |   Against  |   Abstain  | Absent   |
|----------------------|--------|------------|------------|----------|
| Mayor Raven          | X      |            |            |          |
| Councillor Bradley   | X      |            |            |          |
| Councillor Lane      |        |            |            | X        |
| Councillor Russell   | X      |            |            |          |
| Councillor St Ledger |        |            |            | X        |
| Councillor Jackson   | X      |            |            |          |
| Councillor Hall      | X      |            |            |          |
| Councillor Frazer    |        |            |            | X        |
| Councillor Heremaia  | X      |            |            |          |
| Deputy Mayor Bannan  | X      |            |            |          |
| Councillor Stemp     | X      |            |            |          |
| Councillor Willcocks |        |            |            | X        |
| Councillor Murphy    | X      |            |            |          |
| Results              | 9      |          0 |          0 | 4        |

Carried (9 to 0)

## Moved

Councillor Hall

That the confidential attachment and confidential additional attachments, as presented to the meeting in relation to Item 5.2 of the Special Budget Committee meeting held on 28 April 2026, be tabled.

|                      | For    |   Against  |   Abstain  | Absent   |
|----------------------|--------|------------|------------|----------|
| Mayor Raven          | X      |            |            |          |
| Councillor Bradley   | X      |            |            |          |
| Councillor Lane      |        |            |            | X        |
| Councillor Russell   | X      |            |            |          |
| Councillor St Ledger |        |            |            | X        |
| Councillor Jackson   | X      |            |            |          |
| Councillor Hall      | X      |            |            |          |
| Councillor Frazer    |        |            |            | X        |
| Councillor Heremaia  | X      |            |            |          |
| Deputy Mayor Bannan  | X      |            |            |          |
| Councillor Stemp     | X      |            |            |          |
| Councillor Willcocks |        |            |            | X        |
| Councillor Murphy    | X      |            |            |          |
| Results              | 9      |          0 |          0 | 4        |

Carried (9 to 0)

Moved

Mayor Raven

Seconded

Deputy Mayor Bannan

That the report titled 2026/27 Budget - Proposed Annual Budget, be noted.

|                      | For    |   Against  | Abstain *    | Absent   |
|----------------------|--------|------------|--------------|----------|
| Mayor Raven          | X      |            |              |          |
| Councillor Bradley   |        |            | X            |          |
| Councillor Lane      |        |            |              | X        |
| Councillor Russell   | X      |            |              |          |
| Councillor St Ledger |        |            |              | X        |
| Councillor Jackson   | X      |            |              |          |
| Councillor Hall      | X      |            |              |          |
| Councillor Frazer    |        |            |              | X        |
| Councillor Heremaia  |        |            |              |          |
| Deputy Mayor Bannan  | X X    |            |              |          |
| Councillor Stemp     | X      |            |              |          |
| Councillor Willcocks |        |            |              | X        |
| Councillor Murphy    | X      |            |              |          |
| Results              | 8      |          0 | 1            | 4        |

Carried (8 to 0)

Councillor St Ledger joined the meeting at 3:36 pm.

Councillor Bradley provided the following reason for abstaining from voting:

" There are some I may support in here but it is very difficult and not my preference to join via teams for this process because it is very difficult to hear I am just going to abstain today and get the audio and then decide."

Moved

Deputy Mayor Bannan

Seconded

Mayor Raven

1. That the proposed 2026/27 recurrent budget submissions as detailed in Confidential Attachment 2 to this report, be endorsed for inclusion in the 2026/27 budget to be adopted by Council.
2. That the confidential attachment as attached to this report titled 2026/27 Budget – Proposed Annual Budget be deemed confidential and be treated as such in accordance with sections 171 and 200 of the Local Government Act 2009 and that the attachments remain confidential.

|                      | For    | Against    | Abstain          | Absent           |
|----------------------|--------|------------|------------------|------------------|
| Mayor Raven          | X      |            |                  |                  |
| Councillor Bradley   |        |            | X                |                  |
| Councillor Lane      |        |            |                  | X                |
| Councillor Russell   | X      |            |                  |                  |
| Councillor St Ledger | X      |            |                  |                  |
| Councillor Jackson   | X      |            |                  |                  |
| Councillor Hall      | X      |            |                  |                  |
| Councillor Frazer    |        |            |                  | X                |
| Councillor Heremaia  |        | X          |                  |                  |
| Deputy Mayor Bannan  | X      |            |                  |                  |
| Councillor Stemp     | X      |            |                  |                  |
| Councillor Willcocks |        |            |                  | X                |
| Councillor Murphy    | X      |            |                  |                  |
| Results              | 8      | 1          | 1                | 3                |
|                      |        |            | Carried (8 to 2) | Carried (8 to 2) |

Moved

Deputy Mayor Bannan

Seconded

Mayor Raven

1. That subject to the amendments outlined within the confidential attachment as tabled to this meeting, the proposed 2026/27 register of cost -recovery fees and schedule of commercial fees and other charges as detailed in Confidential Attachment 3 to this report, be endorsed for inclusion in the 2026/27 budget to be adopted by Council.
2. That subject to the amendments outlined within the confidential attachment as tabled to this meeting, the proposed 2026/27 register of cost -recovery fees and schedule of commercial fees and other charges as contained in Confidential Attachment 3 to this report, take effect from 1 July 2026.
3. That Council approve the notification of the proposed 2026/27 cemetery fees to funeral directors before the budget has been adopted.
4. That Council approve the notification of the proposed 2026/27 waste fees to frequent use commercial operators before the budget has been adopted.
5. That the confidential attachment as attached to this report titled 2026/27 Budget – Proposed Annual Budget be deemed confidential and be treated as such in accordance with sections 171 and 200 of the Local Government Act 2009 and that the attachments remain confidential.

|                      | For    |   Against  | Abstain    | Absent   |
|----------------------|--------|------------|------------|----------|
| Mayor Raven          | X      |            |            |          |
| Councillor Bradley   |        |            | X          |          |
| Councillor Lane      |        |            |            | X        |
| Councillor Russell   | X      |            |            |          |
| Councillor St Ledger | X      |            |            |          |
| Councillor Jackson   | X      |            |            |          |
| Councillor Hall      | X      |            |            |          |
| Councillor Frazer    |        |            |            | X        |
| Councillor Heremaia  | X      |            |            |          |
| Deputy Mayor Bannan  | X      |            |            |          |
| Councillor Stemp     | X      |            |            |          |
| Councillor Willcocks |        |            |            | X        |
| Councillor Murphy    | X      |            |            |          |
| Results              | 9      |          0 | 1          | 3        |

Carried (9 to 1)

Moved

Mayor Raven

Seconded

Councillor Jackson

1. That subject to the amendments outlined within the confidential attachment as tabled to this meeting, the recommendations as set out in the supplementary report titled 2026/27 Rating Refinement as detailed in Confidential Attachment 4 to this report, be endorsed for inclusion in the 2026/27 budget to be adopted by Council.
2. That the confidential attachment as attached to this report titled 2026/27 Budget – Proposed Annual Budget be deemed confidential and be treated as such in accordance with sections 171 and 200 of the Local Government Act 2009 and that the attachments remain confidential.

|                      | For    | Against    | Abstain *    | Absent   |
|----------------------|--------|------------|--------------|----------|
| Mayor Raven          | X      |            |              |          |
| Councillor Bradley   |        |            | X            |          |
| Councillor Lane      |        |            |              | X        |
| Councillor Russell   | X      |            |              |          |
| Councillor St Ledger | X      |            |              |          |
| Councillor Jackson   | X      |            |              |          |
| Councillor Hall      |        | X          |              |          |
| Councillor Frazer    |        |            |              | X        |
| Councillor Heremaia  |        | X          |              |          |
| Deputy Mayor Bannan  | X      |            |              |          |
| Councillor Stemp     |        |            | X            |          |
| Councillor Willcocks |        |            |              | X        |
| Councillor Murphy    | X      |            |              |          |
| Results              | 6      | 2          | 2            | 3        |

Carried (6 to 4)

## UNCONFIRMED

Councillor Stemp provided the following reason for abstaining from voting:

" Waiting on additional information."

Moved

Councillor Jackson

Seconded

Councillor Murphy

1. That the recommendations as set out in the supplementary report titled 2026/27 Pensioner Concessions as detailed in Confidential Attachment 4 to this report, be endorsed for inclusion in the 2026/27 budget to be adopted by Council.
2. That the confidential attachment as attached to this report titled 2026/27 Budget – Proposed Annual Budget be deemed confidential and be treated as such in accordance with sections 171 and 200 of the Local Government Act 2009 and that the attachments remain confidential.

|                      | For    | Against    | Abstain    | Absent   |
|----------------------|--------|------------|------------|----------|
| Mayor Raven          |        | X          |            |          |
| Councillor Bradley   |        |            | X          |          |
| Councillor Lane      |        |            |            | X        |
| Councillor Russell   | X      |            |            |          |
| Councillor St Ledger |        | X          |            |          |
| Councillor Jackson   | X      |            |            |          |
| Councillor Hall      | X      |            |            |          |
| Councillor Frazer    |        |            |            | X        |
| Councillor Heremaia  |        | X          |            |          |
| Deputy Mayor Bannan  |        | X          |            |          |
| Councillor Stemp     | X      |            |            |          |
| Councillor Willcocks |        |            |            | X        |
| Councillor Murphy    | X      |            |            |          |
| Results              | 5      | 4          | 1          | 3        |

Equal (5 to 5)

As the vote was equal following the initial vote, the chairperson, Councillor Murphy exercised her Casting vote.

The Chairperson advised she would like her vote to remain as 'for'.

On that basis, pursuant to clause 7.1(b)(ii) of the Local Government and Committee Meeting Code, the vote was:

Carried (5 to 5, with the Chairperson having exercised their casting vote)

Moved

Deputy Mayor Bannan

Seconded

Mayor Raven

1. That the recommendations as set out in the supplementary report titled 2026/27 Volunteer Fire Brigade Separate Charge as detailed in Confidential Attachment 4 to this report, be endorsed for inclusion in the 2026/27 budget to be adopted by Council.
2. That the confidential attachment as attached to this report titled 2026/27 Budget – Proposed Annual Budget be deemed confidential and be treated as such in accordance with sections 171 and 200 of the Local Government Act 2009 and that the attachments remain confidential.

|                      | For    |   Against  | Abstain    | Absent   |
|----------------------|--------|------------|------------|----------|
| Mayor Raven          | X      |            |            |          |
| Councillor Bradley   |        |            | X          |          |
| Councillor Lane      |        |            |            | X        |
| Councillor Russell   | X      |            |            |          |
| Councillor St Ledger | X      |            |            |          |
| Councillor Jackson   | X      |            |            |          |
| Councillor Hall      | X      |            |            |          |
| Councillor Frazer    |        |            |            | X        |
| Councillor Heremaia  | X      |            |            |          |
| Deputy Mayor Bannan  | X      |            |            |          |
| Councillor Stemp     | X      |            |            |          |
| Councillor Willcocks |        |            |            | X        |
| Councillor Murphy    | X      |            |            |          |
| Results              | 9      |          0 | 1          | 3        |

Carried (9 to 1)

Moved

Councillor Stemp

Seconded

Councillor Russell

1. That the recommendations as set out in the supplementary report titled 2026/27 Environmental Levy as contained in Confidential Attachment 4 to this report, be endorsed for inclusion in the 2026/27 budget to be adopted by Council.
2. That the confidential attachment as attached to this report titled 2026/27 Budget – Proposed Annual Budget be deemed confidential and be treated as such in accordance with sections 171 and 200 of the Local Government Act 2009 and that the attachments remain confidential.

|                      | For    | Against    | Abstain    | Absent   |
|----------------------|--------|------------|------------|----------|
| Mayor Raven          | X      |            |            |          |
| Councillor Bradley   |        |            | X          |          |
| Councillor Lane      |        |            |            | X        |
| Councillor Russell   | X      |            |            |          |
| Councillor St Ledger | X      |            |            |          |
| Councillor Jackson   | X      |            |            |          |
| Councillor Hall      |        | X          |            |          |
| Councillor Frazer    |        |            |            | X        |
| Councillor Heremaia  |        | X          |            |          |
| Deputy Mayor Bannan  | X      |            |            |          |
| Councillor Stemp     | X      |            |            |          |
| Councillor Willcocks |        |            |            | X        |
| Councillor Murphy    | X      |            |            |          |
| Results              | 7      | 2          | 1          | 3        |

Carried (7 to 3)

Moved

Councillor Jackson

Seconded

Mayor Raven

1. That the recommendations as set out in the supplementary report titled 2026/27 Community Service Obligations as contained in Confidential Attachment 4 to this report, be endorsed for inclusion in the 2026/27 budget to be adopted by Council.
2. That the confidential attachment as attached to this report titled 2026/27 Budget – Proposed Annual Budget be deemed confidential and be treated as such in accordance with sections 171 and 200 of the Local Government Act 2009 and that the attachments remain confidential.
1. That the recommendations as set out in the supplementary report titled 2026/27 Interest on Overdue Rates and Charges as contained in Confidential Attachment 4 to this report, be endorsed for inclusion in the 2026/27 budget to be adopted by Council.
2. That the confidential attachment as attached to this report titled 2026/27 Budget – Proposed Annual Budget be deemed confidential and be treated as such in accordance with sections 171 and 200 of the Local Government Act 2009 and that the attachments remain confidential.

|                      | For    | Against    | Abstain          | Absent   |
|----------------------|--------|------------|------------------|----------|
| Mayor Raven          | X      |            |                  |          |
| Councillor Bradley   |        |            | X                |          |
| Councillor Lane      |        |            |                  | X        |
| Councillor Russell   | X      |            |                  |          |
| Councillor St Ledger | X      |            |                  |          |
| Councillor Jackson   | X      |            |                  |          |
| Councillor Hall      | X      |            |                  |          |
| Councillor Frazer    |        |            |                  | X        |
| Councillor Heremaia  |        | X          |                  |          |
| Deputy Mayor Bannan  | X      |            |                  |          |
| Councillor Stemp     | X      |            |                  |          |
| Councillor Willcocks |        |            |                  | X        |
| Councillor Murphy    | X      |            |                  |          |
| Results              | 8      | 1          | 1                | 3        |
|                      |        |            | Carried (8 to 1) |          |

Moved

Councillor Jackson

Seconded

Mayor Raven

|                      | For    | Against    | Abstain    | Absent   |
|----------------------|--------|------------|------------|----------|
| Mayor Raven          | X      |            |            |          |
| Councillor Bradley   |        |            | X          |          |
| Councillor Lane      |        |            |            | X        |
| Councillor Russell   | X      |            |            |          |
| Councillor St Ledger | X      |            |            |          |
| Councillor Jackson   | X      |            |            |          |
| Councillor Hall      | X      |            |            |          |
| Councillor Frazer    |        |            |            | X        |
| Councillor Heremaia  |        | X          |            |          |
| Deputy Mayor Bannan  | X      |            |            |          |
| Councillor Stemp     | X      |            |            |          |
| Councillor Willcocks |        |            |            | X        |
| Councillor Murphy    | X      |            |            |          |
| Results              | 8      | 1          | 1          | 3        |

Carried (8 to 2)

Moved

Mayor Raven

Seconded

Councillor Jackson

1. That the recommendations as set out in the supplementary report titled 2026/27 Councillor Transportation Allowances as contained in Confidential Attachment 4 to this report, be endorsed for inclusion in the 2026/27 budget to be adopted by Council.
2. That the confidential attachment as attached to this report titled 2026/27 Budget – Proposed Annual Budget be deemed confidential and be treated as such in accordance with sections 171 and 200 of the Local Government Act 2009 and that the attachments remain confidential.

|                      | For    | Against    | Abstain    | Absent   |
|----------------------|--------|------------|------------|----------|
| Mayor Raven          | X      |            |            |          |
| Councillor Bradley   |        |            | X          |          |
| Councillor Lane      |        |            |            | X        |
| Councillor Russell   | X      |            |            |          |
| Councillor St Ledger | X      |            |            |          |
| Councillor Jackson   | X      |            |            |          |
| Councillor Hall      |        | X          |            |          |
| Councillor Frazer    |        |            |            | X        |
| Councillor Heremaia  |        | X          |            |          |
| Deputy Mayor Bannan  | X      |            |            |          |
| Councillor Stemp     | X      |            |            |          |
| Councillor Willcocks |        |            |            | X        |
| Councillor Murphy    | X      |            |            |          |
| Results              | 7      | 2          | 1          | 3        |

Carried (7 to 3)

Moved

Mayor Raven

Seconded

Councillor Jackson

1. That subject to the amendments outlined within the confidential attachment as tabled to this meeting, the recommendations as set out in the supplementary report titled 2026/27 Councillor Divisional Expense Budgets as contained in Confidential Attachment 4 to this report, be endorsed for inclusion in the 2026/27 budget to be adopted by Council.
2. That the confidential attachment as attached to this report titled 2026/27 Budget – Proposed Annual Budget be deemed confidential and be treated as such in accordance with sections 171 and 200 of the Local Government Act 2009 and that the attachments remain confidential.
1. That the recommendations as set out in the supplementary report titled Underwood Innovation Lab Pty Ltd (UiLab) as contained in Confidential Attachment 4 to this report, be endorsed for inclusion in the 2026/27 budget to be adopted by Council.
2. That the confidential attachments as attached to this report titled 2026/27 Budget – Proposed Annual Budget be deemed confidential and be treated as such in accordance with sections 171 and 200 of the Local Government Act 2009 and that the attachments remain confidential.

|                                                         | For                 | Against             | Abstain          | Absent           |
|---------------------------------------------------------|---------------------|---------------------|------------------|------------------|
| Mayor Raven                                             | X                   |                     |                  |                  |
| Councillor Bradley  Councillor Lane  Councillor Russell | X                   |                     | X                | X                |
| Councillor St Ledger  Councillor Jackson                | X X                 |                     |                  |                  |
| Councillor Hall                                         | X                   |                     |                  |                  |
| Councillor Frazer                                       |                     |                     |                  | X                |
| Councillor Heremaia                                     |                     | X                   |                  |                  |
| Deputy Mayor Bannan  Councillor Stemp                   | X                   |                     |                  |                  |
|                                                         | X                   |                     |                  |                  |
| Councillor Willcocks                                    |                     |                     |                  |                  |
|                                                         |                     |                     |                  | X                |
| Councillor Murphy                                       | X                   |                     |                  |                  |
| Results                                                 | 8                   | 1                   | 1                | 3                |
|                                                         |                     |                     | Carried (8 to 1) | Carried (8 to 1) |
| Moved                                                   | Mayor Raven         |                     |                  |                  |
| Seconded                                                | Deputy Mayor Bannan | Deputy Mayor Bannan |                  |                  |

|                      | For    | Against    | Abstain    | Absent   |
|----------------------|--------|------------|------------|----------|
| Mayor Raven          | X      |            |            |          |
| Councillor Bradley   |        | X          |            |          |
| Councillor Lane      |        |            |            | X        |
| Councillor Russell   | X      |            |            |          |
| Councillor St Ledger | X      |            |            |          |
| Councillor Jackson   | X      |            |            |          |
| Councillor Hall      | X      |            |            |          |
| Councillor Frazer    |        |            |            | X        |
| Councillor Heremaia  |        | X          |            |          |
| Deputy Mayor Bannan  | X      |            |            |          |
| Councillor Stemp     |        |            | X          |          |
| Councillor Willcocks |        |            |            | X        |
| Councillor Murphy    | X      |            |            |          |
| Results              | 7      | 2          | 1          | 3        |

Carried (7 to 2)

Councillor Heremaia provided the following reason for voting against the motion:

" The reason why I am voting against this motion today is because I think we need to review this organisation and of course its long-term financial projection. We saw that the Townsville City Council involved innovation subsidiary is facing closure from the Council according to media reports from 2 days ago due to financial changes so I think that when financial forecasts may change, we should step back, pause , and say do we want to continue investing or support organisations. "

Councillor Stemp provided the following reason for abstaining from voting:

"I "I am abstaining and seeking additional information at this time."

Moved

Mayor Raven

Seconded

Councillor Jackson

1. That the recommendations as set out in the supplementary report titled City of Logan Charitable Trust as contained in Confidential Attachment 4 to this report, be endorsed for inclusion in the 2026/27 budget to be adopted by Council.
2. That the confidential attachments as attached to this report titled 2026/27 Budget – Proposed Annual Budget be deemed confidential and be treated as such in accordance with sections 171 and 200 of the Local Government Act 2009 and that the attachments remain confidential.

|                      | For    | Against    | Abstain *        | Absent   |
|----------------------|--------|------------|------------------|----------|
| Mayor Raven          | X      |            |                  |          |
| Councillor Bradley   |        | X          |                  |          |
| Councillor Lane      |        |            |                  | X        |
| Councillor Russell   |        | X          |                  |          |
| Councillor St Ledger | X      |            |                  |          |
| Councillor Jackson   | X      |            |                  |          |
| Councillor Hall      | X      |            |                  |          |
| Councillor Frazer    |        |            |                  | X        |
| Councillor Heremaia  |        | X          |                  |          |
| Deputy Mayor Bannan  | X      |            |                  |          |
| Councillor Stemp     |        |            | X                |          |
| Councillor Willcocks |        |            |                  | X        |
| Councillor Murphy    | X      |            |                  |          |
| Results              | 6      | 3          | 1                | 3        |
|                      |        |            | Carried (6 to 4) |          |

Councillor Heremaia provided the following reason for voting against the motion:

"I "I proposed an idea regarding how we can make sure this subsidiary can be financially independent while having consistent cash flow and saving Council operational expenses I think that idea should be seriously looked into instead of other financial plans because I think it will actually be a better base for the subsidiary to really succeed and launch off. f. "

Councillor Stemp provided the following reason for abstaining from voting:

"I "I am also seeking additional information."

Moved

Mayor Raven

Seconded

Deputy Mayor Bannan

1. That subject to the amendments outlined within the confidential attachment, as tabled to this meeting, the Executive Leadership Team recommendations for the Investment Proposals Strategic Business Cases as contained in Confidential Attachment 5 to this report, be endorsed for inclusion in the 2026/27 budget to be adopted by Council.
2. That the confidential attachment as attached to this report titled 2026/27 Budget – Proposed Annual Budget be deemed confidential and be treated as such in accordance with sections 171 and 200 of the Local Government Act 2009 and that the attachments remain confidential.

|                      | For    | Against    | Abstain    | Absent   |
|----------------------|--------|------------|------------|----------|
| Mayor Raven          | X      |            |            |          |
| Councillor Bradley   |        |            | X          |          |
| Councillor Lane      |        |            |            | X        |
| Councillor Russell   | X      |            |            |          |
| Councillor St Ledger | X      |            |            |          |
| Councillor Jackson   | X      |            |            |          |
| Councillor Hall      | X      |            |            |          |
| Councillor Frazer    |        |            |            | X        |
| Councillor Heremaia  |        | X          |            |          |
| Deputy Mayor Bannan  | X      |            |            |          |
| Councillor Stemp     | X      |            |            |          |
| Councillor Willcocks |        |            |            | X        |
| Councillor Murphy    | X      |            |            |          |
| Results              | 8      | 1          | 1          | 3        |

Moved

Mayor Raven

Seconded

Councillor Jackson

1. That the proposed 2026/27 capital expenditure and 10-year capital program as contained in Confidential Attachment 6 to this report, be endorsed for inclusion in the 2026/27 budget to be adopted by Council .
2. That the confidential attachment as attached to this report titled 2026/27 Budget – Proposed Annual Budget be deemed confidential and be treated as such in accordance with sections 171 and 200 of the Local Government Act 2009 and that the attachments remain confidential.

|                      | For    | Against    | Abstain          | Absent           |
|----------------------|--------|------------|------------------|------------------|
| Mayor Raven          | X      |            |                  |                  |
| Councillor Bradley   |        |            | X                |                  |
| Councillor Lane      |        |            |                  | X                |
| Councillor Russell   | X      |            |                  |                  |
| Councillor St Ledger | X      |            |                  |                  |
| Councillor Jackson   | X      |            |                  |                  |
| Councillor Hall      | X      |            |                  |                  |
| Councillor Frazer    |        |            |                  | X                |
| Councillor Heremaia  |        | X          |                  |                  |
| Deputy Mayor Bannan  | X      |            |                  |                  |
| Councillor Stemp     |        |            | X                |                  |
| Councillor Willcocks |        |            |                  | X                |
| Councillor Murphy    | X      |            |                  |                  |
| Results              | 7      | 1          | 2                | 3                |
|                      |        |            | Carried (7 to 3) | Carried (7 to 3) |

Councillor Stemp provided the following reason for abstaining from voting:

"S "Seeking additional information."

Moved

Deputy Mayor Bannan

Seconded

Councillor Jackson

That the confidential attachments as attached to this report titled 2026/27 Budget – Proposed Annual Budget be deemed confidential and be treated as such in accordance with sections 171 and 200 of the Local Government Act 2009 and that the attachments remain confidential.

|                      | For    |   Against  | Abstain    | Absent   |
|----------------------|--------|------------|------------|----------|
| Mayor Raven          | X      |            |            |          |
| Councillor Bradley   |        |            | X          |          |
| Councillor Lane      |        |            |            | X        |
| Councillor Russell   | X      |            |            |          |
| Councillor St Ledger | X      |            |            |          |
| Councillor Jackson   | X      |            |            |          |
| Councillor Hall      | X      |            |            |          |
| Councillor Frazer    |        |            |            | X        |
| Councillor Heremaia  | X      |            |            |          |
| Deputy Mayor Bannan  | X      |            |            |          |
| Councillor Stemp     | X      |            |            |          |
| Councillor Willcocks |        |            |            | X        |
| Councillor Murphy    | X      |            |            |          |
| Results              | 9      |          0 | 1          | 3        |

Carried (9 to 0)

## 6. Late Reports

There were no late reports to discuss.

## 7. Budget Communication

## 8. General Business

There were no general business matters to vote on.

The meeting concluded at 3:50 pm.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

Chairperson of the Special Budget Committee