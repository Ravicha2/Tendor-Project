## MINUTES OF PROCEEDINGS

The 4791 meeting of the Brisbane City Council, held at City Hall, Brisbane on Tuesday 12 May 2026 at 1pm

Prepared by: Council and Committee Liaison Office Governance, Council and Committee Services Governance and Legal Services

<!-- image -->

Based on the image provided, here is a description focusing on the requested elements:

This image is the official logo of the **Brisbane City Council**.

A detailed analysis based on your specific criteria reveals the following:

*   **Project Names:** There are no project names visible in the logo.
*   **Budget Figures:** There are no budget figures, dollar amounts, or financial data present.
*   **Locations:** The logo text explicitly names **"BRISBANE CITY"**. Furthermore, the central building depicted is a stylized representation of **Brisbane City Hall**, a key landmark located in King George Square in Brisbane's CBD.
*   **Procurement Indicators:** There are no tender numbers, contract details, or other procurement-related indicators visible.
*   **Council Decisions:** There is no information regarding council decisions, meeting minutes, or resolutions in the logo.

**In summary:**

The image is a corporate logo, a branding element designed for identification. It visually represents the Brisbane City Council through the stylized depiction of Brisbane City Hall and a palm tree, set against a blue background with the text "BRISBANE CITY". As a logo, its purpose is symbolic identity, and it does not contain specific operational data such as project names, budgets, procurement details, or council decisions.

## MINUTES OF PROCEEDINGS

<!-- image -->

Based on the image provided, here is a description focusing on the requested elements:

The image appears to be a fragment of a document header or letterhead, likely from the Brisbane City Council.

### **Detailed Analysis based on your criteria:**

*   **Project Names:** There are **no specific project names** visible in the image.
*   **Budget Figures:** There are **no budget figures** or any numerical data present.
*   **Locations:** The location is clearly identified as **Brisbane**. This is stated twice:
    *   In the logo at the base of the building: "**BRISBANE CITY**"
    *   In the tagline below: "Dedicated to a better **Brisbane**"
    The building in the logo is the iconic **Brisbane City Hall**.
*   **Procurement Indicators:** There are **no procurement indicators** such as tender numbers, contract details, or requests for proposal.
*   **Council Decisions:** There is **no text indicating any council decisions**, resolutions, or approvals.

### **General Description of the Visuals:**

*   **Logo:** On the left is the black and white logo for Brisbane City Council. It features a stylized representation of the Brisbane City Hall clock tower with a sunburst symbol to its right. The words "BRISBANE CITY" are at the bottom of the logo.
*   **Text:**
    *   To the right of the logo are the large, capitalized letters "**TH**" in a serif font, likely the beginning of a title or heading (e.g., "THE").
    *   Below the logo and heading is the council's tagline in an italic serif font: "**Dedicated to a better Brisbane**".

## THE 4791 MEETING OF THE BRISBANE CITY COUNCIL, HELD AT CITY HALL, BRISBANE, ON TUESDAY 12 MAY 2026 AT 1PM

## TABLE OF CONTENTS

| TABLE OF CONTENTS  _____________________________________________________________                | TABLE OF CONTENTS  _____________________________________________________________                                                                                                                                                                       | i                                                                             |
|-------------------------------------------------------------------------------------------------|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|-------------------------------------------------------------------------------|
| PRESENT  ______________________________________________________________________                 | PRESENT  ______________________________________________________________________                                                                                                                                                                        | 1                                                                             |
| OPENING OF MEETING  ___________________________________________________________                 | OPENING OF MEETING  ___________________________________________________________                                                                                                                                                                        | 1                                                                             |
| APOLOGIES  ____________________________________________________________________                 | APOLOGIES  ____________________________________________________________________                                                                                                                                                                        | 1                                                                             |
| MINUTES                                                                                         | MINUTES                                                                                                                                                                                                                                                | 1                                                                             |
| PUBLIC PARTICIPATION  __________________________________________________________                | PUBLIC PARTICIPATION  __________________________________________________________                                                                                                                                                                       | 2                                                                             |
| QUESTION TIME  ________________________________________________________________                 | QUESTION TIME  ________________________________________________________________                                                                                                                                                                        | 3                                                                             |
| CONSIDERATION OF RECOMMENDATIONS OF THE ESTABLISHMENT AND COORDINATION  COMMITTEE DURING RECESS | CONSIDERATION OF RECOMMENDATIONS OF THE ESTABLISHMENT AND COORDINATION  COMMITTEE DURING RECESS                                                                                                                                                        | 14                                                                            |
| ESTABLISHMENT AND COORDINATION COMMITTEE (Adoption report)  ___________________________         | ESTABLISHMENT AND COORDINATION COMMITTEE (Adoption report)  ___________________________                                                                                                                                                                | 14                                                                            |
| A                                                                                               | REPORT OF CONTRACTS ACCEPTED BY DELEGATES OF COUNCIL FOR MARCH 2026                                                                                                                                                                                    | 48                                                                            |
| B                                                                                               | ___________ AMENDMENTS TO BRISBANE CITY PLAN 2014  –  WYNNUM CENTRE SUBURBAN RENEWAL  PRECINCT                                                                                                                                                         |                                                                               |
| C                                                                                               | REPORT OF THE AUDIT COMMITTEE MEETING ON 2 APRIL 2026 ___________________________                                                                                                                                                                      | _______________________________________________________________________ 49 50 |
| NOTATION OF DECISIONS OF THE ESTABLISHMENT AND COORDINATION COMMITTEE AS  DELEGATE OF COUNCIL   | NOTATION OF DECISIONS OF THE ESTABLISHMENT AND COORDINATION COMMITTEE AS  DELEGATE OF COUNCIL                                                                                                                                                          | 51                                                                            |
| __________________________________________________________                                      | __________________________________________________________                                                                                                                                                                                             |                                                                               |
| ESTABLISHMENT AND COORDINATION COMMITTEE (Information report)  _________________________        | ESTABLISHMENT AND COORDINATION COMMITTEE (Information report)  _________________________                                                                                                                                                               | 51                                                                            |
| A                                                                                               | NEW SISTER CITY  –  CITY OF LOS ANGELES, UNITED STATES OF AMERICA  ____________________                                                                                                                                                                | 61                                                                            |
| INFRASTRUCTURE COMMITTEE  ___________________________________________________________           | INFRASTRUCTURE COMMITTEE  ___________________________________________________________                                                                                                                                                                  | 62                                                                            |
| A                                                                                               | PETITION  –  REQUESTING COUNCIL IMPROVE LOCAL INFRASTRUCTURE ALONG ALGESTER ROAD  AND BENHIAM AND ORMSKIRK STREETS, CALAMVALE, AND SURROUNDING AREAS PETITION  –                                                                                       | 63                                                                            |
| B                                                                                               | ___________ REQUESTING COUNCIL INSTALL A PEDESTRIAN CROSSING OUTSIDE MORETON BAY  COLLEGE ON WONDALL ROAD, MANLY WEST __________________________________________                                                                                       | 65                                                                            |
| C                                                                                               | PETITION  –  REQUESTING COUNCIL CONSTRUCT A PEDESTRIAN OVERPASS FROM WESTFIELD  MT GRAVATT SHOPPING CENTRE ACROSS LOGAN ROAD, UPPER MT GRAVATT  _______________ –                                                                                      | 67                                                                            |
| D                                                                                               | PETITION  REQUESTING COUNCIL CONSTRUCT MISSING FOOTPATH SECTIONS ALONG RITCHIE  AND GOODERHAM ROADS, AND INSTALL 2 PEDESTRIAN CROSSINGS ON RITCHIE ROAD, PALLARA                                                                                       | _ 68                                                                          |
| E                                                                                               | PETITION  –  REQUESTING COUNCIL REVIEW PEDESTRIAN ACCESS BETWEEN HARRIER STREET AND  MILES PLATTING ROAD, ROCHEDALE  _________________________________________________                                                                                 | 71                                                                            |
| F  G                                                                                            | PETITION  –  REQUESTING COUNCIL ALLOCATE FUNDING TO RESTORE THE STORY BRIDGE AND  KEEP THE STORY BRIDGE TOLL FREE  _________________________________________________ PETITION  –  REQUESTING COUNCIL INSTALL SAFETY IMPROVEMENTS AT THE ZEBRA CROSSING | 73                                                                            |
|                                                                                                 | ON LOGAN ROAD NEAR GLINDEMANN PARK, HOLLAND PARK WEST  _______________________ –                                                                                                                                                                       | 74                                                                            |
| H                                                                                               | PETITION  REQUESTING COUNCIL INSTALL PEDESTRIAN CROSSING IMPROVEMENTS ON CLIVE  STREET AT THE INTERSECTION OF IPSWICH ROAD, ANNERLEY  ____________________________                                                                                     | 76                                                                            |
| I                                                                                               | PETITION  –  REQUESTING COUNCIL INSTALL TRAFFIC SIGNALS AT THE INTERSECTION OF  LEVINGTON AND UNDERWOOD ROADS, EIGHT MILE PLAINS ______________________________                                                                                        | 78                                                                            |
| J                                                                                               | PETITION  –  REQUESTING COUNCIL IMPLEMENT TRAFFIC CALMING DEVICES ON THE PARKWAY,  STRETTON  ______________________________________________________________________                                                                                    | 79                                                                            |
| K                                                                                               | PETITION  –  REQUESTING COUNCIL INSTALL A TEMPORARY PEDESTRIAN CROSSING AND OTHER  SAFETY MEASURES ON SYLVAN ROAD, TOOWONG                                                                                                                             | _____________________________________ 81                                      |

## MINUTES OF PROCEEDINGS

<!-- image -->

Based on the image provided, here is a description focusing on the requested elements:

The image appears to be a header or a portion of a document from the Brisbane City Council.

*   **Location:** The location "Brisbane" is clearly identified. The logo contains the text "BRISBANE CITY", and the tagline below reads, "Dedicated to a better Brisbane".

*   **Other Information:** The image contains the Brisbane City Council logo, which features a stylized depiction of Brisbane City Hall. The letters "TH" are visible in large font.

There are no **project names, budget figures, procurement indicators, or council decisions** visible in this image fragment.

## THE 4791 MEETING OF THE BRISBANE CITY COUNCIL, HELD AT CITY HALL, BRISBANE, ON TUESDAY 12 MAY 2026 AT 1PM

| L                                                                                      | PETITION  –  REQUESTING COUNCIL IMPROVE CROSSING FACILITIES ON ERIC CRESCENT ADJACENT  TO MACKENZIE PLACE PARK, ANNERLEY                                                         | ______________________________________________ 83                  |
|----------------------------------------------------------------------------------------|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|--------------------------------------------------------------------|
| CITY PLANNING, SUBURBAN RENEWAL AND ECONOMIC DEVELOPMENT COMMITTEE  _______________    | CITY PLANNING, SUBURBAN RENEWAL AND ECONOMIC DEVELOPMENT COMMITTEE  _______________                                                                                              | 84                                                                 |
| A                                                                                      | PETITION  –  REQUESTING COUNCIL REJECT PROPOSED DEVELOPMENTS AT 188 GRAHAM ROAD  (A006638485) AND 206 GRAHAM ROAD (A006724928), BRIDGEMAN DOWNS  _______________                 | 85                                                                 |
| B                                                                                      | PETITION  –  REQUESTING COUNCIL REJECT THE PROPOSED DEVELOPMENT AT 405 AND 407  BECKETT ROAD, BRIDGEMAN DOWNS (A006547920), AND RETAIN THE ECOLOGICAL CORRIDOR 87                |                                                                    |
| ENVIRONMENT, PARKS AND SUSTAINABILITY COMMITTEE  _____________________________________ | ENVIRONMENT, PARKS AND SUSTAINABILITY COMMITTEE  _____________________________________                                                                                           | 89                                                                 |
| A                                                                                      | PETITION  –  REQUESTING COUNCIL ESTABLISH A PLAQUE OR SIGN TO FORMALLY RECOGNISE  PATRICIA LESINA FOR HER WORK TO MAINTAIN LAND ADJACENT TO STABLE SWAMP CREEK,  SUNNYBANK HILLS | _______________________________________________________________ 89 |
| B                                                                                      | PETITION  –  REQUESTING COUNCIL PROMOTE YOUTH CULTURE BY EXPANDING THE SKATE PARK  WITHIN WALLY TATE PARK, KURABY  _________________________________________________             | 91                                                                 |
| CUSTOMER SERVICES COMMITTEE  ________________________________________________________  | CUSTOMER SERVICES COMMITTEE  ________________________________________________________                                                                                            | 92                                                                 |
| A                                                                                      | PETITION  –  REQUESTING COUNCIL INVESTIGATE ALLEGED UNLAWFUL BUSINESS ACTIVITY AND  PUBLIC NUISANCE AT 54 WEAVER STREET, COOPERS PLAINS                                          | _____________________________ 92                                   |
| PRESENTATION OF PETITIONS  ____________________________________________________        | PRESENTATION OF PETITIONS  ____________________________________________________                                                                                                  | 95                                                                 |
| GENERAL BUSINESS  ____________________________________________________________         | GENERAL BUSINESS  ____________________________________________________________                                                                                                   | 95                                                                 |
| QUESTIONS OF WHICH DUE NOTICE HAS BEEN GIVEN  ________________________________         | QUESTIONS OF WHICH DUE NOTICE HAS BEEN GIVEN  ________________________________                                                                                                   | 108                                                                |

## MINUTES OF PROCEEDINGS

<!-- image -->

Based on the image provided, here is a description focusing on the requested elements:

The image displays a logo and slogan for the **Brisbane City Council**.

*   **Location:** The location identified is **Brisbane**. The logo itself features a well-known landmark, the **Brisbane City Hall**, and the text within the logo reads "BRISBANE CITY". The slogan below is "Dedicated to a better Brisbane".

There are no project names, budget figures, procurement indicators, or specific council decisions visible in this image snippet. The image appears to be from a document or publication by the Brisbane City Council.

## PRESENT

The Right Honourable , the LORD MAYOR (Councillor Adrian SCHRINNER) – LNP The Chair of Council (Chair), Councillor Sandy LANDERS (Bracken Ridge) – LNP

## LNP Councillors (and Wards)

## ALP Councillors (and Wards)

Fiona CUNNINGHAM (Coorparoo) (Deputy Mayor)

Krista ADAMS (Holland Park) Greg ADERMANN (Pullenvale) Adam ALLAN (Northgate) Lisa ATWOOD (Doboy) Tracy DAVIS (McDowall) Julia DIXON (Hamilton) Alex GIVNEY (Wynnum Manly) Vicki HOWARD (Central) Steven HUANG (MacGregor) (Deputy Chair of Council) Sarah HUTTON (Jamboree) Kim MARX (Runcorn) Ryan MURPHY (Chandler) Danita PARRY (Marchant) Steven TOOMEY (The Gap)

Andrew WINES (Enoggera)

Penny WOLFF (Walter Taylor)

Jared CASSIDY (Deagon) (The Leader of the

Opposition) Lucy COLLIER (Morningside) (Deputy Leader of the Opposition) Steve GRIFFITHS (Moorooka) Emily KIM (Calamvale)

Charles STRUNK (Forest Lake)

## Queensland Greens Councillors (and Wards)

Seal CHONG WAH (Paddington)

Trina MASSEY (The Gabba)

Independent Councillor (and Ward)

Nicole JOHNSTON (Tennyson)

## OPENING OF MEETING

The Chair opened the meeting with prayer and acknowledged the traditional custodians, then proceeded with the business set out in the Agenda.

Chair:

## APOLOGIES

Chair:

Are there any apologies?

## MINUTES

Chair:

Confirmation of minutes, please .

I declare the meeting open and I remind all Councillors of your obligations to declare prescribed and/or declarable conflicts of interest where relevant, and the requirement of such to remove yourself from the Council Chamber for debate and voting where applicable.

## THE 4791 MEETING OF THE BRISBANE CITY COUNCIL, HELD AT CITY HALL, BRISBANE, ON TUESDAY 12 MAY 2026 AT 1PM

596/2025 -26

The Minutes of the 4790 (Ordinary) meeting held on 17 March 2026, copies of which had been forwarded to each Councillor, were presented, taken as read and confirmed on the motion of Councillor Julia DIXON, seconded by Councillor Greg ADERMANN .

## PUBLIC PARTICIPATION

Chair:

I would now like to call on Ms Mia Bannister, who will be addressing the Chamber regarding building safer, kinder communities for Brisbane's youth.

Hello, Ms Bannister. You can either sit or stand, whatever you're comfortable with. You've got 5 minutes whenever you start.

## Ms Mia Bannister – Ollie's Echo

Ms Mia Bannister:

Madam Chair, LORD MAYOR and Councillors, thank you for the opportunity to address Council today. My name is Mia Bannister and I'm the founder of Ollie's Echo: Pathways to Prevention Limited, a national charity established in memory of my son, Ollie Hughes. Oliver Bailey Hughes was born on 21 January 2009. He was beautiful, sensitive, fiercely creative and incredibly funny. He had a mop of red curls that became his trademark, curls he wore like a crown. He loved music, saw the world through a unique lens and felt things deeply.

On 9 January 2024, 854 days ago today, I came home to find that my son, my only child, had taken his own life. He was only 14. Ollie was diagnosed and hospitalised with anorexia nervosa on 8 December 2023. It was an illness most people still do not associate with boys. But Ollie's story was not only about anorexia; it was also about bullying, mental health challenges and the online environment our children are growing up in, an environment that too often exposes them to harm before they have the tools, maturity or support to make sense of it.

There is no preparing for that kind of heartbreak, but in the depths of grief there came a quiet, unwavering knowing that something had to change. Ollie's story could not end there, and so Ollie's Echo was born. Ollie's Echo is not just a charity, it's a movement, a call to action, a promise that we will speak out, change the narrative and create earlier pathways to prevention for young people and families. Our work focuses on eating disorders, bullying, mental health challenges and the impact of the online world, because for many young people, these issues do not sit neatly in separate boxes. They overlap, they compound and too often, they go unseen until it's too late.

In less than 12 months, we have addressed more than 3,500 students across Years 7 to 12. We have spoken in schools, at conferences, in community forums and in national conversations about people's mental health, body image, eating disorders, kindness, bullying and digital wellbeing. On 30 July last year, I was part of a national conversation addressing the media alongside the Prime Minister, where I spoke about the urgent need to better protect young people in the online world.

In our first 5 months of operation, Ollie's Echo raised approximately $175,000, a powerful sign that this community understands the need and wants to be part of the solution. We are now building school toolkits, parent and carer resources, educator guides and community programs designed to help people act earlier before a young person reaches crisis. This is where local government matters.

Brisbane City Council (BCC) is deeply connected to the communities we are trying to reach: families, schools, sporting clubs, libraries, community centres, neighbourhood groups and young people across every ward. Prevention happens in communities, not in hospitals or clinical settings. It happens when a parent hears something that helps them ask a different question. It happens when a teacher notices a quiet change. It happens when a coach understands that overtraining may not be discipline but distress. It happens when a young person hears early enough that they are not alone.

Today, I'm asking Council to recognise Ollie's Echo as a Brisbane-born charity working to protect and support young people through early intervention, education, kindness and advocacy. I would welcome opportunities to work with Council to share our resources through community networks, libraries, youth programs, schools, sporting clubs and local events. Because if we are serious about prevention, we have to meet young people where they are and today, where they are is both offline and online.

Chair:

Too many young people are falling through the cracks, misunderstood, misdiagnosed or missed entirely. We cannot keep waiting until it's too late. We owe our children more than that. I owe Ollie more than that. Ollie's Echo exists so that every young person feels seen, heard and supported before crisis hits and so that parents, carers, educators and communities feel equipped to act, not helpless. Thank you for giving me the opportunity to share Ollie's story today. For Ollie and all the young people whose struggles are still unseen, we must keep building pathways to prevention. Ollie was 14. His life mattered.

Thank you, Ms Bannister.

I'm going to call upon Councillor HOWARD to respond.

## Response by Councillor Vicki HOWARD , Civic Cabinet Chair of the Community and the Arts Committee

Councillor HOWARD:

Chair:

## QUESTION TIME

Chair:

Councillor ADERMANN:

Chair:

LORD MAYOR:

Mia, I don't really know where to begin because I think that everybody in this Chamber is so moved by your presentation, so we really want to thank you. I do have responsibility for communities across Brisbane and I'll be absolutely thrilled to talk to you after the meeting to work out how we can work closer together. I know how incredibly difficult it must be for you to talk about Ollie, but what a beautiful, beautiful memory of him you have created.

I think everyone in this Chamber has experiences, not particularly like yours, but we very much work with organisations across the city and we know how important it is that people , like you , are brave enough to take that step to set up an organisation which is going to be so important for other young people. I have a 14 -year -old granddaughter, so your words absolutely resonated with me. I know that Councillor Danita PARRY has worked very closely with you and she's an absolute gem. I know that any support that you need, not only from her but from everyone, every single person in this Chamber, we are all very willing to support.

Between all of us, we represent all across Brisbane and so your story here today has made such a difference to each and every one of us and I know that each and every one of us will do everything we can to support you. I look forward to catching up with you so that we can work out how we can do that a little bit more, but can I just finish by saying thank you, thank you for being so brave to talk to us today.

Thank you so much, Ms Bannister. Thank you.

Councillors, are there any questions of the LORD MAYOR or a Civic Cabinet Chair of any of the Standing Committees?

Councillor ADERMANN.

Question 1

Yes, thank you, Chair. My question is to the LORD MAYOR.

LORD MAYOR, the Federal Government has foreshadowed sweeping changes to the way that they tax the property market over the coming years. Can you please update the Chamber on whether this will have any impact on our proposal for a short -stay accommodation permit scheme?

LORD MAYOR.

Thank you, Councillor ADERMANN, and absolutely, yes, it will, I can confirm. So we know that there's a housing shortage, not only in Brisbane but right across the nation. There's a housing shortage in other cities, other capital cities. There's a housing shortage in other councils around us, and we're certainly doing what we can to increase the supply of new housing. We control some of the levers, but not all of them. We know that what is being discussed in recent days and weeks about changes to Federal taxation relating to housing investment has certainly created a high level of uncertainty in the market. So, we will all find out tonight the details of what is proposed, but I think only time will tell the impacts of what is proposed and whether they will be good or whether they will be retrograde.

Chair:

LORD MAYOR:

Councillors interjecting.

Chair:

There's certainly a lot of speculation on whether that will be one or the other, but we know that in this kind of environment, creating more regulation, more red tape and making housing investment even harder is not something we should be doing in this current situation of uncertainty. Now, back in 2023, we established a Short -Stay Accommodation Taskforce to look closely at community concerns around short -stay accommodation. This included concerns about security, overcrowding, antisocial behaviour. The taskforce considered those issues carefully and in 2024, a report recommended a permit scheme for short-stay accommodation providers.

Officers have drafted a proposal on that and in recent times, we undertook consultation with the community and with industry on that. The consultation was very helpful and it was very instructive as well. Consultation revealed that short -stay accommodation services provide a broader purpose over and above tourism. Users are not necessarily people on holidays. We discovered that some short -stay accommodation or short-term rentals provide temporary accommodation for people escaping domestic and family violence.

Some short -term rentals support families who have been displaced by fire, flood or other insurance works while their home is repaired. We've discovered that some short -term rentals provide accommodation for hospital patients and their families needing to stay close to medical care and services. Some short-stay rentals provide accommodation for workers in parts of the city where there are limited hotels— close to the Port of Brisbane is one example. So, this is not a black and white issue. It requires a balanced response and we want to make sure we get that response right and that it is appropriate and doesn't actually contribute to a situation at the moment which has great uncertainty.

That situation has changed significantly since 2023 and even to this day, it continues to change. Something we've valued is the work that short-stay platforms have done to dramatically increase the management of their properties. Platforms like Airbnb have improved how they manage operators and problem guests. Since 2023, Airbnb has introduced stricter rules for hosts and guests and introduced new technology to identify and block high-risk party bookings to enforce their ban on parties. Airbnb also operate a 24/7 hotline for neighbours to report noise and antisocial behaviour, with problem operators able to be removed from their platform, and they are being removed from their platform.

Complaints to Council are also down. Brisbane is a city of more than 1.3 million residents and in the past 12 months, we received just 100 complaints relating to short -stay accommodation. We also know that less than one per cent of Brisbane homes are being used for short-term accommodation. Now, unlike the early years of this, I guess, disruptive technology and this platform, where we saw exponential growth, that situation has also changed. Growth has slowed down significantly and this is not just in the local market, it's a global trend. In Airbnb's major markets, their growth has slowed down and they're seeing declining growth. The Economist magazine recently covered this trend and it is, as I said, a global trend.

We don't want to add further uncertainty, so I can confirm today that we are not progressing with the permit scheme for short-term accommodation at this time. We want to make sure that there are more homes in the market, and adding uncertainty when investment already has a cloud over it is not the right thing to do at this time. You will not tax your way out of a housing crisis and you will not regulate your way out of a housing crisis—

LORD MAYOR, your time has expired.

— only building new homes will change this.

Thank you.

Councillors, I'll just remind everybody, Councillor STRUNK particularly, who was calling out, that you are to remain quiet while each Councillor is given the opportunity to speak without interruption.

Further speakers?

Councillor CASSIDY.

| Councillor CASSIDY:       | Thanks very much, Chair. My question is to the LORD MAYOR.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             |
|---------------------------|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Chair:                    | LORD MAYOR.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            |
| LORD MAYOR:               | I really wonder why Councillor CASSIDY is so down on the fantastic work that  Council staff do right across the city, a fantastic job that is appreciated by Brisbane  residents.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      |
| Councillors interjecting. |                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        |
| Chair:                    | One moment, please, LORD MAYOR. One moment. Your microphone.  Councillors will not call out while another Councillor is on their feet speaking.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        |
| LORD MAYOR:               | It is quite clear that Councillor CASSIDY does not appreciate the fantastic work  being done every single day out there making a better Brisbane, to make sure we  maintain our parks, make sure we pick up the rubbish, make sure we build new  footpaths and upgrade infrastructure, make sure we support the delivery of new  homes with planning changes that ensure that more homes are being built in the  right places, to make sure that we grasp hold of economic opportunities for our  city so that we can continue to experience improvements in our lifestyle. These  are all things that the people of Brisbane see very clearly that we are focused on. |
|                           | Now, Labor wants to create a narrative of doom and gloom. They have been saying  these things for a very, very long time. Time and time again, people see our  commitment to the City of Brisbane, our passion for making it better, our passion                                                                                                                                                                                                                                                                                                                                                                                                                       |
|                           | for investing in parks, for investing in transport, for investing in active transport,  for making sure we deliver the services that people expect. These are our priorities  and they have never changed. They will always remain our priorities and we are  absolutely passionate about the future of our city.                                                                                                                                                                                                                                                                                                                                                      |
|                           | We know, though, that Brisbane residents are also optimistic about our city and  they love living here. If Brisbane was the type of place that Councillor CASSIDY  suggests, why are hundreds of people every single week moving here, flocking                                                                                                                                                                                                                                                                                                                                                                                                                        |
|                           | Now, Councillor CASSIDY has talked about a visit. He’s talked about a visit that  came at no cost to ratepayers and he has claimed and misrepresented that  continually, a continual misrepresentation of the facts. This person—                                                                                                                                                                                                                                                                                                                                                                                                                                      |
| Councillors interjecting. |                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        |

## Question 2

Chair:

One moment, please, LORD MAYOR. Just your microphone, please.

Councillor GRIFFITHS, Councillor STRUNK, Councillor CASSIDY and Councillor COLLIER— R— all calling out and interrupting.

Councillor interjecting.

Chair:

Councillor GRIFFITHS, you did twice. I’ve asked you to—

Councillor interjecting.

Chair:

Councillor GRIFFITHS, don’t— t—

Councillor interjecting.

Chair:

Councillor, I caution you for unsuitable meeting conduct. It is my role to keep order in the meeting and it is not yours to yell out and abuse me. Do not do it, Councillor.

Councillor GRIFFITHS:

Point of order, Madam Chair.

Chair:

Point of order.

Councillor GRIFFRITHS:

It wasn’t abuse at all.

Chair:

Councillor.

Councillor GRIFFITHS:

I was just making the point that you’re the person in trouble.

Chair:

Councillor, again, stop bullying me and stop calling out. I—

Councillor GRIFFITHS:

Point of order, Madam Chair.

Chair:

It is not open for debate.

Councillor GRIFFITHS:

I did not bully you. I’m asking you to withdraw that comment. I did not bully you.

Chair:

Councillor, I consider that you are displaying—

Councillor GRIFFITHS:

I spoke to you. I did not bully you. I ask you to withdraw it.

Chair:

Thank you. Councillor, I consider that you are displaying unsuitable meeting conduct and in accordance with section 21(4) of the Meetings Local Law 2001, I hereby request you to stop doing it—stop calling out, interrupting and also bullying me.

LORD MAYOR.

LORD MAYOR:

Thank you, Madam Chair. It is clear that Councillor CASSIDY has no interest in a better Brisbane, has no interest in creating the partnerships that we can benefit from and learn from, especially if they come at zero cost to ratepayers, as my recent visit did. So this is quite clearly a really disappointing approach, but it is not surprising. I would simply say to Labor, I remember, Councillor CASSIDY, when you got up in the Chamber not too long ago and said that we should be travelling to make Olympic connections. He actually said that in this place. I’m happy to dig up the exact words, Madam Chair, if you like, and yet today he says something differently. It is disappointing, but it is not surprising—

Councillor interjecting.

Chair:

Councillor CASSIDY, I caution you, that is—

Councillors interjecting.

Chair:

Councillor CASSIDY, you are displaying unsuitable meeting conduct and in accordance with section 21(4) of the Meetings Local Law 2001, I hereby request that you stop calling out across the Chamber.

Councillor COLLIER, I consider you are displaying unsuitable meeting conduct and in accordance with section 21(4) of the Meetings Local Law 2001, I hereby request you to stop calling out and interjecting.

Councillor JOHNSTON:

Point of order.

Chair:

Point of order, Councillor JOHNSTON.

| Councillor JOHNSTON:      | Madam Chair, just a clarification on your ruling that Councillors are calling out  across the Chamber. So, there was a bit of discussion between Councillor  COLLIER and CASSIDY, which was just discussion. There was no calling out; I  could barely hear it. You know what stuffs up things more than anything—   |
|---------------------------|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Chair:                    | Councillor, thank you.                                                                                                                                                                                                                                                                                               |
| Councillor JOHNSTON:      | — is when a referee in a football game calls out every tiny little infraction and  stuffs up the run of play.                                                                                                                                                                                                        |
| Chair:                    | I don’t uphold your point of order, Councillor JOHNSTON. I am not going to  debate this with you.                                                                                                                                                                                                                    |
| Councillor JOHNSTON:      | So why are you nitpicking on the rules?                                                                                                                                                                                                                                                                              |
| Chair:                    | You continue to do this every meeting. You know the rules. You know how the  Chamber operates and it is not your place to determine how it runs.                                                                                                                                                                     |
|                           | Further questions?                                                                                                                                                                                                                                                                                                   |
|                           | Councillor HUANG.                                                                                                                                                                                                                                                                                                    |
| Councillor JOHNSTON:      | Point of order. I’m sorry.                                                                                                                                                                                                                                                                                           |
| Councillor HUANG:         | Thank you, Madam Chair.                                                                                                                                                                                                                                                                                              |
| Councillor JOHNSTON:      | I did ask a— a—                                                                                                                                                                                                                                                                                                      |
| Chair:                    | I have not called you, Councillor. If it’s the same point of order, don’t repeat it.                                                                                                                                                                                                                                 |
|                           | Point of order.                                                                                                                                                                                                                                                                                                      |
| Councillor JOHNSTON:      | Well, Madam Chairman, I did ask for a ruling about what is discussion versus  what is calling out—                                                                                                                                                                                                                   |
| Chair:                    | My ruling is I do not uphold your point of order.                                                                                                                                                                                                                                                                    |
| Councillor JOHNSTON:      | Is it okay if I—                                                                                                                                                                                                                                                                                                     |
| Chair:                    | That’s it, straight and simple.                                                                                                                                                                                                                                                                                      |
| Councillor JOHNSTON:      | Is it okay if I finish my sentence?                                                                                                                                                                                                                                                                                  |
| Chair:                    | No, I am not— t—                                                                                                                                                                                                                                                                                                     |
| Councillor JOHNSTON:      | Or is that not bullying? I mean, I’d just like to finish my sentence every now and  then.                                                                                                                                                                                                                            |
| Chair:                    | Councillor JOHNSTON, I do not uphold your point of order.  Councillor HUANG.                                                                                                                                                                                                                                         |
| Councillor HUANG:         | Thank you, Madam Chair. My question is to the DEPUTY MAYOR.  DEPUTY MAYOR, today the Albanese Government will hand down its  fifth Federal Budget and we all want to know what’s in it for Brisbane. Can you  please outline to the Chamber what changes we hope to see as part of today’s  budget?                  |
| Chair:                    | DEPUTY MAYOR.                                                                                                                                                                                                                                                                                                        |
| DEPUTY MAYOR:             | Thank you, Madam Chair, and through you, I thank Councillor HUANG for the  question. I know that Councillor HUANG is very interested in the Federal Budget,  not only, of course, as the Deputy Finance Chair, but also as the Councillor for  one of Brisbane’s fastest growing areas in MacGregor Ward.            |
| Councillors interjecting. |                                                                                                                                                                                                                                                                                                                      |
| Chair:                    | One moment, please, DEPUTY MAYOR. One moment, please. Touch your  microphone.  Councillor COLLIER, as you have failed to comply with the request to take  remedial action for your unsuitable meeting conduct, I hereby warn you, in                                                                                 |
|                           | accordance with section 21(6) of the Meetings Local Law 2001 that failing to  comply with the request may result in an order being issued.                                                                                                                                                                           |

DEPUTY MAYOR:

Chair:

## DEPUTY MAYOR.

Now MacGregor Ward, like a lot of places in Brisbane, is a place where infrastructure demand is certainly growing. We're doing our bit to deliver the services that are needed to cater to recent development and unlock more land for housing. But as councils collect just 3 cents in every tax dollar, we can't do it alone. We've partnered with the State Government to deliver the Gardner Road extension through the Residential Activation Fund. That assistance is certainly welcome, but we need investment like this right across the city. It is the Federal Government, not the State Government, who collects the biggest share of the Australian tax dollar, 81 cents.

Today, we find out how they're planning to spend it. Whatever else comes out of today's budget, we will continue to advocate for the funding that Brisbane needs. Even with hundreds of people moving here every week, Federal infrastructure investment in Brisbane has fallen behind other state capitals. In our Federal Budget submission, we have outlined a practical and deliverable pipeline of projects that will keep Brisbane moving as we grow and ensure that we are Games (Brisbane 2032 Olympic and Paralympic Games) ready. Through this partnership, we're already progressing key initiatives, including a $50 million business case to expand the Brisbane Metro to Springwood, Capalaba, Carseldine and the airport. The Story Bridge Restoration Project business case to plan the long-term renewal of this nationally significant asset. Toowong to West End pedestrian and cycle bridge business case to strengthen active transport connections.

The Brisbane Metro expansion will demonstrate how bus rapid transit is a scalable solution for Brisbane, where two -thirds of public transport trips are taken by bus. We can do it for a lot cheaper than Melbourne's Suburban Rail Loop, which is getting another top-up of $3 billion this Federal Budget. At the same time, we will advocate for Federal funding to support more housing in Brisbane. We have asked them to provide an additional $500 million for the Housing Support program to fund enabling infrastructure in major cities and triple the Urban Precincts and Partnerships program to $450 million to support major precinct development.

We're also seeking future Federal partnerships on several key projects, including planning and business case funding for the Bowen Bridge Road corridor, a critical northern gateway to Games ' venues and major hospitals. Four million dollars for ferry network planning and design, improving river transport connections. Renewal of the City Reach boardwalk, one of Brisbane's most heavily used active transport corridors. These investments will help ensure Brisbane can safely move hundreds of thousands of residents and visitors each day during the Games, while delivering lasting benefits for the residents who live here.

At the same time, councils across Australia are facing increasing cost shifting from other levels of government. In 2024-25, Brisbane City Council spent almost $200 million subsidising services that are primarily State or Federal responsibilities. While collecting just 3% of tax revenue, we are delivering around 30% of government services. We have also asked the Federal Government to strengthen financial assistance grants and provide more predictable funding for councils. As noted by the LGAQ (Local Government Association of Queensland) , the Federal funding model supporting councils and their communities was introduced in the mid -1970s, Madam Chair, and it hasn't been reformed since.

This funding approach is going backwards, with untied funding for local governments continuing to fall as a percentage of Commonwealth tax revenue. In fact, Madam Chair, Brisbane's financial assistance grants in 2024-25 were 6.8% lower than 2023 -24, and our allocation of financial assistance grant funding continues to fall from an 8.5% share of Queensland's total funding pool in 2013-14 to just a 6.6% share in 2025-26. Madam Chair, we are one of Australia's fastest growing cities and—

DEPUTY MAYOR, your time has expired.

Further questions?

Councillor GRIFFITHS.

Councillor GRIFFITHS:

Chair:

LORD MAYOR:

## Question 4

Brilliant. Thank you, Madam Chair. My question is to the LORD MAYOR.

LORD MAYOR, 2 years ago , I was approached by parents seeking a short footpath link, approximately 5 houses in length, so their son, who uses a wheelchair, could safely access his local school. I supported the request immediately. Since then, Council has spent the next year undertaking a feasibility study. In the second year, Council completed the design work for a cost of $38,000. I'm told next year, in the third year, Council says it can finally construct the footpath for a further $142,000. That brings the total price of this footpath to $180,000. Three years to deliver a simple footpath.

LORD MAYOR, you've just returned from your fifth overseas Council trip in 2 years since you became Mayor. Your Administration has cut more than 500 permanent Council staff and your LNP Party has controlled this Council for 23 years. LORD MAYOR, doesn't this demonstrate that your Administration has lost focus on the everyday needs of Brisbane residents?

LORD MAYOR.

Well, no, it doesn't. It demonstrates what the people of Brisbane know, which is we are absolutely committed to making Brisbane better each day. But specifically on footpaths, we know that local Councillors do quite a bit of this work through the funds that they have available to them, including through the Suburban Enhancement Fund (SEF). We also know that the way of costing and designing those jobs over time has grown in scope and in cost. So, I want to commend 2 people in this Chamber. I want to commend, first of all, Councillor GRIFFITHS for highlighting this issue, but I also want to commend Councillor MURPHY for taking the bull by the horns and doing something about it, because what I can tell you is this.

Councillor MURPHY has done a full review, with the support of his managers in infrastructure, of the way that these kind of works are planned, costed and delivered to reduce red tape, to reduce unnecessary costs and to increase the speed and efficiency of delivery. We're already seeing some fantastic results out of that review. We know Councillor WOLFF has been one of the first cabs off the rank where a similar footpath job was able to be delivered for significantly lower cost by making sure that we reduce the red tape, we reduce some of those unnecessary costs and overheads associated with projects like this.

All Councillors would have received this morning , a message that came through about these kind of quotes that they have received, specifying that any previous quotes that they have received on jobs like this, like a footpath or another suburban enhancement project , are now invalid because there's a new method of quoting and delivering jobs. Now, this is a true credit to Councillor MURPHY and his team in there to actually make sure that we can deliver quicker and more affordably when it comes to jobs like footpaths, when it comes to jobs like park upgrades.

This is what we want to see happen and this is what is going to happen going forward. So thank you, Councillor GRIFFITHS, for raising issues like this. Thank you, Councillor MURPHY, for responding. We are absolutely excited about the potential to deliver more and deliver sooner, so that we can get footpaths built, parks upgraded, to strip out unnecessary red tape, time delays and costs out of the process through a thorough review, which has been done. I am absolutely excited about this opportunity, because it means we can deliver even more than we've been delivering. We can get jobs done, we can build the footpaths and we can deliver results for people, which is the main reason why we asked for the review to be done.

We want this outcome and we saw in recent times with Councillor GRIFFITHS' example of the possum box. That was an example that we took very seriously. Councillor GRIFFITHS, despite suggesting that we had spent $9,000 on possum boxes, we actually spent $425 on possum boxes. Delivered the same outcome and this has helped us also identify areas where we can reduce the red tape and costs and deliver more for less. So thank you, Councillor GRIFFITHS, Chair:

|                    | thank you, Councillor MURPHY. I’m looking forward to seeing more positive  outcomes like this, so that we can deliver more in the suburbs.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               |
|--------------------|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Chair:             | Further questions?                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       |
|                    | Councillor ATWOOD.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       |
|                    | Question 5                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               |
| Councillor ATWOOD: | Thank you, Chair. My question is to the Chair of the Community and the Arts  Committee, Councillor HOWARD.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               |
|                    | Councillor HOWARD, the Schrinner Council is proud to continue our support for  Brisbane’s most vulnerable through our regular Homeless Connect events. Can  you please update the Chamber on what is in store for our next event and how we  can support it?                                                                                                                                                                                                                                                                                                                                                                                                             |
| Chair:             | Councillor HOWARD.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       |
| Councillor HOWARD: | Thank you, Chair, and through you, I thank Councillor ATWOOD for the  question, because this is an opportunity to speak about something that truly  reflects the best of Brisbane and something that the Schrinner Council is incredibly  proud to continue supporting. Chair, tomorrow ,  Brisbane will once again come  together for our next Homeless Connect event, an event that this year marks  20 years of practical action, 20 years of partnership, 20 years of community spirit and 20 years of standing alongside people who are doing it tough.                                                                                                             |
|                    | Homeless Connect has become part of the fabric of this city. It shows what  happens when local government, community organisations, frontline services,  volunteers and businesses all work together with a shared purpose. That purpose  is very clear: to make support easier to access, to bring services together in one  place and to ensure every person who walks through the door is treated with  dignity, respect and care.                                                                                                                                                                                                                                    |
|                    | Chair, tomorrow’s event is a powerful example of how that purpose is brought to  life. People will be able to connect directly with the services that can help them  stabilise their lives and plan their next steps. Guests will be able to access health  and allied health services, including primary health care, mental health support,  drug and alcohol support, nursing care, wound care, podiatry and referrals to  dental and specialist services. For many people, this is the first time in a long time  that they’ve been able to sit down with a health professional in a safe and  welcoming environment.                                                |
|                    | Chair, housing support is also central to Homeless Connect. Tomorrow, people  will be able to speak directly with housing and homelessness services that assist  with emergency accommodation, social and community housing applications,  tenancy sustainment, bond and rental assistance and pathways into longer term  housing. That includes services that specialise in supporting women and families,  young people, older women, Aboriginal and Torres Strait Islander Brisbane  residents and people with complex needs. It also includes services that help people  stay housed, because preventing homelessness is just as important as responding  to crisis. |
|                    | We’ll also have employment services, resume assistance, job search support and connections to training opportunities. Services Australia staff will be on hand to  help with Centrelink, Medicare and identification, including assistance to obtain  birth certificates, which are often key barriers to accessing housing, income and  work. Community legal centres, tenant advocacy services and specialist legal  assistance will be available for people dealing with fines, tenancy disputes, family  law issues or interactions with the justice system. These are practical  conversations that can help people resolve issues that are holding them back.      |
|                    | Chair, Homeless Connect is about dignity and that is why personal care services  are such an important part of the day. People will be able to access haircuts, clean  clothing, toiletries, hygiene products and food. For people with pets, there is  support to help keep people and their animals together. Now, these might seem  like small things, but they make a real difference on how someone feels when they  walk out the door.                                                                                                                                                                                                                             |

Councillor HOWARD:

Chair:

Councillor MASSEY:

Chair:

LORD MAYOR:

Homeless Connect is also about connection, about creating a space where people feel welcome, they can sit down, share a meal and speak with someone who is there to help. That sense of belonging matters, because homelessness is complex and effective responses rely on trust, relationships and coordination. This event brings together dozens of services that work every day on the frontline and it allows them to collaborate, to share knowledge and to build relationships that continue well beyond a single day.

Chair, since it began in 2006, Homeless Connect has supported tens of thousands of people across Brisbane. We continue to deliver Homeless Connect year on year because it responds to real needs and because it's shaped by the expertise of people who understand homelessness and housing stress firsthand. I also want to acknowledge the extraordinary people who make this event possible. The community organisations who bring their knowledge and compassion, the frontline workers who show up day after day for our most vulnerable residents, and the volunteers who give their time, energy and kindness to ensure the event runs smoothly and respectfully. They are a powerful reminder of what community looks like in action. We all have a role to play by supporting the organisations that do this work year round by volunteering—

Councillor HOWARD, your time has expired.

— and the Schrinner Council is committed to doing its part.

Further questions?

Councillor MASSEY.

## Question 6

Thanks. Thank you, Chair. My question is for the LORD MAYOR.

Residents, recreational bike users, bicycle user groups (BUG), peak bodies, disability advocates and many more are all warning the same outcome. The Queensland LNP's Government proposed e-bike restrictions risk pushing people off safe shared paths onto more dangerous roads or put people into cars on already congested Brisbane roads. Given Brisbane City Council regularly promotes active transport as central to the city's liveability, sustainability and to reduce congestion, my question is to the LORD MAYOR, will you publicly and unequivocally oppose these proposed State Government restrictions and stand up against your own party for the people of Brisbane?

LORD MAYOR.

Councillor MASSEY, thank you for the question. Our position has already been made public and it's very clear. It's in writing. It's in black and white. We raise multiple issues and concerns with the proposed legislation and we stand in solidarity with our comrades from the BUG groups and cyclists in wanting to get the right outcome here to make sure that we can get the balance right, and that is simply balancing safety with the ability to get around easily on e-bikes and e-scooters.

Now, we're proud to have led the way when it comes to e-mobility in Australia and we're also one of the biggest uptake cities in the world when it comes to e-scooters. So this is something that the people of Brisbane clearly—and the people of Queensland, in fact—have clearly demanded as a form of travel. They're using it. They want to use it. They're voting with their feet and using it. We just need to make sure that it is safe. So that is the outcome here that we want to achieve. This is the outcome that the State Government wants to achieve.

The draft legislation we had some concerns about. We raised those concerns and I understand that they have now been pursued through the Committee process. The Committee has recommended a number of important changes to the legislation, which I am hopeful will lead to a positive outcome, to get that balance right, to make sure that we can have improved safety, but also that people will still be able to continue to use e -scooters and e -bikes to get around. Because we know that when people are riding around the city, they are not sitting in a car, adding to traffic congestion. When they are riding around the city, they're often not taking up a seat on public transport at a time when public transport is in huge demand.

So this is a positive thing as a way of moving around the city, provided it is done safely. So I think all of our aims are the same here. We want to get the balance right. Nobody has suggested from this Council that e-scooters or e-bikes should be banned. We certainly haven't. We'd just like to see the right balance achieved so that people can use these devices safely and that we can continue to see more ways to get around the city and get around safely and get around actively—use the great infrastructure that we built, such as the new Kangaroo Point Bridge, the Breakfast Creek Bridge, the sections of Riverwalk and bike path that we built.

We want people to use them, but we want them to use them safely. So I think we'll get that outcome. We're confident the State Government, through the Committee changes and the consultation that has been done, that we will get a good outcome here. We're certainly looking forward to seeing the recommendations of the Committee be taken up by the State Government.

| Chair:                    | Further questions?                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              |
|---------------------------|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
|                           | Councillor PARRY.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               |
| Councillor PARRY:         | Thank you, Madam Chair, and my question is to the Chair of the Infrastructure  Committee, Councillor MURPHY.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    |
| Chair:                    | Councillor MURPHY.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              |
| Councillor MURPHY:        | Thank you, Madam Chair, and I thank Councillor PARRY for the question. If the  Schrinner Council is known for one thing, one thing only, it is for keeping  Brisbane moving. During our time in office, we have built—                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          |
| Councillors interjecting. |                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 |
| Councillor MURPHY:        | We have built city-defining projects like Brisbane Metro, Kangaroo Point Bridge,  the Moggill Road corridor upgrade project. Although projects were dismissed and  continue to be dismissed by those opposite, they have actually been transformative  for Brisbane. Brisbane needs a consistent pipeline of infrastructure investment to  keep up with the growth of our city and our region, something that we have  delivered every single year that we have been in office. But, Madam Chair, we  know — the LORD MAYOR and the DEPUTY MAYOR have spoken about it— we cannot do this alone. The local government sector, as the DEPUTY MAYOR  said, collects just 3% of tax revenue, not enough to deliver the growing  infrastructure a city like Brisbane needs. We are growing, Madam Chair, 600 new  people every week. |
|                           | Madam Chair, I know that the Treasurer, Dr Jim Chalmers, will be giving his  budget speech later tonight. In it, I hope that there will be some funding for key  projects that are essential to our city’s future. This includes, as the  DEPUTY MAYOR said before, the Bowen Bridge Road corridor, a crucial  northern gateway to the Victoria Park Olympic precinct, a key part of delivering  transport to the Games venue. A number of bridges and culverts that make up the  Bowen Bridge Road corridor are approaching their end of life and will require  renewal. Likewise, the City Reach Boardwalk also requires renewal. We are  asking for $350 million to renew that asset, to widen it, to make it more accessible  and more sustainable into the future.                                                         |
|                           | There’s other great Olympic opportunities too, Madam Chair. We’re asking for  $4 million to plan and redesign our Brisbane CityCat network to be ready for the  Games in 2032, to unlock new destinations and new ways of moving on our river.  Finally, we know that infrastructure and housing supply go hand in hand. When  we get it right, we can build new housing supply and we could put downward  pressure on growing rents. I saw just yesterday that the Treasurer has already  committed $2 billion to local government across the nation to support new housing  infrastructure, but spread across Australia’s 537 local councils, that is just a few  million dollars each.                                                                                                                                       |

Councillors interjecting.

| Chair:              | Councillors .                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     |
|---------------------|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Councillor MURPHY:  | I trust, Madam Chair, that Brisbane will get its fair share. Thank you, Madam  Chair.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             |
| Chair:              | Further questions?  Councillor COLLIER.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           |
| Councillor COLLIER: | Question 8 Thanks very much, Chair. My question is to the LORD MAYOR.  LORD MAYOR, right across the city, residents are reaching out to the Brisbane  Labor team in frustration of not being listened to, valued and acknowledged by  your LNP Councillors when it comes to projects in their communities. This  includes at Joachim Street Park and the Emma Street precinct in Holland Park  West and Cox Park in Lota. LORD MAYOR, what do you think is a fair  consultation process for projects impacting local residents, given your LNP  Councillors did nothing?                                                                                          |
| Chair:              | LORD MAYOR.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       |
| LORD MAYOR:         | When I became LORD MAYOR, one of the first things I said is that we would  unashamedly invest in parks across the city, and that we would deliver the biggest  and most important investment in parkland and improving parks in the city’s  history, and we have done exactly that, and that includes projects big and small.  That includes fantastic projects like Hanlon Park in Stones Corner, Bradbury Park,  and Archerfield Wetlands, so many other parks, but there’s also a countless  number of smaller improvements as well. We’re rolling them out continually,  because we are passionate about people using our parks. That’s what they exist  for. |
|                     | Parks don’t exist to look nice but not be used, they exist to be used and enjoyed  and benefit the people of our city. We know that there are particular sports that are  growing really rapidly and there’s huge demand for facilities. So, what we see  here is the 2 examples that Councillor COLLIER used relate to pickleball, one of                                                                                                                                                                                                                                                                                                                        |

Madam Chair, we keep hearing from the Treasurer that the government is being extremely judicious about how they spend our money. But we know that that only applies in some cases, because they have tipped in another, as the DEPUTY MAYOR said, $3.8 billion to the Melbourne Suburban Rail Loop, one of the worst, the most expensive and most opaque public infrastructure projects in Australian history. Now, what Melbourne chooses to build is absolutely a matter for them, but we hope that the Federal Government knows that Brisbane also requires key infrastructure funding and we hope that they don't forget about us tonight.

When it comes to Federal investment in Melbourne versus investment in Brisbane, we know that we have a lot of catching up to do. So far, this government has invested just $52 million on Brisbane roads in its time in office. Obviously, that's a lot less than $3.8 billion for Melbourne's Suburban Rail Loop. In fact, it's 72 times less money. Is Melbourne that much more important than Brisbane, Madam Chair? We don't think so.

We are thankful, of course, for the Federal Government's past support for infrastructure projects in Brisbane, but we need more funding to help our growing city. Madam Chair, I note there are a lot more Federal Labor MPs (Members of Parliament) in Brisbane these days, but a lot of voters are starting to wonder if they are getting bang for their buck. If we keep getting dudded for project funding, many voters will start to ask questions of these MPs. We need these MPs to work harder to advocate for funding for our growing city.

Madam Chair, we are determined to push forward and help deliver the infrastructure that Brisbane needs in the 21st century, the infrastructure our growing city needs, but we need the Federal Government to come to the party. I wish the Treasurer, Dr Jim Chalmers, all the very best for his budget tonight. I trust— t—

the fastest growing sports that we have seen in recent years, a sport that keeps people active and healthy, a sport that people are flocking to. They're saying to Council, we need courts, we need facilities. So, we are delivering those facilities, because we listen to people—

Councillor interjecting.

Chair:

One moment, please, LORD MAYOR, your microphone.

Councillor COLLIER, you have asked a question and the LORD MAYOR is answering it, please show respect and stop calling out while he’s doing that.

LORD MAYOR.

LORD MAYOR:

So, we really are passionate about making sure that our parklands get used, and so are the people of Brisbane, because one of the key things that came out of our legacy consultation that we did recently on what is the great active and healthy and sporting and infrastructure legacy that people want to see from the Olympic and Paralympic opportunity, they wanted to make better use of the parkland and spaces that we have. There was a specific idea put forward called Loving the Leftovers, and that was actually transforming unused spaces into usable spaces.

Councillor COLLIER:

Point of order.

Chair:

One moment, please, LORD MAYOR.

Point of order, Councillor COLLIER.

Councillor COLLIER:

Chair, under the Meetings Local Law, the LORD MAYOR has to be responsive to the question that was asked, which was about a fair consultation process for these particular projects.

Chair:

Thank you, Councillor.

Councillor COLLIER:

The LORD MAYOR is not being responsive.

Chair:

You asked your question, you don’t get to ask it again.

Councillor COLLIER:

He hasn’t answered.

Chair:

The LORD MAYOR is answering the question.

LORD MAYOR.

LORD MAYOR:

Well, I think I’m pointing out that we actually do listen to people. I was talking about a citywide consultation process, but I—

Councillor interjecting.

Chair:

One moment, please, LORD MAYOR if you can take your seat.

## ORDER – COUNCILLOR LUCY COLLIER

The Chair then advised Councillor Lucy COLLIER that as she had continued to fail to comply with the request for remedial action for her unsuitable meeting conduct, in accordance with section 21(8) of the Meetings Local Law 2001, an order reprimanding her for her conduct was being issued.

Chair:

Councillors, that now ends Question Time.

## CONSIDERATION OF RECOMMENDATIONS OF THE ESTABLISHMENT AND COORDINATION COMMITTEE DURING RECESS

## ESTABLISHMENT AND COORDINATION COMMITTEE (Adoption report)

Chair:

LORD MAYOR, Establishment and Coordination Committee (E&amp;C) recommendations.

The LORD MAYOR, Chair of the Establishment and Coordination Committee, moved, seconded by the DEPUTY MAYOR, that the report setting out the recommendations of the Establishment and Coordination Committee during the Autumn Recess 2026, on matters usually considered by that Committee, be adopted.

Chair:

LORD MAYOR:

LORD MAYOR.

Thank you, Madam Chair. Before I move to the items in front of us, I just wanted to cover a number of issues, as I always do. First of all, just relating to the asset light-up of City Hall, Kangaroo Point Bridge, Story Bridge, Victoria Bridge and also the Mt Coot -tha Tropical Dome and Reddacliff Place. Last night, they were lit up in purple and blue to support Light It Up 4 HD, acknowledging May is the International Awareness Month for Huntington's disease. Tonight, our assets will be lit up in orange to mark National Palliative Care Week, now in its 30th year, which remains Australia's largest annual discussion about matters of life and death.

Tomorrow, our assets will be lit in blue for the eve of Apraxia Awareness Day, raising funds to support those living with apraxia, a motor speech condition that makes it difficult to speak. On Thursday, our assets will be lit up in maroon. Can anyone guess why? State of Origin, yes, that's right. It's the NRL (National Rugby League) Women's State of Origin Game 2 at Suncorp Stadium. On Friday, the bridges will be lit up in blue and white to celebrate National Corrections Day, recognising the work of corrective service officers and shining a spotlight on the work they do to keep Queenslanders safe.

Other assets will be lit up to celebrate the NRL Magic Round, the world's biggest rugby league festival, rotating the colours of the participating teams, which will continue on Saturday as well. Brisbane kicked off Magic Round with the NRL and Queensland Government back in 2019, and there's nowhere else in Australia that can bring it to life quite like our city. We love to see people coming from all over Australia to experience the Magic Round, but also, more importantly, to experience Brisbane and the best we have to offer.

This is more than just a weekend of footy. It's packed pubs and hotels. It's thriving precincts. It is experiencing the great Brisbane lifestyle and it is one of the reasons why so many people are moving here. Those footy fans from down in Sydney in particular, they come up here for Magic Round and they're like, I might just stay. They do and they're moving here in droves. It attracts around 30,000 visitors each time and injects more than $50 million into Brisbane's economy. We're huge fans of Magic Round, and we'll continue working with the Premier to keep Magic Round where it belongs here in Brisbane.

Finally, on Sunday our assets will be lit in rainbow colours to mark International Day Against Homophobia, Biphobia, Interphobia and Transphobia, which is known as IDAHOBIT Day. It's observed on 17 May and has been yearly and we have always supported it and continue to support it and we will continue again this year and into the future. We say no to any kind of discrimination and we particularly want to support our local community and also the Council officers as well, who we want to be free from any kind of discrimination.

May is Domestic and Family Violence Prevention Month, and this is an initiative we are also very proud to support. We support charities and initiatives across Brisbane that aim to raise awareness for and promote prevention of domestic violence. Later this month, we'll be stepping up to support Challenge DV's Darkness to Daylight for another year. This is a powerful opportunity for our community to come together, reflect and have a meaningful conversation about domestic violence. I know that the DEPUTY MAYOR and many of our Councillors are already signed up to participate, and it's certainly a fantastic thing to do.

On the weekend, we had a great charity fundraiser in Roma Street Parklands for the Lord Mayor's Charitable Trust. It's known as BrisSizzle and Sounds, and it's Brisbane's day of giving. It started off 20 years ago as the Big City Barbecue. It started off at Riparian Plaza and it was a community-driven event to raise funds. So, the tenants in Riparian Plaza got together to raise money and then it became a whole of city event. So, we then supported it. It then became the Big City Barbecue and it was an annual thing and it has been for 20 years, and it's now transitioned to the Roma Street Parklands, where it's known as BrisSizzle and Sounds. There's great performances, a lot of stalls set up, and most importantly, raising money for charities like Foodbank and Drug ARM (Awareness, Rehabilitation and Management) .

Thank you to the Lady Mayoress for her commitment to that project. I can say that over the years, there's been more than $1 million raised for Brisbane charities from this particular event. So, credit to everyone involved and we are so grateful and we want to thank everyone that came along on the weekend to that event.

I also wanted to provide a report on my visit to the United States, specifically Boston and Los Angeles, during the recess. The purpose of this travel, which I again state came at no cost to the ratepayers, was to visit the Harvard campus at Boston as part of the Bloomberg Harvard Leadership Initiative that I have been involved with since the middle of last year. This is a program that is fully funded by Bloomberg Philanthropies under the leadership of Michael Bloomberg, the former Mayor of New York. He, each year, invites more than 40 Mayors from around the globe to participate in this leadership initiative designed specifically for Mayors and city leaders.

So, I participated in it. We also had the CEO and Tim Wright participating as well, once again, at no cost to the ratepayers of Brisbane. In this recent visit, which was the capstone part of the course, it was in the Harvard campus in Boston, and so we had a few days on the ground at the Harvard campus, but also on the way back there was a stopover in Los Angeles. This—we hear some groaning here. We hear some groaning because isn't it terrible that a Sister City arrangement came at no cost to the ratepayers? So, what we saw is that—I was on the ground in LA for about 7 hours. I want to thank the Australian Consulate in LA and our Consul -General there, who's absolutely fantastic.

We had the support of the consulate, the full consular support of the Australian Consulate in LA. They picked me up from the airport, they took me to their Consular Office, there were briefings, they took me to LA City Hall and they delivered me back to the airport. All of this happened within a matter of hours. I think I hit the ground maybe around 2pm in the afternoon and I was back at the airport again later that afternoon. So, if anyone knows anything about traffic in LA, it wouldn't have been possible without the support of the Consulate-General, Tanya Bennett, in LA and her team.

Now, Mayor Karen Bass, I met with Mayor Bass and we signed the documents, both for our Sister City arrangement and an MOU (Memorandum of Understanding) for cooperation between our 2 cities. This is a really exciting opportunity, because in just 2 and a half years, they will host the Olympic and Paralympic Games. They are in the thick of it at the moment and they are absolutely committed to sharing their learnings with us. That is already started in earnest and it will continue on. They said to me that the City of Paris had been really, really generous with them in sharing what Paris had learnt from their Olympic experience and they want to do the same to us as well and the same for us.

The other thing is that Los Angeles is the world's third largest city economy, third largest. So, there's New York, there's Tokyo and LA, number 3. This is a city of monumental scale. It's a city of monumental economic power and influence, of innovation, and there are many more things than Olympic benefits in sharing a partnership with LA. So, to be able to sign up this Sister City Agreement at no cost to the ratepayers was a fantastic thing.

Now, I heard Councillor CASSIDY mumbling about, oh, you could have done it by Teams. Well, I can tell you, while Councillor CASSIDY for the last 8 months or so has been catching Zs and counting sheep, I've been up in the middle of the night doing Teams meetings as part of this Harvard course. In fact, I've spent countless hours doing Teams meetings in the middle of the night, because the time zones don't exactly align. So, this Harvard program I've been involved with, with the other mayors, there's regular meetings that have been between 1.30am and 3am, sometimes between 3am and 5am.

Councillor interjecting.

Chair:

One moment, please, LORD MAYOR. Your microphone.

Councillor CASSIDY, as you’ve failed to comply with my previous request to take remedial action for your unsuitable meeting conduct, I warn you in accordance with section 21(6) of the Meetings Local Law 2001 that failing to comply with the request may result in an order being issued.

I remind Councillors, all of you, to please remain quiet while another Councillor is on their feet.

LORD MAYOR.

LORD MAYOR:

Thank you, Madam Chair. So, I certainly can tell—

Chair:

LORD MAYOR, your time has expired.

## PROCEDURAL MOTION – EXTENSION OF TIME

597/2025 -26

It was moved by the DEPUTY MAYOR, seconded by Councillor Julia DIXON, that the LORD MAYOR be granted an extension of time.

Councillor interjecting.

Chair:

Thank you, Councillor GRIFFITHS. I also will warn you, in accordance with section 21(6) of the Meetings Local Law 2001, that failing to comply with the request may result in an order being issued.

Councillor interjecting.

Chair:

Correct, Councillor GRIFFITHS.

Councillor interjecting.

Chair:

No, I’m not debating it.

Councillors interjecting.

Councillor JOHNSTON:

Point of order.

Chair:

No, I’m speaking at the moment, thanks, Councillor JOHNSTON.

Councillor JOHNSTON:

Clearly you were not, but anyway.

## ORDER – COUNCILLOR STEVE GRIFFITHS

The Chair then advised Councillor Steve GRIFFITHS that as he had continued to fail to comply with the request for remedial action for his unsuitable meeting conduct, in accordance with section 21(8) of the Meetings Local Law 2001, an order reprimanding him for his conduct was being issued.

Chair:

Now, Councillors —

Councillor GRIFFITHS:

Point of order.

Chair:

Point of order, Councillor GRIFFITHS.

Councillor GRIFFITHS:

Who was that for?

Chair:

That was for you, Councillor.

Councillor GRIFFITHS:

Okay, thank you.

Chair:

If you were listening instead of calling out—

Councillor GRIFFITHS:

No, we can’t hear you.

Chair:

If you want to continue—

Councillor GRIFFITHS:

We can’t hear you. You’re mumbling.

Councillor interjecting.

Councillor GRIFFITHS:

You are mumbling.

Chair:

Completely inappropriate, Councillor JOHNSTON. As you have failed to comply with the request to take remedial action for your unsuitable meeting conduct, I hereby warn you in accordance with section 21(6) of the Meetings Local Law 2001, that failing to comply with the request may result in an order being issued.

I will just remind all Councillors of why you are here and to try and—I know it’s been a long recess but try and refocus on what you are doing in this Chamber, and if you want to call out and are critical of Sister City relationships , et cetera, save it for GB (General Business). It is not appropriate for you to be calling out across the room constantly.

LORD MAYOR.

Councillor JOHNSTON:

Point of order.

Chair:

Councillor JOHNSTON, point of order.

Councillor JOHNSTON:

Okay. First point of order. You made a number of rulings there. You never said anybody’s name. We have no idea who you were addressing any of that to. That’s massively problematic because we need to understand if and when you make a ruling. It’s a basic requirement. Two, and more importantly, Madam Chair, and I think everyone will second this, we cannot hear you. You are talking so lowly like this. We can’t hear you. I cannot hear you properly. I don’t know what you are saying. I don’t know if it’s a microphone issue or it’s the way you’re talking, we can’t hear you properly.

Chair:

Well, I suggest, Council, that you listen more carefully, because I have said the names as I have made it. You can go back and listen later, if you like. I do not uphold your point of order, and I do warn you that you are being very—you are displaying very unsuitable meeting conduct in how you are addressing the Chair.

Councillor CASSIDY:

Point of order.

Chair:

Point of order, Councillor CASSIDY.

## 598/2025 -26

It was moved by Councillor Jared CASSIDY, seconded by Councillor Nicole JOHNSTON, that the Chair is engaging in unsuitable meeting conduct.

At that time, 2.12pm, the Chair retired from the meeting room and associated public places for the duration of the debate. The Deputy Chair presided at the meeting .

| Deputy Chair:            | Councillor CASSIDY.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   |
|--------------------------|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Councillor CASSIDY:      | Thanks very much, Chair, and Mr Harvard Graduate himself is not here,  unfortunately, because this is—the LORD MAYOR’s own evidence here is going  to come into this debate just now. So, Councillor LANDERS has, for the last hour  and 13 or so, accused Labor Councillors and Councillor JOHNSTON of shouting  out, I quote,  “ and calling out across the Chamber ” , and warning us and running  through the disciplinary process, while it still exists for one more month, to try  and get us referred to the OIA (Office of the Independent Assessor) .                                                                                                                                                                                                                                                                                                                                                                                                                                                       |
| Councillor interjecting. |                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       |
| Councillor CASSIDY:      | Yes, and specific targeting to try and get us referred to the OIA for unsuitable  meaning conduct, which then adds up to misconduct. So, this is an LNP targeted  strategy to try and attack and bully and belittle and silence their political  opponents. So, Councillor LANDERS has clearly been given the drum about this,  clearly been told to do this, because every time, according to the  LORD MAYOR— R— and this is the LORD MAYOR’s exact quote, Deputy Chair— “ that Labor Councillors and I were mumbling ” . The LORD MAYOR said that.  Now, when he’s here and not talking to his Harvard buddies, that’s 2 metres away,  just 2 metres away, and the LORD MAYOR said that what I did throughout all of  that apparent calling out and shouting out was just mumbling.  So, who do you believe? Do you believe Councillor LANDERS, who’s clearly  been given her marching orders from on up high in the LNP, or do you believe  Brisbane’s LORD MAYOR, who’s sometimes here and sometimes not? Mostly |
|                          | not, but he was here for that. So, he claimed on the record that all he could hear                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    |

Councillor interjecting.

Councillor CASSIDY:

Deputy Chair:

Councillor WINES:

Councillor interjecting.

Deputy Chair:

was inaudible mumbling. So, LORD MAYOR of Brisbane, who's in charge of this place, can amend the agenda and runs this regime with an iron fist, he claims that all of that interjecting was inaudible and mumbling. Yet the Chair of Council — and we've heard it again today—apparently according to the Chair of Council, what she says goes. There's some sort of personal dictatorship going on in here in the application of the rules. They can be a different application week in, week out. We've experienced that.

Sometimes Councillor LANDERS comes in and mops that up the week after and says a different rule applied this week to last week and things like that. So, there's been complete and utter inconsistency today, except for one thing: a specific targeting of non-LNP Councillors to achieve a referral to the OIA to try and get findings of misconduct against us for, according to the LORD MAYOR, inaudible mumbling. That's what's happened here today.

But more specifically, in her campaign of targeting Labor Councillors, Councillor LANDERS erred and warned Councillor GRIFFITHS and then subsequently noted his conduct in the minutes for interjections he never made. Councillor STRUNK owned up to it and said, no, that wasn't Councillor GRIFFITHS, that was me, Councillor STRUNK, who did that.

Yes, I bet. I bet all these judicial reviews are going to love all this evidence, because it's all on camera, and it's all recorded in here. Unless it's blurred, of course. So, Councillor LANDERS had an opportunity, heard that and decided in her normal way of disregarding the Council rules of which she is bound to uphold, just ignored it and just said whatever she said goes. So that's a pretty clear-cut case. There's 2 things here. The LORD MAYOR has clearly confirmed that there was no calling out and no shouting out across the Chamber. He just said it was inaudible mumbling. That was his term. Quite clearly, Councillor LANDERS got it wrong.

She was corrected that it wasn't Councillor GRIFFITHS who interjected at the time that the interjection apparently occurred. It can't have been that audible if she couldn't discern who even said what. I can guarantee to you if you asked what was said, there would be absolutely no idea what was said either, because according to the LORD MAYOR, it's inaudible mumbling. So, we would just like, for one, a consistent application of the rules in this place, for one, week in, week out, that's not too much to ask, but also in this case, just the application of the rules at all. Not just week in, week out here, but today, an actual application of the rules.

Because this referral that will now occur and Councillor LANDERS next week or the week after will move a motion or she'll get someone to move a motion and then probably attempt to sit with a conflict of interest in the Ethics Committee and make a ruling there again based on illegal rulings here in the Council Chamber to refer somebody off to the OIA and find them guilty of misconduct. So, it's pretty clear what's going on here and it shouldn't stand.

Further speakers?

Councillor WINES.

Thanks, Mr Deputy Chair. Look, once again, we see Councillor CASSIDY coming in here and make some pretty horrendous accusations of the Chair. It's, I think, a pretty sad and cynical use of this rule and that he effectively accused the Chair of pursuing him and his colleagues. It's completely false and I have a very different perspective from—

Councillor COLLIER.

Councillor GRIFFITHS, please allow other Councillors to speak in silence. Thank you.

Councillor WINES.

| Councillor WINES:        | I have a different perspective and I watched for the last hour and a quarter the  minority Councillors pursuing Councillor LANDERS and her attempting to  maintain a calm and professional presentation, which was mocked and attacked  by Councillor JOHNSTON, I think in a personal and unfair way.                                                                                                                                                                                                                                  |
|--------------------------|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Councillor JOHNSTON:     | Point of order.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        |
| Deputy Chair:            | Point of order, Councillor JOHNSTON.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   |
| Councillor JOHNSTON:     | I didn’t mock and attack anybody in anything that I’ve done today. I have raised  issues about I can’t hear Councillor LANDERS. That’s not mocking and attacking  and I’ve raised procedural issues.                                                                                                                                                                                                                                                                                                                                   |
| Deputy Chair:            | Sorry, is that misrepresentation?                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      |
| Councillor JOHNSTON:     | I’d ask that that’s withdrawn.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         |
| Deputy Chair:            | Councillor WINES, would you care to withdraw?                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          |
| Councillor WINES:        | I wasn’t asked to withdraw, and I also think that Councillor JOHNSTON proved  my point in the way she just conducted herself, that she did in fact pursue and  mock Councillor LANDERS in that position, but if she’d like me to withdraw,  I will withdraw. I will wholly and unreservedly withdraw, but I think that a  fair - minded person would see it the way that I presented it. Now, I think, once  again, we see a cynical misuse of this rule from a Chair who—it is a difficult role  up there, who is solo up there, and— |
| Councillor interjecting. |                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        |
| Councillor WINES:        | Look, always appreciate supportive interjections, but the thing is, it is a difficult  role. I think Councillor LANDERS is placed deliberately under unnecessary  pressure by Labor Councillors, and I think she handles it very well. I think that,  once again, that we’re doing this one more time is a reflection not on Councillor  LANDERS, but on the minority Councillors and as a result of that—                                                                                                                             |

## PROCEDURAL MOTION -MOTION BE NOW PUT

599/2025 -26

It was moved by Councillor Andrew WINES, seconded by Councillor Julia DIXON, that the motion be now put.

Upon being submitted to the Chamber, the procedural motion was declared carried on the voices.

Deputy Chair:

Councillor CASSIDY, your right of reply.

Councillor CASSIDY:

Thank you very much, Chair. Talk of what Councillor WINES said, cynical misuse of the rules. That’s what we have observed for the last hour and 15 minutes from this Chair of Council and what we have had to cop for the last 12 months, a cynical misuse of the rules by Councillor LANDERS. You have all seen it. Maybe you don’t pay attention, maybe you don’t listen along, maybe you can’t hear Councillor LANDERS, because I back what Councillor COLLIER was saying and Councillor GRIFFITHS and what Councillor JOHNSTON said as well. I find it very difficult to hear sometimes Councillor LANDERS.

Now, I don’t know whether— r— I don’t know, but sometimes it is very difficult. So how are we meant to respond to requests for so-called remedial action if we don’t even understand what that request is? So as an aside—

Councillor interjecting.

Councillor CASSIDY:

Yes, we’re not mind readers. So that is a legitimate problem. But aside from everything that Councillor WINES said—and it’s the same speech he’s rolled out each and every time in response to an accusation of unsuitable meeting conduct— it’s really quite clear. Councillor WINES is refuting and disagreeing with what the LORD MAYOR has said in the Chamber just 10 minutes ago or so. He reckons he has a different perspective on the meeting as the LORD MAYOR of Brisbane. LORD MAYOR clearly said he couldn’t make out. It was inaudible mumbling coming from Labor Councillors sitting not 2 metres from him. So, I get that Councillor WINES is agreeing with Councillor LANDERS and defending

Councillor interjecting.

Councillor CASSIDY:

Councillor LANDERS' misuse of the rules of this place, but it's very strange that he is in such disagreement with the LORD MAYOR, so that's, I guess, odd, as an aside.

But apart from that, there is a very specific issue here, where Councillor LANDERS warned and then used that official warning to then note Councillor GRIFFITHS' conduct in the minutes of this meeting for something he didn't do, which now will result in a referral to the OIA and potential findings of misconduct. Now, that's obviously going to be ending up in court, right? So obviously now, because of the deliberate strategy of Councillor LANDERS, she is going to cost this Council tens if not hundreds of thousands of dollars in legal fees.

She could very well have just said, my apologies, okay, Councillor STRUNK, you were warned, but no. The LNP are so hellbent on targeting their political opponents through the misuse of these rules, they cannot see clearly through them at the moment, which is really, really quite incredible. Really bad for the people of Brisbane. So, it's pretty clear cut. It's pretty clear cut here and Councillor LANDERS has clearly engaged in unsuitable meeting conduct and there's essentially no 2 ways about it.

I take all these interjections. I take all these interjections from Councillor JOHNSTON. On top of that as well, Councillor LANDERS is specifically applying these rules, having the authority herself to then make these rulings that then result in a Councillor being referred and then ending up in an Ethics Committee of which she sits on as an LNP vote, as the majority of that Committee, and never recuse herself from that. So, I wonder if there's a conflict of interest in all of that as well. So, this is all —j —judge, jury and executioner. I mean, this is all, I guess, going to be wrapping up, and I understand the LNP are trying to force as many of their political opponents through a disciplinary process that's about to be cancelled altogether and will result in a lot of money being wasted, a lot of ratepayers' money being wasted way too much on this.

But it's pretty clear cut today, and I don't accept what Councillor WINES said, that this is a misuse. This is our only avenue. As Councillors, if we observe the Chair of Council engaging in unsuitable meeting, this is the only thing we are allowed to do. In fact, if we try and rise on a point of order and seek clarification these days, we're probably going to be shut down, warned, and then referred to the OIA for that as well. So, this is one of the very last and few vestiges of democracy that operate in this place after 23 years of a political regime that is tightening its control more and more and more.

I mean, it's great to see the LORD MAYOR reappear back in the Chamber. He was, I assume, gone back to his locked office, that you can now no longer, as a member of the public, attend. You ring the doorbell and then you're probably told to go away. This is a really serious issue, not just for the operation of this Chamber here as well, but as we know, this is now going to cost ratepayers tens or hundreds of thousands of dollars to defend these bad decisions.

Deputy Chair:

I now—

Councillor GRIFFITHS:

Point of order, before you do the ruling.

Deputy Chair:

Point of order, Councillor.

Councillor GRIFFITHS:

I wasn’t given the opportunity to speak in that, even though that was about me. Can I just say that I really disagree—

Deputy Chair:

Sorry, no, Councillor GRIFFITHS. I don’t uphold that point of order.

Councillor GRIFFITHS:

I really disagree—

Deputy Chair:

Sorry. I don’t uphold your point of order, Councillor GRIFFITHS.

Councillor interjecting.

Deputy Chair:

Councillor GRIFFITHS, I don’t uphold your point of order.

Councillors interjecting.

Deputy Chair:

I now put the motion to the vote.

Upon being submitted to the Chamber, the motion was declared lost on the voices.

Thereupon, Councillors Jared CASSIDY and Lucy COLLIER immediately rose and called for a division, which resulted in the motion being declared lost .

The voting was as follows:

| AYES: 8  -    | The Leader of the OPPOSITION, Councillor Jared CASSIDY, and Councillors  Lucy COLLIER, Steve GRIFFITHS, Emily KIM, Charles STRUNK,  Seal CHONG WAH, Trina MASSEY and Nicole JOHNSTON.                                                                                                                                                                       |
|---------------|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| NOES: 18  -   | The Right Honourable, the LORD MAYOR, Councillor Adrian SCHRINNER,  DEPUTY MAYOR, Councillor Fiona CUNNINGHAM, and Councillors  Krista ADAMS, Greg ADERMANN, Adam ALLAN, Lisa ATWOOD,  Tracy DAVIS, Julia DIXON, Alex GIVNEY, Vicki HOWARD, Steven HUANG,  Sarah HUTTON, Kim MARX, Ryan MURPHY, Danita PARRY, Steven TOOMEY,  Andrew WINES and Penny WOLFF. |
| Deputy Chair: | Can someone advise the Chair to come back to the Chamber?  Madam Chair, the Chamber has decided you have not conducted any unsuitable  meeting conduct. Please return to the Chair.                                                                                                                                                                         |

At that time, 2.28pm, the Chair presided at the meeting .

## PROCEDURAL MOTION – EXTENSION OF TIME

Upon being submitted to the Chamber, the procedural motion was declared carried on the voices.

Chair:

LORD MAYOR:

LORD MAYOR.

Thank you. The Leader of the Opposition was groaning about why all of this could not be done via Teams or via Zoom. I was just explaining that there was actually a lot of Teams or Zoom meetings that I did as part of this program. In fact, something like 19 or 20 different Zoom sessions, hours and hours, usually in the middle of the night. But I can tell you this, after having participated via the Zoom sessions and also some of the in -person sessions, nothing beats the in-person sessions for value and for relationships.

Councillor CASSIDY has the ability to Zoom into this meeting if he wants, but he chooses to be here in in person, right? Except when it's the budget information sessions, you'll remember that. So there is something to be said for the in-person building of relationships and that was a critical part of both the Bloomberg Harvard program and it was a critical part of signing in person the Los Angeles agreement in person with the Mayor and the Deputy Mayor of Los Angeles and the senior officials from Los Angeles, and the Australian Consul-General, Tanya Bennett, in Los Angeles.

But the other thing I just wanted to point out is that the Bloomberg Philanthropies have a range of programs that they support in cities around the world on a whole range of initiatives, and they're encouraging cities to apply for funding. We were successful in receiving funding through the Bloomberg Youth Climate Action Fund. We have, for many years, had a program called the Lord Mayor's youth environmental network, or young environmental leaders, and this really supports the work we were doing through that. Through our program, young school students came up with projects that reduced their environmental footprint or a sustainability program. A number of the Councillors would be aware of these.

The great news is that Bloomberg Philanthropies has now backed up these projects with funding. So not only do the students have to scrimp to try to raise money for their projects, they will get funding from Bloomberg Philanthropies to initiate projects, which is just fantastic and one of the many benefits that we will see flow, both from this program and our relationship with Bloomberg, Harvard and also our relationship with Los Angeles as well.

Moving to the items on the agenda. Item A is the contracts and tendering report for March 2026. I'm pleased to say that 21 out of 24 contracts, or 87%, are being awarded to local suppliers. So far, this financial year, 162 out of 175 contracts were awarded to local suppliers, being a total spend with local suppliers of $861 million. Contracts include air conditioning and lighting upgrades at Mitchelton Library, construction of a new boardwalk at Nudgee Beach Reserve. I saw Councillor ALLAN out there the other day on social media promoting that. Landscaping in Pallara, concrete and asphalt coring and cutting services, ferry terminal maintenance, a toilet block and sewerage treatment upgrade at Gap Creek Reserve, new playgrounds for Merri Merri Park and Hickey Park, and a new dog-off-leash area at Windsor Park, new storage sheds for Ferguson Park and Shaw Estate Park.

These are part of our commitment that we made to residents in the lead-up to the last election, where we know that a number of community groups don't have anywhere to store their items. So you all know cases of community groups where they're storing things underneath people's houses and that space is in demand, obviously, in people's garages and under houses. So this is effectively piloting a new initiative where we provide some storage sheds for community groups who need to store equipment. So the first 2 are rolling out in Ferguson Park and Shaw Estate Park and I'm excited to see the take -up. Obviously, we're committed to doing more in this space as well, but we'll monitor the take-up and see what the demand is like.

There's a construction of a new BMX jump track at Salisbury Recreation Reserve, first aid training services to support zero harm in our workplace and for the public, Story Bridge concrete slab replacement works, which were delivered early and under budget, and also several contracts for back-of-house systems and IT.

Item B is the Wynnum Centre Suburban Renewal Precinct Plan. This is something that we discussed not too long ago in the last session of Council and obviously the source of a lot of debate. We have now been through the final approval process and received State sign-off to proceed. With its adoption, we can help revitalise one of our amazing bayside suburban destinations and also delivering more homes in the right places. This particular precinct plan will provide for the great demand in the Wynnum-Manly-Lota area and some of the surrounding suburbs for people to be able to downsize out of a home and into a unit when the demands or the size of a house gets too much for people.

We are hearing that people want to stay in their local area, but there are not the options available at this point in time. We are also hearing that younger people want to move in. This is a potential option that provides both downsizers and also younger people an opportunity to share in the wonderful bayside lifestyle. So this will also help revitalise the Wynnum CBD, which is something that everyone says they want to see happen. I think across the political spectrum, everyone agrees that they want to see the Wynnum CBD revitalised, and this will help deliver that outcome, there is no doubt about it.

The precinct is a discrete precinct. It's not including the whole suburb of Wynnum by any stretch of the imagination. It is a very discrete precinct in the Wynnum CBD, and that includes the area near the central train station and there's also a great parkland in the precinct as well. We've had a process of around 18 months from the commencement of the project to its completion, coming through the final stage today, which included initial community consultation, engagement with the State, preparation of the draft plan for public consultation, the making of appropriate changes in response to that consultation, and also obtaining State Government approval to adopt the plan.

So this project has taken about half the time that a traditional neighbourhood plan process would take. That's because we need revitalisation sooner and we need more homes sooner as well. We value community feedback and we have made changes to the plan based on that feedback. Does that mean that everyone will be entirely happy? Of course not. I have never seen ever the history of this Council, or any Council, a planning process where everyone is entirely happy. But we are in a severe housing shortage and we are also talking about a part of the city that everyone agrees would benefit from revitalisation.

Chair:

Now I do have an important and exciting announcement to make relating to the Wynnum CBD today, because not only are we committed to seeing that revitalisation, we're prepared to back packet ourselves. I can confirm today that the City of Brisbane Investment Corporation (CBIC), which is our city's Future Fund, has land ownership in the Wynnum CBD, where they will be redeveloping a new 3 -storey commercial development, which will include medical facilities and other retail opportunities. But most importantly, it will deliver 66 new car parks, free of charge available for the people of Wynnum to use.

One of the things that we heard very clearly is that people wanted more parking available in Wynnum CBD and this medical precinct and retail precinct we're developing, not 12 storeys, not 15 storeys, just 3 storeys, will deliver 66 extra car parks in the Wynnum CBD and they'll be available for anyone to use. So this is the land right next to the Wynnum Library and the Woolworths, and so that precinct will be invested in by the City of Brisbane Investment Corporation. The great news about this is that it will be an investment that will revitalise, deliver more car parks, but it will deliver a long-term return to the people of Brisbane and the ratepayers of Brisbane, because the Future Fund is designed to do exactly that, to deliver a return to ratepayers, which takes the pressure off rates and rents.

So far, City of Brisbane Investment Corporation has delivered major dividends over the years, which have helped reduce the pressure on rates. It's one of the reasons why we can offer the cheapest rates in South East Queensland, because we have entities like City of Brisbane—

LORD MAYOR, your time has expired.

## 600/2025 -26

It was moved by the DEPUTY MAYOR, seconded by Councillor Julia DIXON, that the LORD MAYOR be granted an extension of time.

| Chair:      | LORD MAYOR                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              |
|-------------|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| LORD MAYOR: | As I was saying, it’s one of the reasons why we can offer cheaper rates than other  councils, and we’re determined to keep it that way. This proposal will go through  the normal approval process, and so we have an expectation on CBIC that they  will adhere to the requirements of the plan. As I said, this is not a tall residential  building we’re talking about, it is a 3-storey retail development, which will  include, we’re expecting and hoping, medical uses, but also additional car parking  for the Wynnum CBD. So, subject to approvals, we’re hoping to see construction  kick off next year, maybe in the second half of next year. So, we’re very much  looking forward to that project.  Of course, this is further evidence that we are committed to the revitalisation of  the CBD in Wynnum. We are committed to Wynnum. It is a fantastic part of  Brisbane and we want to see it prosper and thrive and we want to see opportunities  for people to live there, particularly people that are already living there that need  to downsize. They can free up their house, they can move into an apartment and  stay in the area without the maintenance requirements that a house has. Maybe  their kids have moved out, maybe they need less space. That way then another  family can move into their house that they’ve freed up and more people can share  in the beautiful Wynnum lifestyle. So I commend this item to the Chamber.  Item C is the report of the Audit Committee for 2 April. As always, this is  presented to Council in line with the City of Brisbane Regulation. Our Audit  Committee’s job is to work with the Queensland Audit Office to provide another  level of independent oversight to our policies, procedures and practices to ensure  that we’re addressing potential risks and managing them. The Committee was  briefed by the CEO, the CFO, the Chief Legal Counsel, Chief Internal Auditor and  Chief Information Officer on a range of matters.  Topics discussed are set out in the minutes, including the management of risks  associated with ICT and cybersecurity, something that every organisation is  facing. One of the risks that are currently being faced by all large organisations is  the issue of fuel security and what’s happening in the Middle East. So obviously,  as you would expect, that was a source of discussion. We’re actively managing  that risk and I would say simply that I remember in previous budgets when the |

Leader of the Opposition has laughed at the concept that we might run a balanced budget with a surplus. He's laughed at it. This is exactly why we need to run a budget that is balanced and has a small surplus, because unexpected things happen.

I don't think that there's ever been a year where unexpected things have not happened, so that's why we run a balanced budget. It's not something to be laughed at, it's something that we take very seriously because we need that buffer zone against cost increases and unexpected circumstances that do arise, like the increasing cost of fuel. That flows through to our buses, it flows through to grass cutting, it flows through to rubbish collection. There's a whole range of things that it flows through to. We need to manage that risk and we are managing that risk. We'll continue to act on the advice of the Federal Government when it comes to this situation.

The Committee was also briefed on the end of year annual budget 2025-26 review and the lessons learned and opportunities from ex-Tropical Cyclone Alfred, as outlined in the de Jersey review. It's also worth mentioning that work is happening behind the scenes to manage our $45 billion portfolio of assets. Any engineer will tell you that no matter how well something is built and how much you spend maintaining it, everything has a finite serviceable life. Eventually, it requires either a massive restoration or a replacement. So that's an ongoing issue for the City of Brisbane.

We just celebrated recently our 100th birthday as an organisation. What that means is that the city not only has a whole heap of new assets but a lot of ageing assets as well that are 100 years or approaching the end of their life stage. So a process to invest in those assets is ongoing and the Story Bridge is the classic example of that where we've continued to invest and that investment continued just in recent months, where major work was conducted on the process to maintain and repair the Story Bridge. We'll keep doing that, but obviously, the scale of this is beyond our capability as a local government, and we'll continue seeking the financial support of the other levels of government.

We're embracing the latest technology to assist with what often is a time -consuming and dangerous task when it comes to managing and assessing asset condition. The Committee was told that this kind of approach will give us access to more and better data sooner, which will be an integral part of our asset management approach. So it was a comprehensive meeting and I want to thank our Audit Committee for all the work they do behind the scenes and I commend this item to the Chamber.

Chair:

Further speakers?

Councillor CASSIDY.

Councillor CASSIDY:

Thanks, Chair.

## SERIATIM – CLAUSE A

Councillor Jared CASSIDY requested that Clause A, REPORT OF CONTRACTS ACCEPTED BY DELEGATES OF COUNCIL FOR MARCH 2026, be taken seriatim for voting purposes.

Councillor CASSIDY:

Just at the outset, I join the LORD MAYOR in calling out discrimination and particularly welcoming IDAHOBIT Day coming up as well, and also something horrific that happened in your ward, Councillor LANDERS, and close to mine yesterday, the day before, the last couple of days where the threat of attack on worshippers at the Masjid Taqwa Bald Hills Mosque. Just send our thoughts and best wishes and solidarity with those people as well, who were just seeking to peacefully pray and were preyed upon and threatened as well. So we should all call that out when we see that.

On Clause A, the reports of the contracts and tendering before us today, as the LORD MAYOR has mentioned, $238,000 for the Nudgee Beach platform, to construct that new platform, and residents are rightly saying it's about time out there. It wasn't quite enough, though, not quite enough money to bring back the viewing deck, which was much loved by locals and visitors out to that part of the Councillor interjecting.

Councillor CASSIDY:

Councillor interjecting.

Councillor CASSIDY:

world as well. A bit of a letdown for the community, given the extremely long wait they have endured for this rebuild.

The LORD MAYOR talks about all this investment in new things he claims is happening in parks. This is a rebuild of something that they let go and didn't maintain. The Story Bridge is the big one. The viewing platform at Nudgee Beach is a small example of that. When they build back, they don't build back better. They don't even build back the same. People are being short-changed out in that part of the world.

Talking about being short-changed, $235,000 for Pallara for Councillor KIM out there as well, but the LORD MAYOR really does need to visit the Pallara disaster himself. Now, we've heard that Councillor KIM —

No, exactly, yes. No, he won't Teams meeting with that one. He'll need to see that one in person and drive out there. Or he won't drive, let's face it. He'll be chauffeured there out there as well. But Councillor KIM has obviously followed through on her election commitment to fund those 2 new bus stops, so good on you. Promises made and promises kept by our newest Brisbane Labor Councillor on the team here, so that's great work to you. But that community needs so much more out there, as we know, and $250,000 for landscaping at Vied Road in Pallara. I mean, it's nice to have, but we know there are huge issues out there and they've been well canvassed as well.

We see $10 million in ferry terminal maintenance in there, which is, I think, business as usual. We've seen no real uptick in that funding this year from the LORD MAYOR. We know Brisbane CityCat network is probably—there's lots of great legacies from previous Labor administrations in this place, but the greatest river activation under a Labor Lord Mayor was Brisbane CityCat network, of course, and the introduction of $0.50 fares to boost that patronage under a Labor Premier and a Labor Government as well, not just benefits local residents but visitors alike.

We know that those experiences are really critical, because Brisbane is really lagging when it comes to international visitation, when it comes to other domestic experiences that people come to have here in Brisbane. We know the CityCats are something that they do and people aren't really staying more than one day in Brisbane as they're transiting through here. The LORD MAYOR talks a big game about those things, but Brisbane is struggling and businesses are struggling here, so making sure that our CityCat network is kept up to date and terminal maintenance is done is really critical. We need that investment to keep up as well.

It was this time last year we saw those reports of the overloading of a CityCat, almost causing it to sink into the river and people were directed to disembark. So we see this $10 million contract as important, but we do need to think bigger than just business as usual for Brisbane. We do need to have some vision as a Council in here about taking the opportunities of being an Olympic City, rather than just, as this LORD MAYOR does, continue on as a business -as-usual approach.

We're seeing $3.3 million being spent on a mobile parking app. Good to have choice, I guess, in that space, after 2 decades of continuous LNP rule in here. They've finally allowed the free hand of the market to enter into there and have one extra platform for that. But what we'd like to know, Chair—

I welcome that inaudible mumble from Councillor MURPHY over there. Very inaudible, wasn't it? Apparently. But what's the full story? Where does the money go? That's what people want to know. It's not going into paying down debt. That's still stubbornly high. It's not going into busting congestion. So, as we know, Brisbane's still the most congested city in Australia. Is it going into alleviating the housing and homelessness crisis by partnering CBIC with a community housing provider, perhaps, and some funding from Council, maybe? No, we know that it's not going there. According to the LNP, the homelessness crisis in Brisbane has been completely resolved through a one-off $500,000 donation to Emmanuel City Councillor interjecting.

Councillor CASSIDY:

Mission. I remember Councillor HOWARD saying that, stating on record that she believed that the homelessness crisis in Brisbane was completely solved.

There's monies going on newsletters, on billboards, on radio ads. Has anybody heard about the Brisbane Metro yet? Every second ad on commercial radio at the moment is a Brisbetter campaign begging people to Google the Brisbane Metro and telling them that they can catch one basically anywhere in Brisbane, until they actually Google the Brisbane Metro and find out they can't. It's not turn up and go, it's still running on a timetable, if in fact it does. What about all those people out in the suburbs of Brisbane? All those great stories we heard through Councillor GRIFFITHS that Councillor LANDERS was denying access to those people, to the people's Chamber here?

That money is also going on paid influencer collaborations, we know now, and the so -called Brisbane creators forum. We know if this was just promoting brand Brisbane, this would be okay, but it's not, of course. The LORD MAYOR's using it to promote the Schrinner regime in Brisbane and the LORD MAYOR's everything in Brisbane as well. He's using the resources of Council to build a personal brand. Sounds a bit like a regime, doesn't it? Just the sort of things that we see tin pot regimes around the world do.

Now, the LORD MAYOR talked about the Story Bridge concrete repairs, reckons that $300,000 is some sort of massive injection into the Story Bridge and its maintenance. We saw those closures over Easter. I think the LORD MAYOR might have been in Hollywood at the time or maybe rowing with the Harvard rowing team up in Boston, maybe. But that happened while he was away. Then we saw this announcement from the State LNP Government to put $2 million into a flying fox operated by a private operator. So the zip line which will go alongside the Story Bridge, that's a nice to have, but we still don't—maybe people will be forced to use that when the Story Bridge gets shut down again on the LORD MAYOR's watch.

Now, we have a LORD MAYOR that's been kicking the can down the road on Story Bridge maintenance for years and years and years, whether it was when he was LORD MAYOR, whether it was when he was the Chair of the Infrastructure Committee or the Finance Committee over the last 2 decades in this Council, he has had his fingerprints all over the Story Bridge debacle. While we've had some documents released in our Story Bridge RTI (Right to Information), which themselves are pretty damning—you wouldn't believe it, but this Administration has redacted all of the dollar figures, all of the options they're looking at in terms of— f—

Sorry, I slipped. It's not an Administration at all. It's a regime of secrecy here. So I hope the Office of the Information Commissioner will have a look at that, because I don't think the people Brisbane want the wool pulled over their eyes when it comes to the billion -dollar -plus rebuild of the Story Bridge and who is responsible for it falling into the river. That bloke. Congratulations to Councillor GRIFFITHS on the Salisbury Rec Reserve BMX jump tracks as well, long fought and well deserved for a project over there. The southside growing, as we know, an extra 15,000 people expected to move into and use the Salisbury, Moorooka— 15,000 to 20,000 people—area over there through that neighbourhood plan process as well. So that's important to see that advocacy from a local Councillor out there.

One million dollars for bus operator training program. BCC should be doing more to support apprentices and traineeships across this LGA (local government area) . We all have to play a part in increasing economic complexity training, resilient workforce and building a future made in Australia. We can't put on bus routes, can't run extra services, even if we have a LORD MAYOR that doesn't advocate for them, but if in some hypothetical world we did have a LORD MAYOR that advocated for that, we need the workforce to service it. So once we get these bus drivers trained up, it's important also to keep them here.

You can't keep bus drivers with poor facilities and unreasonable KPIs (key performance indicators), which especially impact women operating in our bus fleet. They took the bus union to expose how Council was treating our workers on the frontline and fortunately, it looks like some of those improvements to amenities are on the way as well, but we need to see improvements to safety and full driver barriers and more suburban services.

Chair:

Councillor CASSIDY, your time has expired.

Councillor COLLIER:

Point of order.

Chair:

Point of order, Councillor COLLIER.

601/2025 -26

At that point, Councillor Jared CASSIDY was granted an extension of time on the motion of Councillor Lucy COLLIER, seconded by Councillor Emily KIM .

Chair:

Councillor CASSIDY:

Councillor CASSIDY.

Thanks very much, Chair. So we need to see improvements to safety and full driver barriers and more suburban bus services, and we need to bring back that bus safety forum for ongoing discussions, not just one-off roundtables as well, something that's very important to the 2,000 or so Council employees who are bus drivers out there on the front line every day of the week.

On the amendments to the Brisbane City Plan Clause B, the Wynnum Centre Suburban Renewal Precinct. The Wynnum precinct plan has now been adopted by the State LNP Government. We have tried everything, Chair, at this point, not just here in Wynnum but across the city, but everybody following along to this process would know that. There are opportunities for Council to make these precincts better that they are simply not taking. No targets for affordable housing, no willingness to try inclusionary zoning, no inclusion of supportive housing anywhere in any of these plans.

Councillor ALLAN has previously wanted to know where such measures have worked and Brisbane's LORD MAYOR keeps criticising the City of London, because it has a Labor Mayor, by the way, and there's a reason why he hasn't mentioned anywhere else in the world, because there for many examples where these policies are working. In Sydney, a new inner-city residential suburb has just been greenlit by the State Government with a minimum of 10% affordable housing. It's a low bar, but it's something, right? No surprise why the median unit price there is now lower than in Brisbane.

" Vancouver has had targets for over a decade, both for overall supply and below market affordable stock " , a quote from local media there, the city did exceed its goal for approving new privately owned below-market rentals, recording 1,436 such approvals, more than the double annual target of 550. Coming soon to Adelaide via HomeSeeker SA, a 46 -hectare net zero community with 800 lots, offering diverse housing, including 25% affordable homes built with sustainable materials. Not just London but across the entire UK, just on 26,000 affordable homes, ranging from social rent properties to dwellings bought using shared and affordable ownership models were completed in recent years. These S106 (section 106) homes accounted for 44% of all 59,000 affordable homes built that year in the UK.

So whether it's here in Australia or overseas, affordable housing targets and inclusion rezoning can work, but our LNP regime here in Brisbane has chosen to ignore that fact, Chair. Instead, the LORD MAYOR has bent a knee to the private property development industry, who seek to exploit the housing and homelessness crisis to maximise profits and locals pay the price. We heard it today. Before the changes are even announced, the LORD MAYOR is groaning about changes to the CGT (capital gains tax) tax arrangements and negative gearing as well. So right on—Angus Taylor must have rung him up and said you'd better get the talking points and start arguing against this, Mr 12.5%.

So it's not controversial or radical, Chair, to believe, as Labor does here, that frontline workers who make this city tick deserve to live in a city that they serve. This Council is still not listening to the community's calls for infrastructure, particularly here in Wynnum, including drainage, greenspace, public transport, and active travel. Just on greenspace, too, assume the block that the LORD MAYOR is talking about—happy to be corrected—announcing today that CBIC will be developing into a commercial space, for commercial purposes plus 60 car parks, is greenspace sitting alongside the Woolworths building next to the old Wynnum school building, open greenspace. So sure, make that decision and make that announcement, but CBIC for years has not, despite the LORD MAYOR saying, paid a dividend to Council that exceeds the rent the Council pays it.

I don't know whether the LORD MAYOR just forgot that or conveniently left that bit out, but he also — again, we talk about using different ways of thinking and using different policy responses during a crisis to achieve a better outcome, but for the LORD MAYOR, in a place he says he wants to see—actually, no, he didn't, did he? He doesn't want to see affordable housing. He doesn't want to see rentals. He doesn't want to see first home buyers. He never said any of those things in this debate. He never once mentioned housing affordability. He never once mentioned rental affordability and he never once mentioned first home buyers.

The LORD MAYOR just talked about wealthy retirees. Now, sure, they want to have choice as well. Lots of choice for people who are selling houses for $2 million and $3 million around Brisbane to buy somewhere, let's face it. But for somebody struggling to pay rent in Brisbane at the moment, or looking with their partner and saying, geez, we're 27, 28 now, I'd love to buy a place, never going to happen. Never going to happen in Brisbane under the policies of this LNP Council. So what we are seeing around Brisbane now is the LNP approving, green lighting and enabling more homes for the ultra-wealthy. The luxury GRAYA apartments, of course, on Racecourse Road and St Lucia at West End with unit prices now ranging from $1.8 million to $2.2 million. New Farm with unit prices starting at $2.25 million and people have spent their whole lives working and living in a suburb are being completely priced out.

These planning changes, despite what the LORD MAYOR's rhetoric says, by their design now, don't make that any easier. The result of a lot of these zoning changes will be felt immediately. Blocks of land in Wynnum will increase in value today by, in some cases, probably millions of dollars through those zoning changes. Now, we know that developments in Wynnum, inside this precinct plan, are already going above the allowable height limits through performance-based planning outcomes. One development is going up at 12 storeys in a block that was zoned for 8 storeys. This development at least was occurring on land that today is worth a lot less than it would tomorrow.

The LORD MAYOR used all this rhetoric — that's just one example of development that's happening in Wynnum right now—used this rhetoric as if to say it was some sort of mothballed, dormant area that nothing was happening in and they'll only see development if this plan is put through, but that's not true either, is it? So what's really at play here, Chair, when you look at all of those facts and line them all up, all in an order? Does the LNP really believe that inflating the value of land for a very small group of people will benefit first homeowners? That's probably why they only talk about, as I said, wealthy retirees seeking to downsize in these debates. Not once today did we hear the LORD MAYOR talk about first -home buyers.

We know that the LORD MAYOR didn't listen to submissions from the Wynnum community and they're still frustrated they're not being heard. I like the line where he said you can't please everybody. Well, he pleased—on these numbers, 9 people and really bugged off 350. Seems the equation's a bit out and this is a trend we're seeing more and more. So this is the analysis of the public consultation: 351 submissions opposed to proposed building heights in some fashion in different locations, 282 raised traffic and congestion concerns, 260 raised the lack of parking as a result of development, not just putting in a car park—public car park that I presume won't be for people who live in units that can park there 24/7. I presume that won't be the case. I'm sure it will be timed.

One hundred and ninety raised loss of character and village feel, 187 requested more public greenspace—which they're now losing, and 175 raised inadequate infrastructure concerns, general Council infrastructure. By contrast, it was a much smaller number of submissions sought planning changes that were ultimately reflected in what is before us today. Nine people seeking additional height on larger amalgamated sites, 9 people sought the removal of proposed arcades , 7 people sought tower separation measured between buildings rather than boundaries. I wonder who those 7 were.

Six sought reduced front tower setbacks and got it, 2 sought the removal of mandatory 10% public open space on landmark sites and got it , one sought the removal of a 7 -metre maximum tenancy width and got it. I wonder who that small group of people were. So that was an uptake. For example, the LORD MAYOR's representative for the Wynnum Manly Ward, Councillor GIVNEY. Last week, we noticed a few videos popping up on social media where Council was explaining that people had reached out about legitimate concerns about local infrastructure and how local infrastructure was lacking.

Then the local LNP Council went on to say, what are you talking about? I'm here, everything seems fine, go away. The team went down, there's no problem. Your concerns are not valid, the community. Through you, Chair, to Councillor GIVNEY, in case it's passed you by, your job is to be your community's representative in this place, not the LORD MAYOR's representative out in the Wynnum Manly Ward. That's the fundamental misgiving that we are seeing from LNP Councillors left, right and centre. I guess when people today ask themselves, let alone in 2028, a simple question, is my Councillor in this community for me or for themselves, the LNP are clearly falling on that ledger.

Chair:

Councillor CASSIDY, your time has expired.

Councillor DIXON:

Point of order, Chair.

Chair:

One moment, please.

Point of order, Councillor COLLIER.

## 602/2025 -26

At that point, Councillor Jared CASSIDY was granted an extension of time on the motion of Councillor Lucy COLLIER, seconded by Councillor Charles STRUNK.

Chair:

Councillor CASSIDY:

Councillor CASSIDY.

Just 2 minutes. Audit Committee meeting report, this is a really important one. We — and I've put this on record before—trust the work of the Audit Committee. I think it is a thorough process. However, we don't support what is given to us as oversight of the work of the Audit Committee. It is getting worse and worse when it comes to transparency. There are some critically important things that the LORD MAYOR said the Audit Committee he was looking at, but nobody, LNP Councillors and Labor Councillors alike, are given all the information that we need to be satisfied that those really critical and serious issues are actually being addressed.

The CEO used the meeting to discuss supply chain concerns with the war in the Middle East. What has Council done to ensure that we have access to fuel? The LORD MAYOR said it would be a big problem if we didn't have access to fuel, but what has Council actually done and put in place to ensure that we do have that continuity? We have contract obligations, not just with Translink, but with the people of Brisbane, to make sure the public transport services operate, to make sure that garbage services operate as well. Despite us proactively reaching out to the CEO and asking those questions, we remain as much in the dark today as we have been over the last few months about what Council's response is.

Twenty-one Queensland councils, including Moreton Bay, Redlands and Noosa near us, have implemented fuel monitoring tools through their disaster dashboards, but apparently Brisbane City Council doesn't need to worry about that, because secretly they have some secret plan, which they won't share with us.

Updates on learnings from ex-Tropical Cyclone Alfred. This does need to be ongoing because there are a lot of critical issues that happened during the response to Tropical Cyclone Alfred that Council didn't get right. There are still things— and I know the LORD MAYOR wasn't here to do the advocacy work for the Federal Budget and left it to others, I think, to do that, but there are still fences, playgrounds, public assets that are damaged, were damaged by Tropical Cyclone Alfred, that are still covered in orange mesh. So if we have missed the boat, if Councillors missed the boat on accessing Federal funding for the rebuild of those assets, what's the plan going forward?

The public have very little confidence in the LNP to be able to manage not just, I guess, the response as it happens to the disaster, but also all those ongoing issues. Some 13 or 14 months on since, I can look out the window of my office and look at the Einbunpin Lagoon playground, which itself is in a shocking state of disrepair after spending 25 years serving the community with no plan to replace it, and see the fence is still crumpled with orange mesh around it. It's absolutely incredible, but most concerning—they are small things that can be fixed, right? Just need a LORD MAYOR and a Council that cares about that stuff.

But what is really concerning is the discussion around debt restructuring. Usually when a large company is about to go kaput, what you start to see is discussions around debt restructuring. This strategy is rolled out usually to avoid default, bankruptcy, and to keep cash flowing on a day-to-day basis, basically. Granted, there are risks and uncertainties in today's geopolitical environment, but a healthy organisation should buffer for this in advance.

I guess we're not just concerned that these discussions are having to be had now about debt restructuring, but also the secrecy around them. We don't know what those discussions were and what the strategies are in place to mitigate against them. We're never going to be told in any financial updates or budgets that no longer get printed and distributed and no longer include any of this information in them at all. We want more, as Councillors — and we should all want this —m —more details and assurances that we're in a position to pay creditors what they are owed by Council. What we know the LNP would do if they can't is privatise the gains and socialise the losses here in Brisbane. Somebody is going to make profits off the back of ratepayers.

This should concern everybody here, because the LORD MAYOR has today painted this rosy picture and has tried to convince anyone who's listening along, mainly probably his own side, that there are no problems in Brisbane. By raising serious concerns about whether it's broken footpaths that are causing people to be maimed and injured, covered in blood, the LORD MAYOR's response to that is it has never been better. It just doesn't quite equate. So we should all be concerned and we should all be asking questions and that's what these debates are about here today.

So I look forward to LNP Councillors also raising those concerns. Maybe they're not allowed to do it publicly here, but you certainly hope at least they would behind closed doors start to read these documents and ask some questions, rather than just being rubber stamps for this LORD MAYOR.

Councillor DIXON:

Point of order, Chair.

Chair:

Point of order, Councillor DIXON.

## PROCEDURAL MOTION – ADJOURNMENT

603/2025 -26

It was resolved on the motion of Councillor Julia DIXON, seconded by Councillor Greg ADERMANN, that the meeting adjourn for a period of 15 minutes, to commence only when all Councillors had vacated the Chamber and the doors locked.

Council stood adjourned at 3.16pm.

## UPON RESUMPTION

At that time, 3.31pm, the Deputy Chair presided at the meeting.

Deputy Chair:

Further speakers?

Councillor PARRY:

Deputy Chair:

Councillor STRUNK:

## Councillor PARRY.

Thank you, Mr Deputy Chair. I rise to speak on item A, specifically the Hickey Park playground upgrade. To say that I'm excited about this upgrade would indeed be an understatement. I've taken my own children to this playground many, many, many, many times and I know that it's heavily used by local families. It's in one of those perfect positions where it's located next door to a longstanding kindergarten, the Emily Foord Kindergarten. It's also behind Stafford State School, as well as being very well connected to the Kedron Brook Bikeway and other communities from Stafford all the way through to Gordon Park. It's in that that sort of prime location.

Soon new families will be able to enjoy a better park in a better location. We are going to move where that park is located close to the trees, which was showing that it actually damaged some of the trees nearby, and moving it out and providing a bit more space for new equipment to be enjoyed by all of the local children that go there. There'll be new slides, swings, play panels, a glide and ride, which I've always called a flying fox, but a glide and ride sounds much better. Monkey bars, of course, a shade structure and more seating and better seating that's better connected, again like I said, to the footpath and to the Kedron Brook Bikeway.

I'd just like to say, Mr Deputy Chairman, one part of this whole process I would really like to acknowledge, that's the work of all the Council officers that have kept my office engaged in this process, to work out what the local community wanted there and what would make it even better for local families. These playgrounds are designed to last decades, but it's important that we think about the future and we think about what the community may need in decades to come. It was really important that we spoke with local residents, with local families, particularly, like I said before, a lot of those families from the Emily Foord Kindergarten.

It's a real hotspot for when you're dropping your child at kindy, if you have another child there you go and you play with them for a little while to take a bit of time while you're enjoying that morning coffee. You also organise a lot of playdates and things like that due to the close proximity, so it was really important that we got their feedback. Their feedback was they wanted a bit more, I suppose, challenging equipment in that area. They wanted things that could cater to more than just a certain age group. It's up to—it's our role, it's incumbent upon us to provide that to these families, because we want them to enjoy our parks, that's what they're there for, right? The reason we have parks are for people to be in them and for people to be in them and enjoying them in the right way. That's what will happen with this upgrade.

Can I particularly thank Rob McTackett, Rob is the project manager. I met with him this morning, he's doing a fabulous job at keeping this project together and he will deliver this one in the next few months. We've also got Rebecca who—I was going to pronounce her name Deslandes because it's French, but it's not pronounced that way. It's Deslandes, which is far more comfortable for me to say, so thank you very much, Rebecca. Also—because Rebecca is the one that did most of the outreach with my office—of course to the inimitable Tom McHugh, who is my Outcome Manager, who is a brilliant man and a very hard worker and again told me exactly how to pronounce Rebecca's name when I asked for it.

Merci, Tom, for helping me with that and not allowing me to embarrass myself, even though I think I just did. I cannot wait for this playground to be completed. I can't wait for the community to enjoy it and I can't wait to take my boys there to have a play on this brand new playground. I commend this item to the Chamber. Thank you.

Further speakers?

Councillor STRUNK.

Thank you, Chair. I rise to speak on Clauses B and C and maybe I'll start with C first, the audit report from the Audit Committee. I've been here 10 years and I've looked at all these, I've looked at all the minutes that come through for the Audit Committee and of course it's the same old same old. I mean, they tell you what ensure that people of all ages and backgrounds and life stages can continue to find a home in our beautiful city. Deputy Chair, I think it's important that I address some of the hypocrisy that we've heard from those opposite here today. Because while Labor members may now attempt to criticise the proposal, it was actually the Member for Lytton, Joan Pease MP herself who wrote to the LORD MAYOR in December of 2022, specifically calling for Wynnum Central revitalisation and updated planning controls to support the redevelopment and increased housing supply in the Wynnum CBD.

|                          | the topics are going to be, but they don’t tell you any details of what they’re talking  about or what they’re reporting.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      |
|--------------------------|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Councillor interjecting. |                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                |
| Councillor STRUNK:       | Secret. Anyway, so we got used to that. But when I saw debt restructure, I said to  my leader, I said, ‘in 10 years I’ve never seen those words used in an Audit  Committee report, in 10 years’. Then I thought well what does that actually mean,  debt restructure? I thought I’d better—you know, listen, I’ve been through a  couple of corporate debt restructures in my business, time in business. Not  directly, but indirectly and I felt the issues that came out of that. We got through  them, by the way, both times and I kept my job, which was nice. Anyway, so basically what it boils down to, as the leader said here, it’s basically                                                                                                                                                                      |
| Councillor interjecting. |                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                |
| Councillor STRUNK:       | Their viewpoint of the truth, which is fair enough. But they honestly, they said all  these precincts that are being rolled out, there is no affordability in these units. It’s  basically all units, towered units, whether it’s down at Wynnum even, or  Carindale, or Indooroopilly, or Nudgee or wherever. Honestly, even in my— where I live, Forest Lake and on the right next door, affordability is a real  challenge now, even in those suburbs. Honestly, what’s going to come first? Are  we going to have some kids when we get married and then just rent, if we can  afford to, but just rent and then wait until we’re about 40 or 50 to buy a house? Or  do we buy the unit or house first and then have the kids in our late 30s and 40s?  That’s the choice nowadays in this city. We’re not doing anything— |
| Councillor interjecting. |                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                |
| Councillor STRUNK:       | I know, we’re not doing anything about it. We talk—the LORD MAYOR talks  the talk, but sometimes he acknowledges affordability, but what are we doing to  overcome the issue? Yes, Council only has limited resources or limited levers to  be able to do something, but we’re really not doing very much at all. Honestly, for  those Councillors in this Chamber that are starting their families, or maybe the  families are into teenage years. Honestly, without your help, they probably won’t  be able to buy a house.                                                                                                                                                                                                                                                                                                  |
| Deputy Chair:            | Councillor STRUNK, your time has expired.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      |
| Councillor STRUNK:       | Thank you, Chair.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              |
| Deputy Chair:            | Further speakers?                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              |
|                          | Councillor WOLFF.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              |
| Councillor WOLFF:        | Thank you very much, Deputy Chair. I rise to speak on item B, the Wynnum  Centre Suburban Renewal Precinct Plan. With growth comes a responsibility to                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         |

In that correspondence, Ms Pease acknowledged that there was a ground swell of interest in the redevelopment of Wynnum CBD and stated that her support for increased housing in Wynnum CBD will help address housing pressures and deliver economic benefits to the community. My question to those opposite is simple. Was that genuine then, or is this simply being opposed now because it's politically convenient? Because this Council has actually done the work. We have undertaken the planning, the consultation and the refinement needed to responsibly deliver the very outcomes that Labor representatives themselves have previously called for.

Deputy Chair, we know that there will always be concerns raised whenever change is proposed and today, we have heard this from those opposite, with their negative arguments. Councillor CASSIDY has claimed that infrastructure won't cope, but the reality is that this precinct has specifically been identified because it's already a well -serviced location with access to rail, shops, services, employment opportunities. Strategic infill in existing centres is exactly how we reduce urban sprawl and make better use for existing infrastructure rather than sprawl and pushing growth endlessly outward. This is the beginning and further infrastructure will flow, we've heard just earlier today from the LORD MAYOR, who gave us an example.

There's also been claims that the community has not been properly consulted. Again the facts say otherwise. Council has undertaken extensive consultation, including in-person talk to planner sessions, direct letters to residents and businesses, online engagement, public notices, community information centres and more than 500 submissions were received and carefully considered throughout that process. This is exactly what the suburban renewal precinct is all about. We need the Wynnum Centre Suburban Renewal Precinct—is about representing well -planned growth in a location already supported by transport, services and community infrastructure.

Importantly, this is not growth for growth's sake. This is about making sure young people can stay in the communities where they have grown up. It's about giving downsizers more housing choices close to services and public transport. It's about supporting workers, families and older residents who increasingly need access to more diverse and affordable housing options. This is about more homes. If we fail to increase housing supply in appropriate locations like Wynnum centre, we risk pushing future generations further away from jobs, transport and established communities.

Deputy Chair, our city cannot sit still. The question is not whether Brisbane is growing, it's whether we plan responsibly for that growth. This amendment shows that we can increase housing supply while still protecting character, improving connectivity, supporting local businesses and creating vibrant communities for people at every stage of life. That is what good planning looks like, that is what we are doing and I commend this amendment to the Chamber.

Deputy Chair:

Further speakers?

Councillor CHONG WAH.

Councillor CHONG WAH:

Thank you, Chair.

## SERIATIM – CLAUSE C

Councillor Seal CHONG WAH requested that Clause C, REPORT OF THE AUDIT COMMITTEE MEETING ON 2 APRIL 2026, be taken seriatim for voting purposes.

Councillor CHONG WAH:

Deputy Chair:

Councillor GIVNEY:

I rise to speak on E&amp;C Committee report Clause B regarding proposed amendments to the Wynnum Centre Precinct. Our City Plan is meant to be democratic. The Wynnum Centre Precinct planning process has felt like anything but democracy. This plan came from big businesses, not residents. Residents were denied transparency by this Council and their voices were not being heard in this process. Once again, density can be great. Dense, affordable neighbourhoods that are co-planned with residents around major public transport nodes, with tree canopy, parks, public pools and libraries and much more sustainable than clearing forests for urban sprawl.

This precinct already allows 5 to 8-storey buildings and some apartments have already popped up. But trains through the precinct only run half an hour, hourly, during the day and bus services are shocking. It contains just one park. Residents have flagged all the different infrastructure that will be needed to handle more people. This money should come from the developers who are making massive profits from the housing crisis. The Council's infrastructure charges aren't enough, which is why the Greens have called for value uplift charges or higher infrastructure charges. Much of the precinct is also being land banked. Speculators bought land, built nothing and lobbied the Council to increase height limits for years. Raising height limits hands those speculators millions in property value for nothing.

Apartments that are built don't have to be affordable. At this rate, none of them will be. Over 11,000 people are on the public housing waitlist in the Brisbane City Council area. Thousands more pay over a third of their income for sky-high rent. Only 6% of housing in Wynnum is public or community housing and this amendment won't help. We can't just hope that some new housing or homes are affordable. We can't just hope that raising height limits will magically make developers flood the housing market and drop prices at lower profits. That's failed. Brisbane's house prices are the proof. We need to mandate it through levying vacant properties and through requiring 25% of dwellings in each new development by giving up to public and community housing providers. We need vacancy levies and we need mandatory inclusionary zoning.

Residents have clearly called for more tree canopy and greenspace and parkland in this precinct. They were excited for each lot to contribute 10% of the site to new public open space, but this Council has decided against it. Developers will only be required to contribute 10% of the site deep planting and none to new public space. Through loopholes, developers will whittle that down to almost nothing, just like in Milton, in my ward, continuing the massive loss of Brisbane's tree cover. We know that's what science tells us. More concrete traps heat in our cities to the urban heat island effect. Trees cool our cities through transpiration and tree canopy interrupts part of the urban heat island process.

We need more greenspace and deep planting to be resilient to heatwaves and climate change. Brisbane can't sustain the kind of development being voted on here today. Residents knew all of this and told the Council Administration. Over 500 people poured time into submissions for the Wynnum Central Suburban Renewal Precinct Plan. They proposed sustainable ways to reshape the precinct, to keep the neighbourhood cool, to make space for the public and to put people over big businesses. That's who this Council should be listening to. Thank you, Chair.

Further speakers?

Councillor GIVNEY.

Thank you, Deputy Chair. I rise today to speak on item B, the Wynnum Centre Suburban Renewal Precinct Plan. I want to begin by acknowledging something important. This is an emotive topic. For many people, Wynnum is not just a suburb; it is home, it is family history and community connection. I understand why residents are passionate about the future of our bayside, because I am too. But part of caring deeply about a place is being willing to have honest conversations about its future. The reality is Brisbane is growing, Wynnum is growing and whether we like it or not, we are already seeing increasing pressure on housing affordability, rental availability and the viability of local businesses.

Deputy Chair:

Councillor KIM:

Doing nothing is not a plan. These changes to City Plan are a lever that Council can pull to unlock potential in Wynnum. It is the first step planning for Wynnum's future, while still protecting the character that makes our community so special. At its heart, this plan is about 3 things, housing, local business and creating a stronger Wynnum for the future generations. One of Brisbane's biggest challenges facing our city right now is housing supply. Young people are struggling to enter the market. Older residents are looking to downsize in the community that they love. Families are competing for limited housing stock. We cannot continue wanting our children or grandchildren to live near us if we refuse to create opportunities for more housing.

Importantly, this plan does not mean transformation overnight and it does not guarantee immediate development. In fact the existing City Plan from 2009 already allowed for buildings between 5 and 8 storeys in parts of the precinct. In 16 years since, only a dozen developments have occurred. Even the Flinders Building, standing proudly on Bay Terrace today, was built almost 50 years ago in 1977 at 6 storeys. This will now be zoned for 8. Following community consultation, changes were made in response to feedback, including reduced building heights in some areas and stronger design outcomes. Much of the feedback related to infrastructure, which is understandable. I agree, infrastructure must keep pace with growth.

However, the City Plan changes do not determine specific upgrades to roads, parks and public transport. Those matters are considered separately through the Local Government Infrastructure Plan, or the LGIP. I will continue advocating strongly to ensure that our infrastructure keeps up for the needs of our growing community. But I think it's important that we also understand how infrastructure planning works in reality. We do not build a 6-lane road to a paddock because one day houses might appear there. We build infrastructure in response to communities growing and changing. That's how every city evolves. Growth informs infrastructure investment and infrastructure investment supports growth.

I will continue working closely with our Council teams, the relevant State Government departments, QR (Queensland Rail), Urban Utilities, Energex and other key stakeholders, to ensure Wynnum receives the investment in infrastructure we need as we grow. Those who know me know I'm not backwards in coming forwards and I'm not afraid to ask. Let's be clear, this precinct plan is not the finish line; it is the first step. It is the first step toward an activated CBD, toward more housing choice and toward supporting local restaurants, cafés, retailers and small businesses that are currently doing it tough. Without enough people living close to our centre, local businesses struggle to survive. Foot traffic matters, local spending matters, community matters. A thriving CBD needs people working in it and living by it to support it.

Importantly, this plan is not just about building height. It also includes opportunities for better public spaces, stronger pedestrian connections and more street trees and improved connectivity between the train station, the CBD and our beautiful foreshore, a foreshore which we are also investing in. We look forward to sharing the master plan soon. Good planning is not just about freezing a suburb in time. It is about carefully managing change so Wynnum is liveable and sustainable into the future. I understand that some may not agree with this plan, but leadership is not about avoiding difficult conversations and decisions. It's about balancing the needs of today with the responsibilities we have to future generations. I believe this plan takes an important step toward doing exactly that. Thank you.

Further speakers?

Councillor KIM.

Thank you, Chair. Just in response to the Councillor for Wynnum Manly, I think it's important to also note that Joan, when she originally wrote that letter, actually talked about social housing, which we didn't hear once from across the Chamber from the Councillor for Wynnum Manly. We didn't hear about affordable housing, about social housing, about all the things that the residents of this ward need. We look forward to hearing a real response for the 300 residents who are very upset at that public meeting where they were clearly not consulted with.

Continuing on today, I rise to speak on Clause A, the $200,000 of landscaping finally in Pallara on Vied Road. Hooray, thank you, LORD MAYOR, who's not here today after 2 hours of the first Council meeting back, he's already gone. This is only $200,000 out of the $100 million he finally promised our community from his $4.1 billion budget, after months of our community urging the LORD MAYOR to come down to Pallara and fix the Pallara disaster. After writing letters and letters to him and receiving no adequate response, visiting his office even though the door was closed and now there's a ring doorbell, only to make it even harder to get into his office for the public to speak to him. Tried calling him and then it reverts to the contact centre phone number for some reason.

He is becoming increasingly out of touch and you could see this with his travel to LA. You could see this with his response today, which simply didn't answer the question to the number of residents that have been hurt in the last 2 months in which he hasn't been a leader for our wonderful City of Brisbane at a time when we need it the most. If we put this $200,000 figure into perspective, we just heard from Councillor GRIFFITHS this morning that it cost $180,000 over 2 years to build a very critical footpath, a basic structure, which still isn't there, as well as the almost $300,000 cost that it will take from my Council Suburban Enhancement Fund to build a traffic island in Pallara.

The LORD MAYOR is offering $200,000 from his $4.1 billion budget. Meanwhile, from the Calamvale Suburban Enhancement Fund, we're spending over $300,000 if we include the $20,000 concept designs over the last year, 2 versions of them, to build a traffic island, a basic infrastructure piece, despite the fact that the LORD MAYOR's own traffic impact assessment report from 2041 states that there will be an increased likelihood of angle crashes at every major intersection on Ritchie Road. The LORD MAYOR refusesto come and visit the residents of Pallara. He wants to Teams meeting them. He hasn't even provided that offer either. He doesn't want to meet us, he doesn't want to talk to anyone in the area.

In fact, what the LNP have received is an over $100,000 campaign donation from a major property developer in Pallara. It's important to note this, because now he's spending $200,000 back on the community for landscaping only. We hear buzzwords from the LNP as if they're cosplaying to be urban planners today. 'Urban sprawl, urban sprawl' well look at what they've done to our outer suburbs, a place where, compared to the inner suburbs or maybe to the Walter Taylor Ward, you see families with lower incomes, new families coming here for the first time. Yet they don't have access to basic public transport services, basic safety infrastructure. We have residents tripping over and literally injuring themselves and being hospitalised, but all the LORD MAYOR has to say is nothing.

He comes in here, he answers the Councillor GRIFFITHS' previously and all he says is no to the outer suburban residents of Brisbane City Council. It's no wonder why at the last election the LORD MAYOR lost the vote at Pallara. This is only the start of change for all of the rest of Brisbane City and every Councillor here knows it because they know that they are up against it. They know that there is pressure, they know that there is a demand. The worst traffic congestion in all of Australia being in our city right now, yet he goes over to Boston for leadership training because he thinks that that's going to change the outcome. He goes to Hollywood and enjoys his time there. He goes to Boston and he thinks that that is the answer to a problem that is going to impact generations and generations of people in Brisbane city. It's disingenuous and it's simply not good enough.

That's why last night I spent it talking to residents on Kraft Road, where yet again this was an example, just straight down the corner from the new junior school campus and Pallara State School. On this road there is hooning, there is illegally dumped rubbish everywhere. LORD MAYOR, clean the streets and stop hiding from us right now. Stop hiding in your office, stop hiding from our Council meetings here. Why is it so hard to speak to the leader of the biggest city council in all of Australia?

Councillor interjecting.

Councillor KIM:

In the southern hemisphere as well. It’s simply not good enough. Aside from Auckland, thank you, LNP, for correcting. The only time they speak up in this Chamber— r—

Councillors interjecting.

Councillor KIM:

—b —but doesn’t speak about anything else that’s important here. LORD MAYOR, I hope you’re listening today and if you’re not, we’ll make sure the residents continue to contact you like they have been every single day.

Deputy Chair:

Further speakers?

Councillor ADERMANN.

Councillor KIM:

Point of order.

Councillor ADERMANN:

Yes, thank you, Deputy Chair. I rise to speak on item—

Deputy Chair:

Sorry, Councillor ADERMANN.

Councillor ADERMANN:

Sorry, you’re not finished?

Deputy Chair:

Your point of order.

## PROCEDURAL MOTION – SUSPENSION OF STANDING RULES

604/2025 -26

It was moved by Councillor Emily KIM, seconded by Councillor Lucy COLLIER, that the Standing Rules be suspended to move a motion that this LNP Council recognises Pallara as a sister suburb to the Council Administration, in order to enable the LORD MAYOR to travel more than 5 kilometres from the CBD to finally visit a suburb within his own City Council.

Upon being submitted to the Chamber, the procedural motion was declared lost on the voices.

Deputy Chair:

Councillor ADERMANN:

Councillor ADERMANN.

Yes, thank you, Deputy Chair. I rise to speak on item A, in particular about 2 contracts that have been awarded for projects in my ward. They are for the replacement of a toilet block and wastewater treatment system at the Gap Creek Reserve, Mt Coot-tha, and for a new playground at Merri Merri Park, Chapel Hill. Deputy Chair, the Gap Creek Reserve at Mt Coot-tha is one of the more popular parks in the Pullenvale Ward. The tracks are well utilised by walkers and mountain bikers alike, while families enjoy taking advantage of the shelters, barbecue and open spaces to relax, particularly on weekends.

The existing toilets at the reserve are old and have seen better days, so the decision was made to replace them with a new disabled compliant toilet block. I'm advised work is expected to commence soon on building the new block closer to the main shelter, which will be much more convenient for visitors to the reserve. Work will hopefully be completed by the end of June, but in the interim, the existing toilets will continue to be used while work on the new block occurs and then they'll be removed after the project is completed.

Deputy Chair, if I can indulge, it's great to see the number of local riders now taking advantage of our dedicated tracks at Mt Coot-tha and in particular our new Crebra Climb trail at Gap Creek Reserve. The 1.8 kilometre trail was built mostly by volunteers as part of Council's trail care program. A total of 66 volunteers spent more than 250 hours working on this trail. I recently spent time with a number of them at the Gap Creek Reserve to thank them for their efforts as part of the Trail Care program. Crebra Climb was designed to meet international mountain biking standards and requirements, including wider trails, widths and larger turning circles. This project marks a significant step towards completing a full green loop that is suitable for adaptive riders, depending on skill level and equipment and that is accessible to riders of all ages, abilities and skill levels.

Establishing more green rated trails and adaptive friendly trails was a key outcome of the Schrinner Council's Mt Coot -tha Reserve Mountain Bike Concept Plan. Deputy Chair, even more exciting are the additional tracks proposed as part of our Deputy Chair:

Councillor MASSEY:

concept plan. The first one is the upgrading of the existing Death Adder trail and the second is the creation of a new trail to be called Carpet Snake, which will connect the existing Crebra Climb and provide a return section back to the Gap Creek picnic area. Future planning includes a new skills trail besides the Gap Creek picnic area, but that's a story for another day.

Deputy Chair, the other contract that has been awarded in my ward relates to a playground upgrade at the popular Merri Merri Park at Chapel Hill. Like the previous project, the old playground had seen better days and was nearing the end of its life. It was certainly not a playground that I wanted to see lost to the local community, so I listed its upgrade as a priority for capital funding in the 2025-26 Schrinner Council budget. Naturally, I was over the moon when this was approved and in conjunction with Council officers, we've been working on a new modern play area to meet the needs of the families who live in this part of Chapel Hill. In designing the new playground, we were left with little choice but to relocate it away from the existing heavily shaded area because of the large tree roots.

The cost of the shade cover was not included in the initial budget allocation, but it nevertheless is an important element of this project, so I agreed to cover that through my Suburban Enhancement Fund. I popped out to Merri Merri Park last week to have a look at progress and can advise that the old equipment has been removed and that earthworks for the new play area have been undertaken. Hopefully the new equipment, the new play equipment is on its way and the Chapel Hill community will soon have an exciting and modern new playground to enjoy for many years to come. I support the Chamber's—I urge your support for this item. Thank you.

Further speakers?

Councillor MASSEY.

Thank you, Deputy Chair. I rise to speak briefly on all items, if I can. Firstly, I want to speak to the contracts, just on 2 very specific things. Firstly, the Story Bridge. To remind everyone again and again and again that the footpaths have probably about 2 years left. That's it, that's their lifespan. The fix that was done last year was superficial. It is on top and the footpaths continue to keep crumbling. Of course the iconic Story Bridge needs to also maintain. It's going to cost billions of dollars and no business case, no $300,000 patch-up of lamps leading up to it will change the fact that the Story Bridge footpaths are near end of life and this LNP Council is doing nothing about it.

Secondly, I just want to talk about the ferry maintenance, network maintenance. I know that the maintenance for our ferry terminals and for our ferries is incredibly important, because we've had such a huge increase in them. It is good to see, but we know the pressures of the ferry network are continuing. We know that Riverside ferry terminal is also nearing end of life. Again we are nearing end of life on all of these key infrastructures, items and this is all happening, of course, under the LNP Council.

We also know that there has to be an expansion of our ferry terminal. This was basically acknowledged during—at the start by the LORD MAYOR, who isn't here, when they talked about pushing the Federal Government for a network review, noting that we do our own networks review and that we already know the gaps in the ferry terminal system, which moves me on to item B. Ferry terminal is a good link for that and this is directly, through you, Deputy Chair, to Councillor GIVNEY's debate. The LGIP and how density comes from another way. Well, guess what? The neighbourhood plan that was moved in West End that promised a ferry terminal in 2011, second one, because there is a 5.5-kilometre gap of ferry services on the southside, still hasn't been delivered 15 years later.

The idea that the LGIP, all these — is going to deliver things. The idea, we've supported this LGIP just recently, because we want to believe in it, but to come up here and say that Council, under the LNP Administration is increasing density and then afterwards delivering the infrastructure that these areas need. Well, just look like — through you, Deputy Chair, I welcome a meeting with Councillor GIVNEY to explain how West End has received none of that, after the density Councillor interjecting.

Councillor MASSEY:

Deputy Chair:

Councillor HUTTON:

kept increasing. Another thing about West End is it didn't get cheaper. We increased supply, this Council increased supply and it didn't get cheaper.

The Wynnum Manly plan has no affordable housing, no social housing, already has developers that are pushing the barrier because we have a performative, a performative planning system. It has buses, no, rarely. The trains currently aren't running every 30 minutes, of course, thanks to the LNP State Government. This is where we are with it. This idea that this is going to provide for young people, for first -home owners, for renters.

Well I can't say that word, Councillor CHONG WAH, but I do agree. You can all imagine what word Councillor CHONG WAH just said. Lastly, I just want to talk about the edit— t— the Audit Committee. I've got a couple of minutes. The edited Audit Committee, heavily audited. I think the most important thing to state here is that the war in Iran that has spread through the Middle East, through Gaza and also Lebanon, is causing fuel shortages. Through this document, it talks multiple times about risk, because of course our bus fleet is predominantly diesel. We haven't transitioned completely, I think it's 82% diesel. Our ferry fleet is diesel, the contracts that we have to waste management is diesel trucks. Even though this risk keeps getting talked about, none of the Councillors involved, maybe even over on that side of the Chambers, have the details. Maybe they don't want to ask the details, but if this Council is at risk we should all know.

Councillor MASSEY, your time has expired.

Further speakers?

Councillor HUTTON.

Thank you, Mr Chair. I rise to speak about item A, contracts and tendering. The item is about practical works that sit behind the services that residents rely on each and every day. Mr Chair, I am very proud to be talking about the replacement of the air conditioning system in our Mitchelton Library. Chair, libraries are some of the most important community facilities that we have across our city and it's really important that we make them spaces that are safe, comfortable and most importantly, reliable. They are essentially community hubs. In our hot Brisbane climate, we want to keep those spaces comfortable and that is essential.

Now Mitchelton Library has been serving the local community for more than 40 years. It is well-used, well-loved and plays an important role for residents in Mitchelton, Enoggera and surrounding suburbs. But like any hardworking community facility, the building needs investment from time to time to ensure it remains fit for purpose. The air conditioning system at Mitchelton Library has reached its end of serviceable life and thus we are in the process of replacing it. Contract for these works was awarded on 2 March 2026 and works are scheduled to commence in mid -May.

Because of these works, the library will need to be temporarily closed while the air conditioning system is replaced. The last day of service before the closure will be this weekend, Saturday 16 May, so make sure you rush in and pick up your books. But don't worry, just because we are closed at Mitchelton does not mean that all of our libraries are closed. You have local libraries at Everton Park, which is only 3 kilometres away, Grange Library and of course Ashgrove Library. These nearby branches will be more than happy to welcome customers from the Mitchelton Library while it is underway.

We also have our pop-up library that will be delivering our First 5 Forever children's storytime in Sid Loder Park, adjacent to Mitchelton Library, so the kids will not miss out. These sessions will run every Tuesday from 19 May until the library reopens, with sessions at 9.30 and 10.30, weather permitting. It's also good news that the local library deck will be open, which means that the Mitchelton Library café remains open, so you can still pick up a coffee and enjoy some of the free Wi -Fi while the works are being undertaken. Mr Chair, this is just our continued investment in the suburbs. We love creating more to see and do in our Deputy Chair:

Councillor GRIFFITHS:

Deputy Chair:

Councillor WINES:

suburbs and we know just how much our library network is loved by the residents of Brisbane. I commend this item to the Chamber.

Further speakers?

Councillor GRIFFITHS.

Thank you, Mr Chairperson. I rise to speak on E&amp;C, particularly items A and B, contracts and Wynnum central sellout. In relation to item A, contracts, I'm pleased to say that finally the Salisbury BMX site—we're building a new BMX track at Salisbury, is going ahead. This project came about prior to the 2024 election, when I met with some young people and their parents, who were very keen on getting a bike track down there, a dirt track down there. It's been really great to have them involved in designing and giving their feedback about the dirt track. I, like some of the LNP Councillors, do extensive consultation before I do anything in the parks and I think that's really important. I don't think you just go and drop something in a park. But the original price that I got to build this dirt BMX track, which I thought was quite steep, was $90,000.

Can you imagine my surprise in 2025, when Council came back to me and said the price had increased? What do you think it might have increased to, $120,000, $150,000? Try $450,000, for dirt. Same amount of dirt, gone from $90,000 to $450,000. Thank you, Councillor MURPHY for your delivery of that dirt. That has been 2 years that we've been waiting for this project to be delivered, 2 years, 2 years. Our creaky organisation's gradually getting there, gradually, but it has not been an exceptional experience from my side of things. Being in Council 23 years, I've seen this place function so well. At the moment, it's like a car with square tyres, it's just not going anywhere. Anyway, I look forward to that particular project being delivered. I look forward to the young people—meeting with them. I've had to apologise on multiple times, because Council just has been so slow at delivering.

Now the second thing is the Wynnum plan, what a sellout. What a sellout by the LORD MAYOR, what a sellout by the Councillor, what a joke. You've been sold out, Wynnum, you've been sold a pup. The Liberals have wanted to get their hands on Wynnum for a long time and now they've done it and they're selling you out. I don't have it here today, but the Better Suburbs Board, that little group of well, Liberal developers or mainly Liberal developers, who deal directly with the development community, then go and deal directly with our planners, that little group, they had a list and Wynnum was all over that list.

I'm not allowed to release that list to the public, but Wynnum was all over that list and sites contained in the Wynnum CBD are all over that list. There's people, developers rubbing their hands because we have a Liberal Council and we have a Liberal Mayor who is prepared to sell the city out at any cost. He calls it housing, they call it housing, but it's not housing; it's looking after developers. That's what this Council, 23 years of this Council, that's what it stands for. It doesn't stand for infrastructure and it doesn't stand for affordable housing for our kids or our nephews and nieces. No, they're just about developers. I think this is a shocking plan. I haven't seen Councillor GIVNEY's submission, I suspect there is no submission. We don't even know how many extra people are going to plonk in to Wynnum.

What a sellout and it's happening all over the city. You happen to meet a Westfield owner, let's give him 30 storeys. You know what, when we rezone this land, we're giving developers cash in the pocket. We're making them rich. At the moment, we have a Council Administration that's been here for 23 years, 23 years and they're proud of it. Councillor MURPHY often goes 'well we got elected, we're great'. No, you're not. You're selling Brisbane out and Brisbane's waking up to it. This is a really bad result for Wynnum.

Further speakers?

Councillor WINES.

Thanks, Mr Deputy Chair. Just wanted to make some contributions around particularly item A, contracts and tendering and just add some further context to some of the items within that. Keeping Brisbane moving is at the heart of everything we do and includes maintaining critical infrastructure that supports, in particular, our ferry network. Council operates 22 public passenger ferry terminals along the Brisbane River and they are supported by 2 operations facilities. To ensure these assets are maintained to a high standard, Council requires scheduled maintenance and technical inspections of the ferry terminal network. This contract ensures scheduled maintenance and technical inspections are delivered to a high standard, helping keep this network reliable and fit for purpose.

It's important to consider that 11 of our 12 terminals are now beyond 10 years of age and entering a phase that requires servicing and some replacement works, to ensure they continue to serve our community. This contract allows Council to prioritise maintenance based on the condition of whatever is required and ensure the investments occur where needed. I think sometimes it's important to take a moment to consider that these are marine environments and that the river is itself what they call a brackish estuarine, which means the water is somewhat salty. That means, of course, some of the metal closer to the water does oxidise and degrade a little bit faster than it would if it weren't in water at all times. Sometimes I think we have to remember that the context that these particular items exist in has to be considered.

Part of that is ensuring that we work with quality partners that can inspect and maintain and repair our ferry terminals when they require it. The successful tenderer achieved the highest value for money of the shortlisted submissions and was also offering the lowest comparative tender price. The tenderer also has local officers and local staff and local suppliers and materials. It's also an opportunity to discuss something that we do, is in partnership with TAFE we have the bus operator traineeship program. As I say, it's a contract we have with TAFE for our bus operators to undertake TAFE-accredited training courses.

The contract offers real support and betterment of skills for our drivers who operate our bus fleet. The bus operator traineeship pathway is to allow successful job applicants the opportunity to gain a formal qualification as a Cert III in Driving Operations. The delivery of this contract supports not only the professional skill and growth of our operators but also assists in potential career progression as well. These are skills which, while funded by Council, will assist our drivers not only be better drivers in the day-to-day operation of the fleet, but they'll be able to hold on to and assist with other career progression, should they wish to.

The intake for our bus operator traineeships come from new employees or the existing casual bus operator workforce who seek to move from casual contracts to our permanent team.

At that time, 4.22pm, the Chair presided at the meeting.

Councillor WINES:

With over 2,500 operators operating our fleet of more than 1,200 vehicles, it's both worthwhile and value for money to ensure that our drivers continue to be trained and continue to have their skills improved with a recognised training organisation like TAFE. I think it's something that—my understanding is it's something that's very popular and sought after, particularly by younger drivers. Not only does it demonstrate our commitment to supporting and furthering our workforce, but it also provides better service to the more than 80 million people who ride our buses each and every year.

The third contract from Program 1 is a contract to implement a turn-by-turn navigation system in our buses, which will be a transformation shift for many of our drivers. The skill and talent that we demonstrate in our drivers will be supported by this new system. It is being rolled out in Eagle Farm initially and has been, from what I understand, very well received. So those—I also want to take a moment to thank— k— to recognise and thank Councillor HUTTON for her very kind words about Mitchelton Library, which I know that the community there is very much looking forward to that upgrade.

Mitchelton is a library that has only gotten more popular and it's very reassuring to hear that the facility will be upgraded, but that the young reading programs will continue in the park. We're really lucky in Enoggera Ward, we have the Chair:

|                           | Dorrington Park open air reading and now for a time we’ll also have the open air  reading in Sid Loder Park there, which will be a fantastic experience and  something that I know that in the meeting room is often overflowing with people  who are keen to get in. Hopefully the open air experience will be an even better  one and even more popular with local families.                                                                                                                                                                                                                                                                                                                                                                                                                                                    |
|---------------------------|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Chair:                    | Further speakers?                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 |
|                           | Councillor ALLAN.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 |
| Councillor ALLAN:         | Thank you, Madam Chair. I rise to speak briefly on items A and B. Item A, the  item there on the Nudgee Beach Boardwalk. The Nudgee Beach Boardwalk is a  boardwalk, a loop through the wetlands up there and it is very much an enjoyed  and well - used facility. Now some time ago, the viewing deck started to subside a  section of the boardwalk needed to be fenced off for public safety reasons. The  section that subsided was because the pylons were in a tidal creek area and that  created a risk of collapse ultimately, so it was closed off. What Council has done  with this project is to rather than replicate a viewing deck that failed, they are  creating a new connection closer inland, which will avoid the risk of a collapse  and also completes the loop, so the residents can again use that loop. |
|                           | The second item, item 16, relates to a community storage facility in Murray Duus  Park. It’s a 4 - bay shed. We, I think, have 3 community groups identified already  to use those sheds, so I’m sure they’ll be a great contribution to the community.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           |
|                           | Turning to item B, the adoption of the Wynnum Centre Precinct Plan, this is a  great opportunity to revitalise the Wynnum CBD and not only create housing for  a vast range of local residents, it’s the downsizer market, it’s the homebuyer, it’s  the renter and other people who would look to acquire a home in that  Wynnum CBD. Now the reason that the Wynnum CBD was chosen as a location  for revitalisation was the infrastructure attributes it has. Councillor CASSIDY  made much of the lack of infrastructure, so I’ll just touch upon the infrastructure  that is in fact there.                                                                                                                                                                                                                                  |
|                           | The Wynnum CBD has a train station. It has bus services, all of which potentially  can be upgraded in terms of the frequency of services as the population grows in  the future. It has drainage, it has water, it has power, it has parks. It’s got the  Wynnum Foreshore, it’s got sports facilities, it’s got a golf course nearby, it’s got  a tennis centre, it’s got a bowls club, so much for a lack of infrastructure. It’s got  shops, it’s got services, it’s got a library. All of the things that you would need—                                                                                                                                                                                                                                                                                                     |
| Councillors interjecting. |                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   |
| Chair:                    | Sorry, Councillor ALLAN.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          |
|                           | Councillor COLLIER and Councillor CASSIDY, could you please remain quiet  while another Councillor is on their feet speaking?                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     |
|                           | Councillor ALLAN.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 |
| Councillor ALLAN:         | All of the things that you would need to justify additional housing in a location is  present in Wynnum. Evidently Councillor CASSIDY’s comments about  infrastructure are unfounded. The very reason this presents as an opportunity is  because it has all those aspects. The process has taken about 18 months,  Councillor WOLFF touched upon that earlier, but it’s gone through the initial  research, it’s gone through rounds of community consultation. It’s been to the  State Government a couple of times for review and now we’re ready to embed it  in City Plan. The expectation is that the plan will come into effect in City Plan on  12 June, not too far away now.                                                                                                                                            |
|                           | I think as Councillor GIVNEY touched upon a little bit earlier, there was a  response to the community feedback. Some of the heights were reduced in the  precinct. Different heights were set for different sized lots, so in lots that were  over 2,000 square metres, they can have up to 15 storeys. If they’re under 2,000,  it drops back to 12. There are a range of other heights in the precinct, ranging from  5 storeys through to 10, 12 and 15. There are a range of items that we’re looking  to address through the LGIP process to connect the Wynnum CBD to the foreshore  area.                                                                                                                                                                                                                                 |

Councillor MURPHY:

This is the start of the plan, as Councillor GIVNEY touched upon earlier, the plan is in place now. The industry will obviously need to respond. I think at this point in time, it's not going to happen all at once. It'll happen over many, many years. I did want to touch upon something that Councillor GRIFFITHS said. He spoke about developers and housing. He needs to recall that 96% of housing is built by the development industry. It's not built by somebody else. We do need to recognise that housing is actually built by the development industry.

Councillor ALLAN, your time has expired.

Further speakers?

Councillor MURPHY.

Thank you very much, Madam Chair. I rise to speak on all items. I want to just start by talking a little bit about the parking meters. Now we've had the parking meter system maligned here, but what we have done with parking meters is move to a digital platform, 2 digital platforms in fact. This is the way in which we ensure turnover of the system and that, yes, we ensure revenue returns to the city coffers to fund all of the things that Councillors have requested that we fund in their wards here in this debate today. We currently have 9,000 paid on-street parking spaces and an increasing share is operating on a pay by app basis. Mobile payments represent over 50% of our revenue already, so the parking meters are going the way of the dodo, not yet, but eventually. We are increasingly seeing people wanting to pay by app.

The second item I want to talk about in the report is the concrete and asphalt coring and cutting services. This underpins our ability to deliver day-by-day maintenance and capital works across roads, footpaths, kerbs, channels and buildings. These are very highly specialised services. They're frequently required at short notice and in varying volumes to respond to external factors. These include significant weather events that result in the need to do out -offcycle or additional maintenance or renewal activities to be completed. Five suppliers were appointed based on strong value-for-money outcomes, competitive pricing and proven capability.

Finally, as the Story Bridge reaches the end of its intended 100-year design life, works are required on the southern approach concrete slab. These are part of routine planned maintenance. It's been completed very regularly by Councils of all political persuasions since the bridge was handed over to Council after 1940. This contract will facilitate the maintenance of concrete on the Story Bridge. The successful supply is locally based and has demonstrated strong experience in similar works. Works have already commenced on site and indeed will be ramping up over the next few years as we get underway with the restoration.

Now to the Wynnum Centre Suburban Renewal Precinct, I want to congratulate Councillor GIVNEY on taking this one on. This is not something that every new Councillor to this place wants to get stuck into straightaway, neighbourhood planning, precinct planning. It's controversial, people don't like change. There are always reasons to not do something. I believe, as the Treasurer, Jim Chalmers, has said about housing reforms, there's a lot of reasons to not do something. It's courageous to do something. Well I want to congratulate Councillor GIVNEY for having the courage to bring this through her community, because I think they will be the benefits of the renewal that this plan will bring.

They have already seen the benefits from previous neighbourhood planning efforts that actually Councillor Cumming was generous enough to support through his time here and actually champion against his Labor colleagues, who wanted to vote it down for political reasons, to embarrass the Administration. We know that they have a horrendous record when it comes to supporting precinct planning and additional housing in this city. Labor Councillors who sit here in this place have voted against 17 out of 20 neighbourhood plans that have provided housing supply for Brisbane in the last decade, since 2016. That is their record, that is their record, Madam Chair.

Quickly to just rebut some of the comments that were made by some Opposition Councillors in the debate today. We had Councillor CASSIDY, who tried to claim the CityCat network as a great Labor initiative. Well let's just look at the numbers Chair:

Councillor DAVIS:

on the CityCat network, because yes, the Labor Party started the CityCats, but they started with effectively a novelty fleet size, 6 vessels, which they then grew to a whopping 8 vessels, across 15 terminals. We now have 28 vessels and 5 KittyCats that carry 170 passengers each across 22 terminals. All of the terminals that were rotting and falling into the river under Labor, we have renewed and rebuilt. We took the CityCat network from a novelty to a real mode of transport. Councillor CASSIDY's attempt to claim that legacy here, I think, is fairly disingenuous.

He also mentioned something else. He mentioned the free hand and I love it. It's actually the invisible hand, Adam Smith, Scottish economist and philosopher, Councillor CASSIDY. You need to talk to Councillor GRIFFITHS about the free hand, because Councillor GRIFFITHS maligned capitalism quite broadly in his attack on property developers that he does time and time again in this place. You need to talk to him about that, because your team—although you might be a new capitalist, Councillor CASSIDY, your team is not.

Councillor MURPHY, your time has expired.

Further speakers?

Councillor DAVIS.

Thank you, Madam Chair. I rise to speak on items A, B and C as they relate to the Environment, Parks and Sustainability portfolio. Firstly, to a number of important park upgrades that are being delivered under the report. Contract 10 will deliver a new toilet facility at Gap Creek Reserve into a more appropriate location. The new amenities will include 3 cubicles, an accessible toilet and an upgraded wastewater filtration system. The existing facility will remain operational until the new construction is completed.

Contract 12 relates to the upgrades at Merri Merri Park in Chapel Hill, which will replace and relocate the existing playground away from the overland flow path. The upgrade will include new shade retaining walls and safety fencing, which will create a more resilient and functional recreation space.

Contract 14 is for the construction of the BMX track at the Salisbury Recreation Reserve. The project will be constructed at the northern end of the park, which was identified by members of the public as being their preferred site for the bike jump. Importantly, Madam Chair, the new facility will cater to riders of all abilities.

Contract 15 relates to the upgrade of Hickey Park in Stafford and will deliver a complete renewal of the existing playground, shade structure and connecting pathway. The new design will be located away from the surrounding trees that have previously caused issues with root intrusion. Construction is scheduled to commence in early June and expected, all things being good with the weather, by the end of that month.

Contract 17 will establish a new dog off-leash area at Windsor Park and I know that Councillor WINES is very excited about that. It will feature separate areas for large and small dogs. There will be fencing, shelters, drinking facilities and agility equipment and these are all on track for a July 2026 completion date, Councillor WINES.

Finally, contract 3 will test the market for a new software underpinning Council's energy information management services. This software helps Council track and monitor energy and water consumption. It's also delivered significant saving over the years by detecting and stopping errors or excess charges by our energy providers. The tender, which commenced in April, will close next week and will test the market for other alternatives. Following the tender, the contract is expected to be awarded in October and commenced at the expiry of the current arrangements that will be in March.

Madam Chair, during the course of the debate, we heard a number of things from Councillor KIM that she's going to go back and be telling things to her community. Well, I do hope that Councillor KIM will be talking about the $20 million Pallara District Sports club that the former Councillor, Councillor Angela Owen, secured the funding for.

Chair:

DEPUTY MAYOR:

Madam Chair, item B is the Wynnum Centre Suburban Renewal Project and that speaks to the important work shaping Wynnum Centre and its foreshores. A particularly significant addition is a provision of an urban common, delivering the centrally located greenspace that the community asked for as Wynnum grows. Equally as important is the recognition of a continuous shaded pedestrian connection between Wynnum Central station, the CBD and the foreshore.

Development fronting Florence Street will be required to support a subtropical shade -way through canopy trees and a well-designed pedestrian environment, which is a very practical and visionary step. This work is complemented, of course, by the Wynnum Manly Lota Foreshores Master Plan, which drew through more than 1,450 survey responses from a community that cares deeply about its waterfront. Together, the Precinct Plan and the Foreshores Master Plan present a really coherent, community-shaped vision for Wynnum's future.

Madam Chair, finally, I want to touch on item C and something that came before the Audit Committee on 2 April that I think deserves recognition here in the Chamber. That's the implementation of the former Governor and Supreme Court Justice Paul de Jersey's independent review of Brisbane's response to ex-tropical cyclone Alfred. I'm really pleased to report that Council has finalised implementation actions across all 12 of the de Jersey recommendations, from strengthening our evacuation centre network and expanding real-time flooding monitoring, to formalising how we manage spontaneous volunteers and ensuring Councillors receive automatic notification during events. Madam Chair, I commend all of those items to the Chamber. Thank you.

Thank you.

## Further speakers?

## DEPUTY MAYOR.

Thanks, Madam Chair. I rise to speak on item A first and then hopefully I'll have some time to get to item C. First to A though, the month of March was another strong demonstration of the Schrinner Council's commitment to backing Brisbane businesses, with more than $860 million in work delivered by local suppliers right here in Brisbane this financial year. Councillors will know that the LORD MAYOR's buy local policy sets an 80% benchmark for Council and I'm pleased to report that March exceeded that target, recording an 85% local spend. This reflects not only this Council's commitment to sourcing locally, but also the dedication of Brisbane's business community, who consistently rise to the challenge to deliver for our city.

The report, as we have heard, outlines a range of investments, including the upgrade to the air conditioning at Mitchelton Library, the maintenance of our 22 ferry terminals along the Brisbane River, safety upgrades to the Nudgee Beach Boardwalk, new replacement toilet block at the Gap Creek Reserve, a new playground at Merri Merri Park, construction of the BMX jump track at Salisbury Recreational Reserve. BMX tracks are good, pickleball courts are bad, if you listen to Councillor GRIFFITHS, through you, Madam Chair. Delivery as well of our commitment for a community equipment storage at Ferguson Park and Shaw Estate Park. Alongside with this 80% buy local policy, Council also applies a 30% weighting for local economic benefits in procurement activities valued at $500,000 or more.

We actively work to keep processes fair and accessible for small suppliers, including through our better payment terms for them. Only the Schrinner Council is committed to ensuring that the money Council spends creates jobs here in Brisbane. It strengthens the local capability and also delivers real improvements in every corner of our city.

Now to item C. As we know, it's the report of the Audit Committee meeting just held last month on 2 April. I seem to say it every time but I'll say it once again, that this report comes through on a regular basis from our independent Audit Committee. I have to say that because those opposite have a knack for really trying to bend reality here, Madam Chair, it is a fully independent committee external to Council and external to Councillors. The Audit Committee is an advisory Chair:

## CLAUSE A PUT

Upon being submitted to the Chamber, the motion for the adoption of Clause A of the report of the Establishment and Coordination Committee was declared carried on the voices.

Thereupon, Councillors Jared CASSIDY and Emily KIM immediately rose and called for a division, which resulted in the motion being declared carried .

The voting was as follows:

| AYES: 19  -       | The DEPUTY MAYOR, Councillor Fiona CUNNINGHAM, and Councillors  Krista ADAMS, Greg ADERMANN, Adam ALLAN, Lisa ATWOOD,  Tracy DAVIS, Julia DIXON, Alex GIVNEY, Vicki HOWARD, Steven HUANG,  Sarah HUTTON, Sandy LANDERS, Kim MARX, Ryan MURPHY, Danita PARRY,  Steven TOOMEY, Andrew WINES, Penny WOLFF and Nicole JOHNSTON.   |
|-------------------|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| ABSTENTIONS: 7  - | The Leader of the OPPOSITION, Councillor Jared CASSIDY, and Councillors  Lucy COLLIER, Steve GRIFFITHS, Emily KIM, Charles STRUNK,  Seal CHONG WAH and Trina MASSEY .                                                                                                                                                         |
| Chair:            | We will now put item B to the vote.                                                                                                                                                                                                                                                                                           |

## CLAUSE B PUT

Upon being submitted to the Chamber, the motion for the adoption of Clause B of the report of the Establishment and Coordination Committee was declared carried on the voices.

Thereupon, Councillors Danita PARRY and Jared CASSIDY immediately rose and called for a division, which resulted in the motion being declared carried .

The voting was as follows:

AYES: 18 - committee of Council and it's bound and established pursuant to the City of Brisbane Act and the City of Brisbane Regulation. The committee operates independently and, as it should, free from any political interference or the presence of Councillors at that committee.

One of the functions of the committee is to consider the continuous improvement of all of Council's processes, systems and controls, continuous improvement. The current Audit Committee members were appointed by way of an independent external recruitment process. There's nothing secretive about the meetings. The committee enforces accountability. Every action is identified and then it has a clear outcome, Madam Chair, or process and dates that are also monitored. We can also see from the minutes, Madam Chair, that representatives from the Queensland Audit Office are always in attendance at these meetings. That's to ensure that the requirements are being enforced and adhered to, as well as to make certain that any preparation is occurring for the end of financial year.

When it comes to debt restructure, this is something that, as the Chamber noted, we can all see was talked about at that meeting. There's again no conspiracy here, because if you have a mortgage with interest rates increasing, it's always important to make sure that you get the appropriate terms for your individual case. It doesn't say we are, but it's just an important thing to consider, which is what responsible financial management is, and perhaps the Leader of the Opposition should look it up. Finally, I'd like to offer my thanks once again to the committee, who despite the misinformed and unjustified comments, they continue to provide continuing assistance to ensure that Council gets the best outcome for all ratepayers of Brisbane and I commend it to the Chamber, Madam Chair.

Further speakers? No further speakers?

We'll now put item A to the vote.

The DEPUTY MAYOR, Councillor Fiona CUNNINGHAM, and Councillors Krista ADAMS, Greg ADERMANN, Adam ALLAN, Lisa ATWOOD, Tracy DAVIS, Julia DIXON, Alex GIVNEY, Vicki HOWARD, Steven HUANG, NOES: 8 - Chair:

## CLAUSE C PUT

Upon being submitted to the Chamber, the motion for the adoption of Clause C of the report of the Establishment and Coordination Committee was declared carried on the voices.

Thereupon, Councillors Jared CASSIDY and Lucy COLLIER immediately rose and called for a division, which resulted in the motion being declared carried .

The voting was as follows:

AYES: 18 -

The DEPUTY MAYOR, Councillor Fiona CUNNINGHAM, and Councillors Krista ADAMS, Greg ADERMANN, Adam ALLAN, Lisa ATWOOD, Tracy DAVIS, Julia DIXON, Alex GIVNEY, Vicki HOWARD, Steven HUANG, Sarah HUTTON, Sandy LANDERS, Kim MARX, Ryan MURPHY, Danita PARRY, Steven TOOMEY, Andrew WINES and Penny WOLFF.

NOES: 8 -

The Leader of the OPPOSITION, Councillor Jared CASSIDY, and Councillors Lucy COLLIER, Steve GRIFFITHS, Emily KIM, Charles STRUNK, Seal CHONG WAH, Trina MASSEY and Nicole JOHNSTON.

The report read as follows

## A REPORT OF CONTRACTS ACCEPTED BY DELEGATES OF COUNCIL FOR MARCH 2026 109/695/586/2 -007

605/2025 -26

Sarah HUTTON, Sandy LANDERS, Kim MARX, Ryan MURPHY, Danita PARRY, Steven TOOMEY, Andrew WINES and Penny WOLFF.

The Leader of the OPPOSITION, Councillor Jared CASSIDY, and Councillors Lucy COLLIER, Steve GRIFFITHS, Emily KIM, Charles STRUNK, Seal CHONG WAH, Trina MASSEY and Nicole JOHNSTON.

We'll now put item C to the vote.

1. The Chief Executive Officer provided the information below.
2. Sections 238 and 239 of the City of Brisbane Act 2010 (the Act) provide that Council may delegate some of its powers. Those powers include the power to enter into contracts under section 242 of the Act.
3. Council has previously delegated powers to the Establishment and Coordination Committee and Chief Executive Officer, to make, vary or discharge contracts for the procurement of goods, services or works.
4. The City of Brisbane Regulation 2012 (the Regulation) was made pursuant to the Act. Chapter 6, Part 4, section 227 of the Regulation provides that:
1. Council must, as soon as practicable after entering into a contract worth $200,000 or more (exclusive of GST), publish relevant details of the contract on Council's website.
2. The relevant details must be published under subsection (1) for a period of at least 12 months.
3. Also, if a person asks Council to give relevant details of a contract, Council must allow the person to inspect the relevant details at Council's public office. 'Relevant details' is defined in Chapter 6, Part 4, section 227 as including:
- a. the person with whom Council has entered into the contract
- b. the value of the contract
- c. the purpose of the contract (e.g. the particular goods or services to be supplied under the contract).
5. The contracts, detailed in Attachment A (submitted on file) represent contractual arrangements that Council has already entered into. The purpose of this report is not to consider making decisions about the contracts, rather for transparency of the decisions made on contracts entered into with a value greater than the threshold.
6. The Chief Executive Officer provided the following recommendation and the Committee agreed at the meeting of 27 April 2026.

## 7. RECOMMENDATION:

## THAT COUNCIL NOTES THE REPORT OF CONTRACTS ACCEPTED BY DELEGATES OF COUNCIL FOR MARCH 2026, AS SET OUT IN ATTACHMENT A (submitted on file).

ADOPTED

## B AMENDMENTS TO BRISBANE CITY PLAN 2014 – WYNNUM CENTRE SUBURBAN RENEWAL PRECINCT 152/160/1218/588 -004

## 606/2025 -26

8. The Group Executive, City Planning and Economic Development Services, provided the information below.
9. At its meeting of 26 November 2024, Council resolved to amend Brisbane City Plan 2014 (the planning scheme) to include precinct planning for the Wynnum Centre Suburban Renewal Precinct (the precinct), amend planning scheme policies associated with the proposed amendments, and to make supporting and consequential amendments, including changes to the Wynnum—Manly neighbourhood plan (the proposed amendments). Council also resolved to request a tailored amendment process from the Chief Executive of the Department of State Development, Infrastructure and Planning (the Department) pursuant to section 18(2) of the Planning Act 2016 (the Act).
10. By letter dated 19 February 2025, the Director-General of the Department issued a notice for the tailored amendment process pursuant to section 18(3) of the Act (the Notice), confirming public consultation could proceed on the proposed amendment, concurrent with State interest review.
11. At its meeting of 16 September 2025, Council resolved to proceed to State interest review and public consultation on the proposed amendments. Public consultation on the proposed amendments was undertaken from 7 October to 23 November 2025 pursuant to the Notice, the Act and the Minister's Guidelines and Rules (the Guidelines). By letter dated 21 November 2025, the Deputy Director-General, Planning Group of the Department confirmed that the proposed amendments appropriately integrate the relevant State interests.
12. At its meeting of 17 March 2026, Council resolved to modify the proposed amendments in response to submissions received during public consultation and to request approval from the Chief Executive of the Department of State Development, Infrastructure and Planning (Chief Executive) to adopt the proposed amendments.
13. On 31 March 2026 an amended notice was issued under section 18(3)(b) of the Act by the Acting Director -General of the Department amending the delegation for approving the adoption of the proposed amendments from the Chief Executive to the Minister for Planning (the Minister).
14. By letter dated 14 April 2026 (refer to Attachment B, submitted on file), the Minister granted approval for the proposed amendment (as set out in Attachments C to E, submitted on file) to be adopted into the planning scheme without conditions.
15. The Group Executive provided the following recommendation and the Committee agreed at the meeting of 27 April 2026.

## 16. RECOMMENDATION:

THAT COUNCIL APPROVES THE DRAFT RESOLUTION, AS SET OUT IN ATTACHMENT A, hereunder.

## Attachment A Draft Resolution

DRAFT RESOLUTION TO DECIDE TO PROGRESS AMENDMENTS TO BRISBANE CITY PLAN 2014 – WYNNUM CENTRE SUBURBAN RENEWAL PRECINCT

As Council:

- (i) decided, at its meeting on 26 November 2024:

- (a) pursuant to section 18 of the Planning Act 2016 (the Act), to make amendments to Brisbane City Plan 2014 (the planning scheme) to include the precinct plan for the Wynnum Centre Suburban Renewal Precinct and make supporting and consequential amendments, including changes to the Wynnum—Manly neighbourhood plan (the proposed amendments)

- (b) pursuant to section 22 of the Act and section 2.1 of Part 1 of Chapter 3 of the Minister’s Guidelines and Rules made under the Act (the Guidelines), to amend planning scheme policies associated with the proposed amendments (the proposed planning scheme policy amendments)

- (ii) sought, pursuant to part C, step 4 of the notice given under section 18(3) of the Act (the Notice), approval from the Chief Executive of the Department of State Development, Infrastructure and Planning (the Department) to adopt the proposed amendments to the planning scheme

- (iii) received an amended Notice from the Acting Chief of the Department on 31 March 2026 under section 18(3)(b) of the Act amending delegation for part C, step 5 of the notice from the Chief Executive to the Minister for Planning (the Minister)

- (iv) was, pursuant to part C, step 5 of the amended Notice, advised by letter dated 14 April 2026 from the Minister (refer to Attachment B, submitted on file), that it may adopt the proposed amendments without conditions,

then Council:

- (i) decides, pursuant to part C, step 6 of the amended Notice, to adopt the proposed amendments (refer to Attachments C to E, submitted on file) to the planning scheme

- (ii) decides, pursuant to section 5.1 of part 1 of Chapter 3 of the Guidelines, to adopt the proposed planning scheme policy amendments (refer to Attachments C to E)

- (iii) directs that a notice of the adoption of:

- (a) the proposed amendments be given in accordance with part C, step 7 and step 8 of the amended Notice

- (b) the proposed planning scheme policy amendments be given in accordance with section 5.2 and 5.3 of the Guidelines.

ADOPTED

## C REPORT OF THE AUDIT COMMITTEE MEETING ON 2 APRIL 2026 109/695/586/6 -003

607/2025 -26

17. The Chief Executive Officer provided the information below.
18. Section 201 of the City of Brisbane Regulation 2012 (the Regulation) requires that as soon as practicable after a meeting of the Audit Committee, Council must be given a written report about the matters reviewed at the meeting and the Audit Committee's recommendations about the matters.
19. The Chief Executive Officer is to present the report mentioned in section 201(1)(c) of the Regulation at the next meeting of Council.
20. The report of the Audit Committee meeting of 2 April 2026 is set out in Attachment A (submitted on file).
21. The Chief Executive Officer provided the following recommendation and the Committee agreed at the meeting of 27 April 2026.

## 22. RECOMMENDATION:

## THAT COUNCIL NOTES THE REPORT OF THE AUDIT COMMITTEE MEETING OF 2 APRIL 2026, AS SET OUT IN ATTACHMENT A (submitted on file).

## ADOPTED

## NOTATION OF DECISIONS OF THE ESTABLISHMENT AND COORDINATION COMMITTEE AS DELEGATE OF COUNCIL

## ESTABLISHMENT AND COORDINATION COMMITTEE (Information report)

Chair:

DEPUTY MAYOR, the Establishment and Coordination Committee decisions.

The DEPUTY MAYOR moved, seconded by Councillor Julia DIXON, that the report setting out the decisions of the Establishment and Coordination Committee as delegate of the Council during the Autumn Recess 2026, on matters usually considered by that Committee, be noted.

Chair:

DEPUTY MAYOR:

Chair:

Councillor CASSIDY:

DEPUTY MAYOR.

Thanks, Madam Chair. As we can all see, the item before us is to enter into a Sister City Agreement with the City of Los Angeles. LA is one of the world's greatest cities. It's home to nearly 4 million people and its greater metropolitan area ranks as the world's third largest economic centre. If Greater LA stood alone as a nation, its economy would rank among the world's top 15 economies and importantly, it's the next Host City of the Olympic and Paralympic Games. At their closing ceremony in 2028, the baton will pass from LA to Brisbane, making this partnership both timely and practical for our city.

Once signed, the agreement will be our 10th Sister City Agreement , presenting fantastic opportunities to collaborate, learn from and knowledge share across a range of areas. These areas include civic administration, urban planning and mobility, international and multicultural engagement, economic development, trade and investment. Digital and technology innovation, liveability and community development, cultural, educational, youth and sporting initiatives, major events and tourism promotion, resilience and sustainability. These are the areas that shape how cities function. They are also the areas that will help define our Olympic legacy here in Brisbane.

By focusing on these, we can make sure that our city, the residents and businesses of our city will benefit now, into 2032 and well beyond that time. We want the Games, obviously, Madam Chair, to be a raging success, but more importantly we want Brisbane to be stronger because we hosted them and we welcomed the world to our city. This Sister City Partnership with LA will support that goal. It will support better planning, better delivery and a stronger legacy for all of our residents. I commend the item to the Chamber.

Further speakers?

Councillor CASSIDY.

Incredible that Mr Harvard graduate couldn't even be here to introduce this E&amp;C item. Talk about being part-time, this is why he went. I understand why the LORD MAYOR decided he wanted to talk for whatever, 5, 10, 15 minutes earlier about this, because he knew he had no intention of staying in the Council meeting after afternoon tea. He has this innate inability to come to work. Unless of course that involves going business class over to LA, then hopping over to Harvard to do some leadership training over there and back through LA and back to Brisbane.

Quite incredible, really quite incredible. I thought I'm sure he would be here. It's not a lot, it's not a lot, it's 4 pages, this agreement's just 4 A4 pages. Where is he? Who knows, maybe they don't know. We know that the Council under the LNP regime can use all the help it can get in terms of running a city at the moment. But when we look and see that this regime is spending $342 a day on international Chair:

|                           | travel, when drainage isn’t being serviced in our city, when potholes aren’t being  repaired in the 24 hours that Councillor MURPHY guaranteed they would be,  when playgrounds are broken for months and where are these priorities? Offshore.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           |
|---------------------------|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Councillor interjecting.  |                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           |
| Councillor CASSIDY:       | Offshore, over in LA. Now Sister City Agreements of course have their place, but  what we know is that this LORD MAYOR has not— t—n —not just has been missing in  action, but is missing in action, when the people of Brisbane probably needed his  leadership the most. He is anywhere but Brisbane, this LORD MAYOR, anywhere  but Brisbane. What we saw while he was away on this little junket over to  Hollywood and to Boston, Massachusetts, there was no Council plan to manage  the fuel crisis. Credit where credit’s due, I guess, the Premier cancelled an  overseas trip during this fuel crisis because he said it would be inappropriate for a  leader in this State to be flying out overseas in the midst of a fuel crisis. He  cancelled that overseas travel to stay here, campaigned I’m sure in the Stafford  by-election as well. But he did decide to stay here, unlike our LORD MAYOR. Even more bins were missed on their collection days, Chair. Somebody in Taigum  sent me a photo through today, another round of missed bins, the fifth time since  August last year. The State Government announced while the LORD MAYOR |
| Chair:                    | Councillor CASSIDY, please refer to the Councillors by their appropriate names.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           |
| Councillor CASSIDY:       | I’m sorry, Mr Harvard graduate. Won’t be dissuaded though, because from what  we understand— d—                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           |
| Chair:                    | Councillor CASSIDY. Councillor CASSIDY, LORD MAYOR.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       |
| Councillor CASSIDY:       | Lord Mayor of Boston, Massachusetts, Mr Harvard graduate, LORD MAYOR  Adrian SCHRINNER, won’t be dissuaded. We understand he’s got another  overseas trip booked in in February to LA again and it’s not even for the Sister  City Agreement. He’s flying out in February next year on another overseas trip to  LA. Can you believe it?                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  |
| Councillor interjecting.  |                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           |
| Councillor CASSIDY:       | Can you believe it? Where is he the Mayor for?                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            |
| Councillors interjecting. |                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           |
| Councillor CASSIDY:       | Where is he? Couldn’t he go and do a leadership course at Griffith University, or  UQ (University of Queensland) or QUT (Queensland University of Technology)?  I’m sure QUT would have some course he could do, but he has to go to Harvard  to learn about leadership.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  |
| Councillor interjecting.  |                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           |
| Councillor CASSIDY:       | He’s got to do it in person. Now he says there’s no cost apparently, when he  vacates his day job here in Brisbane in addressing the many crises we are facing  as a city, he reckons there’s no cost to that. Well there is a cost to that, there is a  cost to that. We know he’s earning $1,100 a day as LORD MAYOR—                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   |
| Councillor MURPHY:        | Point of order.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           |
| Councillor CASSIDY:       | —w —when he’s overseas.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   |
| Chair:                    | Point of order, Councillor MURPHY.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        |

| Councillor MURPHY:       | We’ve heard a lot of personal attacks on the LORD MAYOR. I’m just wondering  if we’ll hear about the Sister City Agreement that’s the item before us—                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  |
|--------------------------|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Chair:                   | Thank you, Councillor MURPHY.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          |
| Councillor MURPHY:       | — from Councillor CASSIDY.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             |
| Chair:                   | Thank you.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             |
|                          | Councillor CASSIDY, can you come to the report please.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 |
| Councillor CASSIDY:      | Thanks very much. When the LORD MAYOR was talking about his trip to LA to  sign the Sister City Agreement with the City of LA, Councillor MURPHY, he said  there was no cost, both in terms of his wages. Maybe he didn’t draw a wage of  $1,100 a day as LORD MAYOR while he was overseas. Maybe he returned that  money to the people of Brisbane, because he clearly wasn’t working on Brisbane  problems when he was in LA. Quite incredibly, when he complained, the  LORD MAYOR was groaning and moaning about getting up in the middle of the  night and doing a couple of Teams meetings with a time zone change when he was  earning $1,100 a day to do it. That is literally his job, you would think, to do that.  That’s okay, do those Teams meetings, get up in the middle of the night and do  them.                                                                                    |
| Councillor interjecting. | Councillor interjecting.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               |
| Councillor CASSIDY:      | Maybe he’s not up for it, maybe he’s had enough of it. Maybe he’s asked Michael  Bloomberg for a job. Maybe this is all about that.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    |
| Councillor interjecting. | Councillor interjecting.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               |
| Councillor CASSIDY:      | Maybe earning $1,100 a day as LORD MAYOR of Brisbane is not enough for  him. Maybe that’s why he’s hanging around with these billionaires over in these  special selected courses that he’s doing while being paid by the people of  Brisbane, the ratepayers of Brisbane, in person.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  |
| Councillor interjecting. | Councillor interjecting.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               |
| Councillor CASSIDY:      | It’s great, good, we’ve got a new Sister City of LA. It’s an Olympic city, we’re an  Olympic city. I’m glad to see—I assume this is LA has put this in, that all of these  meetings and follow-ups should be done via video conferencing. I guess that’s  why we’re seeing the LORD MAYOR concoct other reasons to do international  travel, because all the Sister City arrangements that he’s entering into and  renewing aren’t delivering the frequent flyer points that he needs. But here in  Brisbane, there are a lot of problems. The LORD MAYOR says—he puts his  rose-coloured glasses on and says, ‘the fact that Brisbane is one of the most  unaffordable cities when it comes to renting a unit is not a problem’. The  LORD MAYOR says, ‘that being the most congested city in Australia is not a  problem’. The LORD MAYOR says that ‘here in Brisbane and Greater Brisbane, which we |
|                          | are now being treated in an Olympic sense as one big city, has the worst access to  public transport is apparently not a problem’. Not when he goes and travels  overseas, whether it’s through Europe, whether it’s to the Middle East, whether  it’s to America, wherever he goes, it’s not a problem for him. He gets chauffeured  around, he gets these business class flights paid for by these billionaires. It isn’t a  problem, it isn’t a problem if you’re LORD MAYOR Adrian SCHRINNER, but  all these things are a problem if you’re living in Brisbane and you’re seeing your  future disappear while Adrian SCHRINNER is in charge of this city. That is a  problem. While the Sister City Arrangement in the document before us today is  great for Brisbane and great for LA, what is not great for Brisbane is this  LORD MAYOR.                                                       |
| Chair:                   | Further speakers?                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      |
|                          | Councillor ALLAN.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      |
| Councillor ALLAN:        | Thank you, Madam Chair. I rise to speak on item A, the Sister City Agreement  with LA. I must say I’m immensely amused by the hypocrisy of  Councillor CASSIDY’s contribution this afternoon. He spoke mostly about the  LORD MAYOR’s travel and very little about the Sister City Agreement itself and                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                |

|                           | the benefits it’ll bring to the city. But nonetheless, here we are, we have the Leader  of the Opposition, who’s good mates with none other than Anika Wells. What a  record she has. At least the LORD MAYOR was travelling overseas, not on  ratepayer money, to do things that are relevant to the city.                                                                                                                                                                                                                                                                                                                                                                                                                                                                           |
|---------------------------|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Councillors interjecting. |                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       |
| Councillor ALLAN:         | He was in LA for 7 hours to sign the Sister City Agreement, he didn’t even stay  overnight. Now we know that Anika Wells is having a little bit of trouble on one  of her trips in South Australia. She’s having trouble getting another Labor Minister  to substantiate the fact they had a meeting. All I can say is it’s pretty rich for  Councillor CASSIDY to get up here and talk about travel.                                                                                                                                                                                                                                                                                                                                                                                 |
| Chair:                    | Thank you, Councillor ALLAN, one moment.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              |
|                           | Councillor COLLIER, you don’t call out at me from your chair. If you have  something to say, if you’ve got a point of order, do it appropriately.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     |
| Councillor interjecting.  |                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       |
| Chair:                    | No, Councillor. I’m not asking for a response.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        |
|                           | Councillor ALLAN.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     |
| Councillor ALLAN:         | Thank you, Madam Chair. I would now actually like to talk about the Sister City  Agreement, because I think that’s the substance of this item.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        |
| Councillors interjecting. |                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       |
| Chair:                    | Thank you, Councillor. Microphone, thank you.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         |
| Councillors interjecting. |                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       |
| Chair:                    | Now we’ll just wait until they’re quiet.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              |
| Councillor ALLAN:         | Madam Chair— r—                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       |
| Chair:                    | Wait one moment, Councillor ALLAN, until they’re quiet, everybody to be quiet.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        |
|                           | Councillor ALLAN.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     |
| Councillor ALLAN:         | Madam Chair, this agreement matters because we are just over 6 years away from  hosting the 2032 Games. It matters because cities do not succeed by planning in  isolation. They succeed by learning from others who have walked the path before  them. This will be Brisbane’s first new Sister City relationship in 16 years. It  reflects how far our city has come and where we intend to go next. Los Angeles  will be Brisbane’s Olympic counterpart. In just over 2 years’ time, the Olympic  and Paralympic baton will pass from Los Angeles to Brisbane. This transition  makes this partnership timely and practical. This will not be a symbolic  arrangement, it will be a working partnership.                                                                           |
|                           | Under this Sister City Agreement, Brisbane and Los Angeles will share knowledge  and experience across 9 clear focus areas. The DEPUTY MAYOR touched upon  these earlier, but I will repeat them. These include civic administration, urban  planning and transport, economic development, trade and investment. Digital  innovation, liveability, culture, education, youth and sport, major events, tourism,  resilience and sustainability. These are important areas and they will also be at the  heart of our Olympic legacy. We will share policy insights, we will collaborate on  research and projects. We will build organisational capability, we will support  business delegations and joint tourism promotion. We will strengthen cultural and  educational exchanges. |
|                           | Importantly, this partnership also creates a platform to work with other levels of  government, business and industry. The goal is clear, deliver economic and social  outcomes that benefit local residents and help local businesses grow. This  partnership also builds on Brisbane’s existing network of 9 Sister Cities across the  Asia Pacific and Middle East. Those relationships have supported trade,  investment, cultural exchange and capability building over decades. Los Angeles  adds a new dimension. It connects Brisbane directly to a global economic and  cultural powerhouse at a critical moment in our city’s future. We know that LA is                                                                                                                    |

Councillor KIM:

Councillors interjecting.

Chair:

Councillors interjecting.

Councillor KIM:

Chair:

Councillor KIM:

Councillor ADAMS:

Councillor KIM:

Councillors interjecting.

Chair:

Councillor GRIFFITHS:

Councillors interjecting.

Chair:

Councillor ADAMS:

Chair:

using the 2028 Games to reimagine infrastructure, build resilience and expand opportunity through a games-for-all approach.

Business leaders have been clear about the opportunity this creates. Stronger ties with Los Angeles opens doors to new markets, deeper networks and real commercial outcomes. They also help local businesses prepare for and benefit from major global events. Community and city building organisations have also highlighted the value. Well-established city-to-city relationships support investment attraction, knowledge sharing and long-term growth. Madam Chair, we want the Olympic and Paralympic Games to run well, but we also want Brisbane to be better off because we hosted them. The Sister City Agreement will go a long way towards this goal and I commend this item to the Chamber.

Further speakers?

Councillor KIM. Councillor, can you turn your microphone on please?

Thank you, Chair. How was your trip to Dubai, Councillor ALLAN? I find it interesting that he brings up Anika Wells to Councillor CASSIDY, but he doesn't talk about his good time that he spent in Dubai, only last year. I think that should be noted today.

Councillors, Councillors.

One moment, please.

Councillor ALLAN, please do not call out—

They're cagey.

— or Councillor MURPHY, please do not call out while Councillor KIM is on her feet.

Councillor KIM.

Thank you, well that's great. I'm sad that the LORD MAYOR's not here today because I wanted him to see this post that we even liked of his where he said, "why travel the world when you can spend a day in Brisbane?" So true, LORD MAYOR. You've only spent one day in Brisbane and only 2 hours in this Chamber right here. He's standing next to this person right here this photo— Councillor JOHNSTON, didn't this lady call you a female dog? An LNP Councillor called you a female dog. That's why we know Luke Richmond will go and save the 93 -bed hospital cuts from the Prince Charles Hospital this Saturday, because that's what Labor's about every single day.

Point of order, Madam Chair.

In relation to the injuries, now these are the injuries that have been sustained—

One moment please, Councillor KIM.

Point of order.

One moment, there's already one point of order.

Councillor KIM, there's a point of order.

Point of order, Councillor ADAMS.

Thank you, Madam Chair. I know Councillor CASSIDY did not speak about Sister City report at all, but there is no even longbow on what Councillor KIM is talking about to relevance to this report.

I'm going to ask all Councillors to try and stick to the report please.

Councillor KIM, can you come back to what is in the report please.

| Councillor KIM:           | Absolutely, because on the topic of hospitals, I will bring up a resident that was  hospitalised in Councillor MURPHY’s ward while the LORD MAYOR was in  LA, failing to lead his LNP Council.                                                                                                                                                                                                                                          |
|---------------------------|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Chair:                    | Councillor, Councillor, we’re not talking about hospitals, we’re talking about City  of Los Angeles, United States of America, and I ask you to come back to that  please.                                                                                                                                                                                                                                                              |
| Councillors interjecting. |                                                                                                                                                                                                                                                                                                                                                                                                                                         |
| Councillor KIM:           | While the LORD MAYOR was in LA —                                                                                                                                                                                                                                                                                                                                                                                                        |
| Chair:                    | One moment, sorry.                                                                                                                                                                                                                                                                                                                                                                                                                      |
| Councillor KIM:           | This is Erica.                                                                                                                                                                                                                                                                                                                                                                                                                          |
| Chair:                    | One moment.                                                                                                                                                                                                                                                                                                                                                                                                                             |
| Councillor KIM:           | She was mauled by a dog and—                                                                                                                                                                                                                                                                                                                                                                                                            |
| Chair:                    | Councillor KIM.                                                                                                                                                                                                                                                                                                                                                                                                                         |
| Councillor KIM:           | — she only lives down the road from Councillor MURPHY’s office. This is  Erica— a—                                                                                                                                                                                                                                                                                                                                                      |
| Chair:                    | Councillor KIM.                                                                                                                                                                                                                                                                                                                                                                                                                         |
| Councillor KIM:           | —h —hospitalised. This is her in hospital.                                                                                                                                                                                                                                                                                                                                                                                              |
| Chair:                    | Now I’m speaking, Councillor KIM and when I speak, that means you stop, okay?  I’ve asked you already to come back to the report. You are not speaking to the  report. You’re not that new to the Chamber that you don’t know exactly what  you’re doing and I’ve asked you to come back to the report. If you have other  things to talk about, I encourage you to do that in General Business please. Can  you do that?               |
| Councillor KIM:           | Absolutely.                                                                                                                                                                                                                                                                                                                                                                                                                             |
| Chair:                    | Thank you.                                                                                                                                                                                                                                                                                                                                                                                                                              |
| Councillor KIM:           | Because it’s only taken me 2 years to learn that the LORD MAYOR has travelled  5 times overseas and more. He’s travelled everywhere around the world, with LA  included. Now Erica was mauled by a dog and—                                                                                                                                                                                                                             |
| Chair:                    | Again Councillor, I have already asked you—                                                                                                                                                                                                                                                                                                                                                                                             |
| Councillors interjecting. |                                                                                                                                                                                                                                                                                                                                                                                                                                         |
| Councillor KIM:           | The LORD MAYOR needs to hear this.                                                                                                                                                                                                                                                                                                                                                                                                      |
| Chair:                    | Councillor, you’ve got—                                                                                                                                                                                                                                                                                                                                                                                                                 |
| Councillor KIM:           | This was his ward.                                                                                                                                                                                                                                                                                                                                                                                                                      |
| Chair:                    | Have you got anything to say about the report please? If not, I’ve asked you to talk  about whatever you want to talk about in General Business. You do have that  opportunity to do that then. Have you got any more to say about the report?  Because I’m sure other Councillors have got their part to say.                                                                                                                          |
|                           | Do you have a point of order?                                                                                                                                                                                                                                                                                                                                                                                                           |
| Councillor COLLIER:       | Point of order, Chair. Sorry, you were speaking so I didn’t know if you were  finished or not.                                                                                                                                                                                                                                                                                                                                          |
| Chair:                    | Thank you, well done.                                                                                                                                                                                                                                                                                                                                                                                                                   |
| Councillor COLLIER:       | Thank you, I live for pats on the back from you. Chair, under the Sister City  Agreement , article 2, scope of cooperation, it talks about civic administration. I  do believe that Councillor KIM is being relevant. Point B talks about urban  planning and mobility. Point F talks about liveability and community  development, so Councillor KIM is being extremely relevant. These are things in  our Sister City Agreement that— |
| Chair:                    | Well unfortunately for you, Councillor COLLIER, you are not in the Chair  deciding that. I do not uphold your point of order.                                                                                                                                                                                                                                                                                                           |

Councillor KIM.

| Councillor KIM:           | Thank you, I’ll go back to the Olympics, even though the LORD MAYOR’s not  even here today, because his response to all of this is to instruct Council officers  to change this sign, Welcome to Brisbane, on a road that’s cracked, to a brand new  one that has —                      |
|---------------------------|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Chair:                    | Councillor KIM, bring it up in General Business please.                                                                                                                                                                                                                                  |
|                           | Are there any further speakers?                                                                                                                                                                                                                                                          |
| Councillors interjecting. |                                                                                                                                                                                                                                                                                          |
| Chair:                    | Yes, Councillor JOHNSTON.                                                                                                                                                                                                                                                                |
| Councillor KIM:           | Madam Chair, point of order.                                                                                                                                                                                                                                                             |
| Chair:                    | Councillor JOHNSTON.                                                                                                                                                                                                                                                                     |
| Councillor JOHNSTON:      | I don’t want to cut Councillor KIM off if she’s still speaking, but I definitely want  to speak.                                                                                                                                                                                         |
| Chair:                    | I know you do, Councillor JOHNSTON and I’ve asked Councillor KIM to stay  relevant and bring whatever she has to talk about that isn’t relevant up in General  Business.                                                                                                                 |
|                           | Have you got any further to say on this report, Councillor KIM?                                                                                                                                                                                                                          |
| Councillor KIM:           | Absolutely, which is the Olympics.                                                                                                                                                                                                                                                       |
| Chair:                    | We’re talking about a Sister City arrangement.                                                                                                                                                                                                                                           |
| Councillors interjecting. |                                                                                                                                                                                                                                                                                          |
| Councillor KIM:           | The Sister City to do with the Olympics. This is the sign that he instructed—that  he wanted erected, yet he calls this his Olympic City. This is Denise. Denise  tripped over while he was overseas. She tripped over, hurt her face over a footpath  and remained this way for months. |
| Chair:                    | Councillor KIM, can you please stop talking?                                                                                                                                                                                                                                             |
| Councillor KIM:           | This is what he calls his Olympic City.                                                                                                                                                                                                                                                  |
| Chair:                    | Councillor KIM, as you have failed to comply with the request to take remedial  action for unsuitable meeting conduct, I hereby warn you, in accordance with  section 21(6) of the Meetings Local Law 2001, that failing to comply—                                                      |
| Councillors interjecting. |                                                                                                                                                                                                                                                                                          |
| Chair:                    | —w —with the request may result in an order being issued.                                                                                                                                                                                                                                |
| Councillor KIM:           | Thank you, Chair. I haven’t even got into the 15 sheep that were mauled by wild  dogs in Karawatha. This is—                                                                                                                                                                             |
| Chair:                    | I’m sure you’ll have time to do that when you are in General Business.                                                                                                                                                                                                                   |
| Councillor KIM:           | I mean it’s a joke, it’s a joke that the LORD MAYOR is not here.                                                                                                                                                                                                                         |
| Chair:                    | Thank you, Councillor KIM. No.                                                                                                                                                                                                                                                           |
| Councillor KIM:           | He can’t even protect the residents. The LNP—                                                                                                                                                                                                                                            |
| Chair:                    | Councillor KIM, you’re an elected representative. This is not difficult to follow—                                                                                                                                                                                                       |
| Councillor KIM:           | It’s not difficult for the LORD MAYOR to —                                                                                                                                                                                                                                               |
| Chair:                    | — and you are not to debate me.                                                                                                                                                                                                                                                          |
| Councillors interjecting. |                                                                                                                                                                                                                                                                                          |
| Chair:                    | Councillor JOHNSTON.                                                                                                                                                                                                                                                                     |
| Councillor JOHNSTON:      | Okay, I’m going to go.                                                                                                                                                                                                                                                                   |
| Councillor COLLIER:       | Point of order, Chair.                                                                                                                                                                                                                                                                   |

| Chair:                    | Point of order, Councillor COLLIER.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  |
|---------------------------|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Councillor COLLIER:       | Chair, just to clarify, are you silencing Councillor KIM from speaking further?  You don’t know what she’s got to say and she still has—                                                                                                                                                                                                                                                                                                                                                                                             |
| Chair:                    | If you’d like—                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       |
|                           | Councillor COLLIER, I don’t uphold your point of order. If you want to go back—                                                                                                                                                                                                                                                                                                                                                                                                                                                      |
| Councillor COLLIER:       | I haven’t finished making it.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        |
| Chair:                    | No, I do not uphold your point of order—                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             |
| Councillor COLLIER:       | I haven’t finished making it.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        |
| Chair:                    | —b —because if you want to go back and have a look at the footage, you’ll see I gave  Councillor KIM more than enough opportunities to speak and state the point.                                                                                                                                                                                                                                                                                                                                                                    |
| Councillor COLLIER:       | Are you—                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             |
| Chair:                    | There are other people before time runs out that would like to speak.                                                                                                                                                                                                                                                                                                                                                                                                                                                                |
| Councillor COLLIER:       | — turning her microphone off and stopping her from speaking when she has time  left on the clock?                                                                                                                                                                                                                                                                                                                                                                                                                                    |
| Chair:                    | Councillor JOHNSTON, I do not uphold your point—                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     |
| Councillor COLLER:        | I’m not Councillor JOHNSTON.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         |
| Chair:                    | Councillor COLLIER, I do not uphold your point of order.                                                                                                                                                                                                                                                                                                                                                                                                                                                                             |
| Councillor COLLIER:       | So you are silencing Councillors from speaking in this place? Yes?                                                                                                                                                                                                                                                                                                                                                                                                                                                                   |
| Chair:                    | Councillor, I will warn you, you are showing unsuitable meeting conduct by  arguing with me. I have made a decision and I’ve given Councillor KIM more  than enough opportunity to speak today. I’m asking her to bring up the things that  are not in the report in GB in today’s meeting. You will have every opportunity to  talk about those things. Can you please keep it for then.                                                                                                                                            |
| Councillor STRUNK:        | Point of order.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      |
| Chair:                    | Point of order, Councillor STRUNK.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   |
| Councillor STRUNK:        | Listen, I’m a bit confused, Chair. Anika Wells was brought up in this Chamber in  regards to this report and you didn’t do anything to dissuade Councillor ALLAN  about that information introduced into the debate, so I’m a bit confused.                                                                                                                                                                                                                                                                                          |
| Chair:                    | Again, Councillor STRUNK, I urge you to actually go back and look at this after,  because I did bring him back to the report. Now I’m not going to argue with you.  I do not uphold your point of order.                                                                                                                                                                                                                                                                                                                             |
| Councillor KIM:           | With the 1.5 minutes left to speak on this item, I would like to hear the  LORD MAYOR speak for himself about what he did in LA. I don’t think it’s  appropriate that the DEPUTY MAYOR, who also enjoyed her time in Dubai last  year, gets to present this report. I think it’s actually such a joke that the  LORD MAYOR himself is not here, because he’s afraid. He’s afraid to face our  community while all of this happens in his area. His own Councillors aren’t even  responding to dogs that are mauling their residents. |
| Chair:                    | Thank you, Councillor KIM.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           |
| Councillor KIM:           | It’s time for the LORD MAYOR to stop hiding.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         |
| Chair:                    | In the short time we have, I’m asking you to give Councillor JOHNSTON a turn,  because you are not sticking to what we’re talking about. Can you do that?                                                                                                                                                                                                                                                                                                                                                                            |
| Councillor KIM:           | Well there’s 50 seconds left to speak on this item.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  |
| Councillors interjecting. |                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      |
| Councillor KIM:           | The residents of Calamvale Ward would like to know why the LORD MAYOR  has travelled to LA without at least visiting Pallara in person.                                                                                                                                                                                                                                                                                                                                                                                              |

Chair:

Well, Councillor, that’s probably something that you could have covered in Question Time, in General Business, but we are talking about the report.

Councillors interjecting.

Chair:

Stick to the report. Away you go.

Councillor KIM:

Sorry, Councillor JOHNSTON. With the 30 seconds that I have left, I think it’s important that the LORD MAYOR comes back next week and addresses this report. It’s insufficient for the DEPUTY MAYOR to be here speaking on his behalf.

Councillor interjecting.

Councillor KIM:

$1,100 a day, what is he going to say to the residents of Brisbane City? This is wrong.

Chair:

Councillor JOHNSTON.

I’ve already called Councillor JOHNSTON, Councillor ADAMS.

Councillor JOHNSTON:

Yes, thank you so much. Do I have a whole 5 minutes?

Chair:

No, sorry.

Councillor JOHNSTON:

How long, sorry?

Chair:

Actually, let me check for you. Just—yes, 5 minutes.

Councillors interjecting.

Councillor JOHNSTON:

Firstly, I do want to thank Councillor KIM. I appreciate the point very much that she was making, that there is a cost to our city when the LORD MAYOR goes overseas and that means his attention and focus is on other issues and not on local issues here in her community and in mine. I think her point was very well made. I think personally it's very relevant to the debate that we're having here and I just want to say I heard you and I understand exactly what you were saying. I didn't think it was confusing.

I just want to say a few things about the LORD MAYOR's junkets. It was very interesting to hear that he's off again next year to LA and I suspect there'll be quite a few trips back and forth to LA now. This is the 10th Sister City Agreement that we're signing up to. Generally, the other agreements are in the Asia-Pacific area, so this one is a little bit unusual. Whether we needed a Sister City Agreement I think is a moot point. Obviously, there'll be a lot of learnings that come for the city out of the LA Olympics and we should learn from that. I mean, LA is a completely different city to Brisbane, so not quite sure—they've got multiple major stadiums. Anyway, so it's a whole different ballgame, but certainly I'm sure there are learnings that will come from this.

But what I want to say is you would think that the LORD MAYOR is running the Olympics, because he has to do all this personally. He's off on his leadership junkets over to Harvard in Boston. No, I don't think he did join the rowing team. He doesn't look quite like rowing stock to me. But he did not cost the ratepayers of Brisbane anything other than the taxpayers of Australia who apparently limoed him back and forth and ferried him around for the day in LA. Thank you to the Consul -General there, because the LORD MAYOR thinks that was all for free, but no, that was not the case.

But the big issue we have, the LORD MAYOR is not running the Olympics. The LORD MAYOR is on the board that is running the Olympics. It is part of that board's responsibility to run the Olympics properly. All of this should be done through that board. The fact that the LORD MAYOR is using this to engage in these vacuous trips, vacuous trips, he did not have to go over and do this. We didn't need this arrangement. LA will work with us. We will learn. That's all part of the Olympic agreement with each city, that there is the give and take between the cities and the learnings and how they're working together.

The big issue we've got here is, yes, our city is going to be a Host City and there are lots of learnings we can get out of that. But the LORD MAYOR is on the

|                           | committee that runs the Olympics and why this LORD MAYOR thinks he  personally needs to be doing all of this, instead of—                                                                                                                                                                                              |
|---------------------------|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Councillor interjecting.  |                                                                                                                                                                                                                                                                                                                        |
| Councillor JOHNSTON:      | —w —which he doesn’t— t— instead of working as part of the official authority that is  actually running the Olympics, that is the part that I am finding difficult to  understand. Councillor ADAMS went to Paris and then retired. Councillor  HOWARD’s been off to Paris and no doubt she’s going to retire as well. |
| Councillor HOWARD:        | Point of order, Madam Chair.                                                                                                                                                                                                                                                                                           |
| Chair:                    | Point of order, Councillor HOWARD.                                                                                                                                                                                                                                                                                     |
| Councillor HOWARD:        | That is totally uncalled for and I ask that it be retracted.                                                                                                                                                                                                                                                           |
| Councillor GRIFFITHS:     | Point of order. Is that a point of order?                                                                                                                                                                                                                                                                              |
| Chair:                    | I’m not finished with this. Thank you, Councillors, calm down.                                                                                                                                                                                                                                                         |
| Councillors interjecting. |                                                                                                                                                                                                                                                                                                                        |
| Chair:                    | Councillor GRIFFITHS —                                                                                                                                                                                                                                                                                                 |
| Councillors interjecting. |                                                                                                                                                                                                                                                                                                                        |
| Chair:                    | Calm down.                                                                                                                                                                                                                                                                                                             |
|                           | Councillor JOHNSTON, would you care to withdraw that?                                                                                                                                                                                                                                                                  |
| Councillor JOHNSTON:      | I’m sorry, Councillor HOWARD, you’re going to rule forever in Central Ward.                                                                                                                                                                                                                                            |
| Councillors interjecting. |                                                                                                                                                                                                                                                                                                                        |
| Councillor JOHNSTON:      | I mean rule forever and she’s correct, yes.                                                                                                                                                                                                                                                                            |
| Councillors interjecting. |                                                                                                                                                                                                                                                                                                                        |
| Councillor JOHNSTON:      | It’s okay, it’s okay. Councillor HOWARD didn’t make a proper point of order or  anything, but that’s fine.                                                                                                                                                                                                             |
| Chair:                    | Sorry, Councillor—                                                                                                                                                                                                                                                                                                     |
| Councillor JOHNSTON:      | I mean everybody—                                                                                                                                                                                                                                                                                                      |
| Chair:                    | —b —but the point of order was called upon.                                                                                                                                                                                                                                                                            |
| Councillor JOHNSTON:      | Maybe Councillor HOWARD’s going to get voted out, not retire, I don’t know.  But the point I’m making is these LNP Councillors—                                                                                                                                                                                        |
| Chair:                    | Thank you, Councillors.  Councillor JOHNSTON, your time has expired.                                                                                                                                                                                                                                                   |

## EXPIRATION OF PERIOD FOR DEBATE OF COMMITTEE REPORTS

At that point, 5.22pm, the Chair advised that the period allowed for debate of Committee reports had expired.

Councillor CASSIDY:

Point of order.

Councillors interjecting.

Chair:

Under the provisions of section 35(13) of—

Councillor CASSIDY:

Point of order.

Chair:

— the Meetings Local Law—

Councillor CASSIDY:

Point of order.

Chair:

— on the expiration of the period allowed for debate of Committee reports, I shall now put the motions to the meeting. For the—

Councillor CASSIDY:

Point of order.

Chair:

For any—one moment. I’m speaking, Councillor.

[4791 (Post Recess) Meeting – 12 May 2026]

Councillor CASSIDY:

I asked for a point of order before you started speaking.

Chair:

Well I was actually speaking.

Councillor CASSIDY:

You weren’t.

Chair:

Well again, check your footage. I shall now put the motions of the rest—

Councillors interjecting.

Chair:

— to the meeting for the noting of any Committee report not yet voted upon without further amendment or debate.

Do you have a point of order?

Councillor CASSIDY:

Yes. Did you or did you not think all of that was unsuitable meeting conduct? We’re trying to follow the rules.

Chair:

That is not a point of order. We’ll now vote on—

Councillor CASSIDY:

It is a point of order.

Chair:

— the Establishment and Coordination Committee report.

Councillor CASSIDY:

Point of order. Point of order.

Chair:

Point of order, Councillor CASSIDY.

Councillor CASSIDY:

I believe that Councillor HOWARD, Councillor WINES and Councillor MURPHY, through their shouting out, were engaging in unsuitable meeting conduct. Will you rule on that?

Chair:

No, Councillor and I —

Councillor CASSIDY:

Check the video, you can check the video.

Chair:

Yes, don’t worry, I will be.

We’ll now put Clause A to the vote.

Upon being submitted to the Chamber, the motion was declared carried on the voices.

The report read as follows

## A NEW SISTER CITY – CITY OF LOS ANGELES, UNITED STATES OF AMERICA 122/465/760/89

## 608/2025 -26

1. The Group Executive, City Planning and Economic Development Services, provided the information below.
2. Brisbane's Sister City Program has a strong history of fostering trade, education, cultural exchanges and urban development practices with cities across the Asia-Pacific Region and the Middle East.
3. Council is responding to a request to enter into a new partnership with the City of Los Angeles (LA), United States of America (USA) , to create new opportunities for economic growth, cultural exchanges and global visibility, whilst leveraging the USA's role as a key global trading partner.
4. Brisbane and LA are both preparing to host the Olympic and Paralympic Games, creating a unique opportunity to share knowledge and collaborate on areas including sustainability, transport, economic development, resilience and emergency preparedness. The partnership would seek to benefit the technology, creative industries, tourism and infrastructure sectors, while strengthening ties through cultural, youth and sporting exchanges.
5. LA is a global hub for technology, entertainment and advanced manufacturing. A Sister City partnership would enable Brisbane to access this innovation ecosystem and offer LA strategic links to Asia-Pacific networks. Civic collaboration on areas such as mobility, urban planning and sustainability would seek to deliver long-term benefits for Brisbane.
6. Subject to the approval of Council to enter into the arrangement, and following ratification by the City of Los Angeles, a finalised version of the Sister City Agreement (refer Attachment A, submitted on file)

will be signed by the Lord Mayor or an authorised Council delegate on behalf of Council. Under the Australia's Foreign Relations (State and Territory Arrangements) Act 2020, Council is required to register all arrangements with foreign entities in the Department of Foreign Affairs and Trade's (DFAT's) Foreign Arrangements Portal.

7. The Group Executive provided the following recommendation and the Committee agreed at the meeting of 23 March 2026.

## 8. DECISION:

THAT E&amp;C, AS DELEGATE OF COUNCIL DURING RECESS, APPROVES ENTERING INTO A SISTER CITY ARRANGEMENT WITH THE CITY OF LOS ANGELES, UNITED STATES OF AMERICA.

NOTED

## INFRASTRUCTURE COMMITTEE

The Chair then drew the Councillors' attention to the report setting out the decisions of the Establishment and Coordination Committee as delegate of the Council during the Autumn Recess 2026, on matters usually considered by Infrastructure Committee.

Councillor CASSIDY:

Point of order.

Chair:

Point of order, Councillor CASSIDY.

## SERIATIM EN BLOC -CLAUSES C AND E

Councillor Jared CASSIDY requested that Clause C, PETITION – REQUESTING COUNCIL CONSTRUCT A PEDESTRIAN OVERPASS FROM WESTFIELD MT GRAVATT SHOPPING CENTRE ACROSS LOGAN ROAD, UPPER MT GRAVATT; and Clause E, PETITION – REQUESTING COUNCIL REVIEW PEDESTRIAN ACCESS BETWEEN HARRIER STREET AND MILES PLATTING ROAD, ROCHEDALE, be taken seriatim en bloc for voting purposes.

Councillor JOHNSTON:

Point of order.

Chair:

Point of order, Councillor JOHNSTON.

## SERIATIM -CLAUSE H

Councillor Nicole JOHNSTON requested that Clause H , PETITION – REQUESTING COUNCIL INSTALL PEDESTRIAN CROSSING IMPROVEMENTS ON CLIVE STREET AT THE INTERSECTION OF IPSWICH ROAD, ANNERLEY, be taken seriatim for voting purposes.

Chair:

We’ll now put items A, B, D, F, G, I, J, K, L to the vote.

## CLAUSES A, B, D, F, G, I, J, K AND L PUT

Upon being submitted to the Chamber, Clauses A, B, D, F, G, I, J, K and L of the report of the Infrastructure Committee were declared carried on the voices.

Thereupon, Councillors Jared CASSIDY and Lucy COLLIER immediately rose and called for a division, which resulted in the motion being declared carried .

The voting was as follows:

| AYES: 18  -    | The DEPUTY MAYOR, Councillor Fiona CUNNINGHAM, and Councillors  Krista ADAMS, Greg ADERMANN, Adam ALLAN, Lisa ATWOOD,  Tracy DAVIS, Julia DIXON, Alex GIVNEY, Vicki HOWARD, Steven HUANG,  Sarah HUTTON, Sandy LANDERS, Kim MARX, Ryan MURPHY, Danita PARRY,  Steven TOOMEY, Andrew WINES and Penny WOLFF.   |
|----------------|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| NOES: 8  -     | The Leader of the OPPOSITION, Councillor Jared CASSIDY, and Councillors  Lucy COLLIER, Steve GRIFFITHS, Emily KIM, Charles STRUNK,  Seal CHONG WAH, Trina MASSEY and Nicole JOHNSTON.                                                                                                                        |

Chair:

We’ll now move to vote on items C and E.

## CLAUSES C AND E PUT

Upon being submitted to the Chamber, Clauses C and E of the report of the Infrastructure Committee were declared carried on the voices.

Thereupon, Councillors Seal CHONG WAH and Trina MASSEY immediately rose and called for a division, which resulted in the motion being declared carried .

The voting was as follows:

AYES: 23 -

The DEPUTY MAYOR, Councillor Fiona CUNNINGHAM, and Councillors Krista ADAMS, Greg ADERMANN, Adam ALLAN, Lisa ATWOOD, Tracy DAVIS, Julia DIXON, Alex GIVNEY, Vicki HOWARD, Steven HUANG, Sarah HUTTON, Sandy LANDERS, Kim MARX, Ryan MURPHY, Danita PARRY, Steven TOOMEY, Andrew WINES, Penny WOLFF and the Leader of the OPPOSITION, Councillor Jared CASSIDY, and Councillors Lucy COLLIER, Steve GRIFFITHS, Emily KIM and Charles STRUNK.

NOES: 2 -

Councillors Seal CHONG WAH and Trina MASSEY .

ABSTENTIONS: 1 -

Councillor Nicole JOHNSTON .

Chair:

We’ll now move to item H.

## CLAUSE H PUT

Upon being submitted to the Chamber, Clause H of the report of the Infrastructure Committee was declared carried on the voices.

Thereupon, Councillors Trina MASSEY and Lucy COLLIER immediately rose and called for a division, which resulted in the motion being declared carried .

The voting was as follows:

| AYES: 18  -    | The DEPUTY MAYOR, Councillor Fiona CUNNINGHAM, and Councillors  Krista ADAMS, Greg ADERMANN, Adam ALLAN, Lisa ATWOOD,  Tracy DAVIS, Julia DIXON, Alex GIVNEY, Vicki HOWARD, Steven HUANG,  Sarah HUTTON, Sandy LANDERS, Kim MARX, Ryan MURPHY, Danita PARRY,  Steven TOOMEY, Andrew WINES and Penny WOLFF.   |
|----------------|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| NOES: 8  -     | The Leader of the OPPOSITION, Councillor Jared CASSIDY, and Councillors  Lucy COLLIER, Steve GRIFFITHS, Emily KIM, Charles STRUNK,  Seal CHONG WAH, Trina MASSEY and Nicole JOHNSTON.                                                                                                                        |

The report read as follows

- A PETITION – REQUESTING COUNCIL IMPROVE LOCAL INFRASTRUCTURE ALONG ALGESTER ROAD AND BENHIAM AND ORMSKIRK STREETS, CALAMVALE, AND SURROUNDING AREAS 137/220/594/417

609/2025 -26

1. A petition requesting Council improve local infrastructure along Algester Road and Benhiam and Ormskirk Streets, Calamvale, and surrounding areas (the area), was presented to the meeting of Council held on 18 March 2025, by Councillor Emily Kim, and received.
2. The A/General Manager, Transport Assets and Operations, Infrastructure Services, provided the following information.
3. The petition contains 141 signatures. Of the petitioners, 138 reside within Calamvale Ward and 3 reside outside the City of Brisbane.

4. Council has reviewed the petitioners' requests for resurfacing, traffic flow, road widening and lighting through the area. A locality map is provided at Attachment B (submitted on file).
5. Recent inspections show Ormskirk and Formby Streets are in reasonable to good condition and do not require resurfacing at this time. Benhiam Street, between Durre and Diamantina Streets, has been identified in a future resurfacing program and will be prioritised against citywide needs and available funding. Sections of Algester Road, near Ormskirk and Formby Streets, will also be assessed for inclusion in a future resurfacing program. Routine minor repairs including pothole patching will continue as required.
6. Road widening or realignment of Benhiam and Ormskirk Streets is expected to occur through precinct redevelopment over time. Crash data over the past 5 years, show no incidents linked to road width or alignment.
7. Lighting near Calamvale District Park predates current Australian Standards and requires detailed assessment to determine whether upgrades are warranted. Any works would be prioritised against citywide needs. Nearby footpaths are generally 1.2 metres wide, which meets expectations for residential streets. Motorists are expected to drive to conditions, and organised activities, such as parkrun, provide guidance to participants when moving near roads and car parks.
8. There have been 3 crashes recorded at the Algester Road and Ormskirk Street intersection over the past 5 years, all attributed to driver behaviour. While some congestion occurs during peak periods, performance is considered moderate compared with similar intersections. A roundabout is not supported due to safety risks associated with multi-lane roundabouts and the land required to build one.
9. Wisdom College, located near Formby Street, contributes to short delays during school peak times which is common around schools. Council's Brisbane City Plan 2014 includes mechanisms to ensure new development contributes to road upgrades where appropriate.
7. 10 . Given competing priorities across the city, Council will continue to consider improvements to the area alongside other locations, with safety and community benefit as guiding factors.

Consultation

11. Councillor Emily Kim, Councillor for Calamvale Ward, has been consulted and does not support the recommendation.

Customer impact

12. The submission will respond to the petitioners' concerns.
13. The A/General Manager recommended as follows and the Committee agreed at its meeting held on 23 March 2026.

## 14. DECISION:

THAT THE INFORMATION IN THIS SUBMISSION BE NOTED AND THE DRAFT RESPONSE, AS SET OUT IN ATTACHMENT A, hereunder, BE SENT TO THE HEAD PETITIONER.

## Attachment A Draft Response

## Petition Reference: 137/220/594/417

Thank you for your petition requesting Council improve local infrastructure along Algester Road and Benhiam and Ormskirk Streets, Calamvale, and surrounding areas (the area). Council has reviewed the matters raised and provides the following information.

Recent inspections show Ormskirk and Formby Streets are in reasonable to good condition and do not require resurfacing at this time. Benhiam Street, between Durre and Diamantina Streets, has been identified in a future resurfacing program and will be prioritised against citywide needs and available funding. Sections of Algester Road, near Ormskirk and Formby Streets, will also be assessed for inclusion in a future resurfacing program. Routine minor repairs including pothole patching will continue as required.

Road widening or realignment of Benhiam and Ormskirk Streets is expected to occur through precinct redevelopment over time. Crash data for the past 5 years, show no incidents linked to road width or alignment.

Lighting near Calamvale District Park predates current Australian Standards and requires a detailed assessment to determine whether upgrades are warranted. Any works would be prioritised against citywide needs. Nearby footpaths are generally 1.2 metres wide, which meets expectations for residential streets. Motorists are expected to drive to conditions, and organised activities, such as parkrun, provide guidance to participants when moving near roads and car parks.

There have been 3 crashes recorded at the Algester Road and Ormskirk Street intersection over the past 5 years, all attributed to driver behaviour. While some congestion occurs during peak periods, performance is considered moderate compared with similar intersections. A roundabout is not supported due to safety risks associated with multi-lane roundabouts and the land required to build one.

Wisdom College, located near Formby Street, contributes to short delays during school peak times which is common around schools. Council's Brisbane City Plan 2014 includes mechanisms to ensure new development contributes to road upgrades where appropriate.

Council will continue to monitor the area and prioritise any improvements alongside citywide needs, with safety and community benefit guiding decisions.

The above information will be forwarded to the other petitioners via email.

Should you wish to discuss this matter further, please contact Daniel Gray, A/Principal Engineer Strategic Delivery, Policy Strategy and Planning, Transport Assets and Operations, Infrastructure Services, on 3178 8865.

Thank you for raising this matter

## NOTED

## B PETITION – REQUESTING COUNCIL INSTALL A PEDESTRIAN CROSSING OUTSIDE MORETON BAY COLLEGE ON WONDALL ROAD, MANLY WEST 137/220/594/496

## 610/2025 -26

15. A petition requesting Council install a pedestrian crossing outside Moreton Bay College on Wondall Road, Manly West, was presented to the meeting of Council held on 25 November 2025, by Councillor Lisa Atwood, and received.
16. The A/General Manager, Transport Assets and Operations, Infrastructure Services, provided the following information.
17. The petition contains 34 signatures. Of the petitioners, 2 live in Doboy Ward, 30 live in other wards in the City of Brisbane and 2 live outside of the City of Brisbane.
18. Wondall Road is classified as a suburban road in Council's Brisbane City Plan 2014 road hierarchy. Suburban roads connect residential areas to arterial routes and play an important role in public transport operations and inter-suburban freight movement. Attachment B (submitted on file) shows a locality map.
19. Council acknowledges the petitioners' concerns regarding the safety of children and other vulnerable road users crossing Wondall Road during school peak times. A review of existing traffic controls confirms that a 40 km/h school zone is in place on Wondall Road outside Moreton Bay College. The school zone operates on school days between 7am and 9am, and 2pm and 4pm in accordance with the Queensland Government's Manual of Uniform Traffic Control Devices. The start of the school zone is marked with flashing warning lights, which activate during operating times to increase driver awareness. School zone pavement markings are installed on both approaches.

20. There are currently 2 pedestrian refuge crossing facilities located within the school zone. Pedestrian refuge islands are Council's preferred crossing treatment on roads with speed limits of 60 km/h or higher because they allow pedestrians to cross one direction of traffic at a time, while enabling traffic flow to be maintained. These crossing points are supported by advance 'Refuge Island', 'Pedestrians' and 'Children' fluorescent warning signs.
21. The pedestrian refuge crossing near the bus stops facilitates a staggered crossing and includes a fenced refuge in the centre median approximately 4 m wide and 7 m long. Two permanent Speed Awareness Monitor (SAM) signs operate on approach to this crossing during and outside school zone times, noting Wondall Road has a 60 km/h speed limit outside of school zone times. These SAM signs complement the school zone flashing warning lights during school zone times and encourage motorists to slow down at all times.
22. A review of Queensland Government crash data for the past 5 years showed no pedestrian-related incidents occurring within the school zone. This suggests that pedestrians can cross Wondall Road safely when appropriate care and attention is taken. Based on the available data and existing infrastructure, there are no current plans for additional pedestrian crossing upgrades within the Moreton Bay College school zone on Wondall Road.

## Consultation

23. Councillor Lisa Atwood, Councillor for Doboy Ward, has been consulted and supports the recommendation.

## Customer impact

24. The submission responds to the petitioners' concerns .
25. The A/General Manager recommended as follows and the Committee agreed at its meeting held on 23 March 2026.

## 26. DECISION:

THAT THE INFORMATION IN THIS SUBMISSION BE NOTED AND THE DRAFT RESPONSE, AS SET OUT IN ATTACHMENT A, hereunder, BE SENT TO THE HEAD PETITIONER.

## Attachment A Draft Response

## Petition Reference: 137/220/594/496

Thank you for your petition requesting Council install a pedestrian crossing outside Moreton Bay College on Wondall Road, Manly West.

Council acknowledges your concerns regarding the safety of children and other vulnerable road users crossing Wondall Road during school peak times. A review of existing traffic controls confirms that a 40 km/h school zone is in place on Wondall Road outside Moreton Bay College. The school zone operates on school days between 7am and 9am, and 2pm and 4pm in accordance with the Queensland Government's Manual of Uniform Traffic Control Devices. The start of the school zone is marked with flashing warning lights, which activate during operating times to increase driver awareness. School zone pavement markings are installed on both approaches.

There are currently 2 pedestrian refuge crossing facilities located within the school zone. Pedestrian refuge islands are Council's preferred crossing treatment on roads with speed limits of 60 km/h or higher because they allow pedestrians to cross one direction of traffic at a time, while enabling traffic flow to be maintained. These crossing points are supported by advance 'Refuge Island', 'Pedestrians' and 'Children' fluorescent warning signs.

The pedestrian refuge crossing near the bus stops facilitates a staggered crossing and includes a fenced refuge in the centre median approximately 4 m wide and 7 m long. Two permanent Speed Awareness Monitor (SAM) signs operate on approach to this crossing during and outside school zone times, noting Wondall Road has a 60 km/h speed limit outside of school zone times. These SAM signs complement the school zone flashing warning lights during school zone times and encourage motorists to slow down at all times.

A review of Queensland Government crash data for the past 5 years showed no pedestrian-related incidents occurring within the school zone. This suggests that pedestrians can cross Wondall Road safely when appropriate care and attention is taken. Based on the available data and existing infrastructure, there are no current plans for additional pedestrian crossing upgrades within the Moreton Bay College school zone on Wondall Road.

The above information will be forwarded to the other petitioners via email.

Should you wish to discuss this matter further, please contact Brian Nichol, A/Senior Programs and Engineer Team Leader, Transport Network Performance, Transport Assets and Operations, Infrastructure Services, on 3403 7674.

Thank you for raising this matter.

## NOTED

- C PETITION – REQUESTING COUNCIL CONSTRUCT A PEDESTRIAN OVERPASS FROM WESTFIELD MT GRAVATT SHOPPING CENTRE ACROSS LOGAN ROAD, UPPER MT GRAVATT

137/220/594/505

## 611/2025 -26

27. A petition requesting Council construct a pedestrian overpass from Westfield Mt Gravatt shopping centre (the shopping centre) across Logan Road, Upper Mt Gravatt, was received during the Summer Recess 2025 -26.
28. The A/General Manager, Transport Assets and Operations, Infrastructure Services, provided the following information.
29. The petition contains 11 signatures. Of the petitioners, none live in MacGregor Ward, 5 live in other wards in the City of Brisbane, and 6 live outside the City of Brisbane.
30. Logan Road is classified as an arterial road in Council's Brisbane City Plan 2014 road hierarchy. Arterial roads connect major centres of the city and provide an important link in Brisbane's public transport and freight network.
31. The petitioners have requested a pedestrian overpass to improve safety for pedestrians. Council's review of Logan Road, between Kessels Road and Links Street, shows that multiple signalised pedestrian crossings are provided to access the shopping centre, as shown in Attachment B (submitted on file). A pedestrian overpass at this location would provide little benefit. The level difference often makes pedestrian overpasses unattractive to use, especially while crossing remains lawful and frequently quicker at road level. They also require a significant footprint, often requiring land from adjacent properties and/or reducing the available verge width.
32. Logan Road, south of Mt Gravatt-Capalaba Road, is owned and managed by the Queensland Government's Department of Transport and Main Roads (TMR). Any changes to road infrastructure along this section of Logan Road, including the construction of a pedestrian overpass, falls under the jurisdiction of TMR. Petitioners are required to make their request for a pedestrian overpass at this location with TMR directly.

## Consultation

33. Councillor Steven Huang, Councillor for MacGregor Ward, has been consulted and supports the recommendation.

Customer impact

34. The submission responds to the petitioners' concerns.

35. The A/General Manager recommended as follows and the Committee agreed at its meeting held on 23 March 2026.

## 36. DECISION:

THAT THE INFORMATION IN THIS SUBMISSION BE NOTED AND THE DRAFT RESPONSE, AS SET OUT IN ATTACHMENT A, hereunder, BE SENT TO THE HEAD PETITIONER.

## Attachment A Draft Response

## Petition Reference: 137/220/594/505

Thank you for your petition requesting Council construct a pedestrian overpass from Westfield Mt Gravatt shopping centre (the shopping centre) across Logan Road, Upper Mt Gravatt.

Council acknowledges your request for a pedestrian overpass to improve safety for pedestrians. Council's review of Logan Road, between Kessels Road and Links Street, shows that multiple signalised pedestrian crossings are provided to access the shopping centre. A pedestrian overpass at this location would provide little benefit. The level difference often makes pedestrian overpasses unattractive to use, especially while crossing remains lawful and frequently quicker at road level. They also require a significant footprint, often requiring land from adjacent properties and/or reducing the available verge width.

Logan Road, south of Mt Gravatt-Capalaba Road, is owned and managed by the Queensland Government's Department of Transport and Main Roads (TMR). Any changes to road infrastructure along this section of Logan Road, including the construction of a pedestrian overpass, falls under the jurisdiction of TMR. You can make a request for a pedestrian overpass at this location with TMR directly, by calling 3066 4338 or via email at MetropolitanRegion@tmr.qld.gov.au.

The above information will be forwarded to the other petitioners via email.

Should you wish to discuss this matter further, please contact Daniel Gray, A/Principal Engineer Strategic Delivery, Policy Strategy and Planning, Transport Assets and Operations, Infrastructure Services, on 3178 8865.

NOTED

- D PETITION – REQUESTING COUNCIL CONSTRUCT MISSING FOOTPATH SECTIONS ALONG RITCHIE AND GOODERHAM ROADS, AND INSTALL 2 PEDESTRIAN CROSSINGS ON RITCHIE ROAD, PALLARA 137/220/594/483

## 612/2025 -26

37. A petition requesting Council construct missing footpath sections along Ritchie and Gooderham Roads, and install 2 pedestrian crossings on Ritchie Road, Pallara, was presented to the meeting of Council held on 4 November 2025, by Councillor Emily Kim, and received.
38. The A/General Manager, Transport Assets and Operations, Infrastructure Services, provided the following information.
39. The petition contains 224 signatures. Of the petitioners, 194 live in Calamvale Ward, 28 live in other wards within the City of Brisbane, and 2 live outside of the City of Brisbane.
40. Council acknowledges the petitioners' request to construct new or missing footpath links along Ritchie and Gooderham Roads. These roads are classified as suburban roads in Council's Brisbane City Plan 2014 road hierarchy. Suburban roads connect to arterial routes in and around suburbs forming an important link in the public transport and inter-suburban freight network. Attachment B (submitted on file) shows a locality map.
41. In 2025 -26, Council distributed $16.38 million evenly between each ward through the Suburban Enhancement Fund (SEF) to deliver local priority projects, including the provision of new footpaths and

local park improvements. Each local Councillor plays a role in determining which new projects are funded from their SEF following community consultation.

42. Council provides the following information on specific sections of footpath identified by the petitioners.

## Ritchie Road – Cornwall Street to Hideaway Street

43. Councillor Emily Kim, Councillor for Calamvale Ward, has allocated SEF funding for design work to extend 2 enclosed drainage outlets which will enable future footpath construction between the enclosed drainage outlet and the bend in the road. Construction of the footpath will be subject to future SEF allocation.

## Ritchie Road – Hideaway Street to Bill Watson Way

44. The footpath along this section of road is largely complete, with 2 missing segments located outside 226 and 282 Ritchie Road (Pallara State School Junior Campus). These segments are anticipated to be delivered as part of current developments at 226 Ritchie Road and 282 Ritchie Road once construction has completed.

## Ritchie and Gooderham Roads – Bill Watson Way to Brookbent Road

45. No footpath currently exists along this section, however, Councillor Kim may consider funding this section through future SEF allocation.
46. Regarding the petitioners' request for crossings near Hideaway Street and Kraft Road, a supervised pedestrian crossing has been constructed on Ritchie Road near Kraft Road as part of the Queensland Government's Ministerial Infrastructure Designation for Pallara State School Junior Campus. The pedestrian crossing includes kerb buildouts to improve sightlines and crossing distance. A school zone is also in place, reducing the speed limit from 60 km/h to 40 km/h, between 7am to 9am and 2pm to 4pm on weekdays.
47. Council is considering a pedestrian crossing on Ritchie Road near Hideaway Street, in conjunction with planned new bus stops. Funding for design and delivery will depend on the project's priority relative to other citywide proposals. At this time, no budget or timeframe has been identified.
48. Petitioners are encouraged to submit requests for new footpath links to Councillor Kim for consideration through future Calamvale Ward SEF allocation. Councillor Kim can be contacted via the Calamvale Ward Office on 3131 7022 or calamvale.ward@bcc.qld.gov.au.

## Consultation

49. Councillor Emily Kim, Councillor for Calamvale Ward, has been consulted and does not support the recommendation.

## Customer impact

50. The submission will respond to the petitioners' concerns.
51. The A/General Manager recommended as follows and the Committee agreed at its meeting held on 30 March 2026.

## 52. DECISION:

THAT THE INFORMATION IN THIS SUBMISSION BE NOTED AND THE DRAFT RESPONSE, AS SET OUT IN ATTACHMENT A, hereunder, BE SENT TO THE HEAD PETITIONER.

Petition Reference: 137/220/594/483

Thank you for your petition requesting Council construct missing footpath sections along Ritchie and Gooderham Roads, and install 2 pedestrian crossings on Ritchie Road, Pallara.

In 2025 -26, Council distributed $16.38 million evenly between each ward through the Suburban Enhancement Fund (SEF) to deliver local priority projects, including the provision of new footpaths and local park improvements. Each local Councillors plays a role in determining which new projects are funded from their SEF following community consultation.

Council provides the following information on specific sections of footpath identified in your petition.

## Ritchie Road – Cornwall Street to Hideaway Street

Councillor Emily Kim, Councillor for Calamvale Ward, has allocated SEF funding for design work to extend 2 enclosed drainage outlets which will enable future footpath construction between the enclosed drainage outlet and the bend in the road. Construction of the footpath will be subject to future SEF allocation.

## Ritchie Road – Hideaway Street to Bill Watson Way

The footpath along this section of road is largely complete, with 2 missing segments located outside 226 and 282 Ritchie Road (Pallara State School Junior Campus). These segments are anticipated to be delivered as part of current developments at 226 Ritchie Road and 282 Ritchie Road once construction has completed.

## Ritchie and Gooderham Roads – Bill Watson Way to Brookbent Road

No footpath currently exists along this section, however, Councillor Kim may consider funding this section through future SEF allocation.

Regarding your request for crossings near Hideaway Street and Kraft Road, a supervised pedestrian crossing has been constructed on Ritchie Road near Kraft Road as part of the Queensland Government's Ministerial Infrastructure Designation for Pallara State School Junior Campus. The pedestrian crossing includes kerb buildouts to improve sightlines and crossing distance. A school zone is also in place, reducing the speed limit from 60 km/h to 40 km/h, between 7am to 9am and 2pm to 4pm on weekdays.

Council is considering a pedestrian crossing on Ritchie Road near Hideaway Crescent, in conjunction with planned new bus stops. Funding for design and delivery will depend on the project's priority relative to other citywide proposals. At this time, no budget or timeframe has been identified.

You are encouraged to submit requests for new footpaths links to Councillor Kim for consideration through future Calamvale Ward SEF allocation. Councillor Kim can be contacted via the Calamvale Ward Office on 3131 7022 or calamvale.ward@bcc.qld.gov.au.

The above information will be forwarded to the other petitioners via email.

Should you wish to discuss this matter further, please contact Mr Thomas Thai, Senior Transport Planner, Policy Strategy and Planning, Transport Assets and Operations, Infrastructure Services, on 3403 3424.

Thank you for raising this matter.

## Attachment A Draft Response

NOTED

## E PETITION – REQUESTING COUNCIL REVIEW PEDESTRIAN ACCESS BETWEEN HARRIER STREET AND MILES PLATTING ROAD, ROCHEDALE 137/220/594/492

## 613/2025 -26

53. A petition requesting Council review pedestrian access between Harrier Street and Miles Platting Road, Rochedale, was presented to the meeting of Council held on 18 November 2025, by Councillor Steven Huang, and received.
54. The A/General Manager, Transport Assets and Operations, Infrastructure Services, provided the following information.
55. The petition contains 34 signatures. All the petitioners live in MacGregor Ward.
56. The petitioners have raised the following concerns.
5. -Pedestrian access from Harrier Street to Miles Platting Road will be reduced after construction of Stage 3 of Arbor Residences is completed and requests Council review.
6. -Removal of the existing pedestrian access has created inconvenience to local residents and anti -social behaviour.
7. -Pedestrian access.
57. Approval for temporary access between Harrier Street and Miles Platting Road was included in the development application for Reconfiguration of a lot (application reference A004873844) on 23 November 2018, with a subsequent change application approval on 31 July 2019 (application reference A005175115). Temporary access was approved to enable the delivery of residential lots prior to the final road layout being delivered.
58. Approval for the final road layout between Harrier Street and Miles Platting Road was included in the development application for Reconfiguration of a lot (application reference A004897067) on 21 August 2019. Council assessed these applications, including traffic impact assessments, against the provisions of Council's Brisbane City Plan 2014 and in accordance with the provisions of the Planning Act 2016 (the Act).
59. On 28 July 2020, Council approved the 3-stage Multiple Dwelling development (Arbor Residences) (application reference A005314900) for 38 townhouses, including removal of the temporary access upon completion of Stage 3. All relevant development applications were subject to impact assessment, with formal public notification carried out in accordance with the provisions of the Act.
60. The final road layout provides appropriate, safe and convenient vehicle and pedestrian access for the neighbourhood and aligns with the overall structure planning for the estate. Attachment B (submitted on file) shows a locality map. A copy of the relevant development applications can be viewed online via Council's Development.i website at developmenti.brisbane.qld.gov.au by searching the relevant application reference number.
61. Private property access is a civil matter, and the petitioners are encouraged to raise their concern with Queensland Police Service as the relevant authority who manage anti-social behaviour.
62. While there are no plans to construct an additional pedestrian connection between Harrier Street and Miles Platting Road beyond the final access, Council's Local government infrastructure plan includes the future extension of Gardner Road between Miles Platting and Priestdale Roads which will provide pedestrian access between Raptor Street and Miles Platting Road.

## Consultation

63. Councillor Steven Huang, Councillor for MacGregor Ward, has been consulted and supports the recommendation.

## Customer impact

64. The submission responds to the petitioners' concerns.
65. The A/General Manager recommended as follows and the Committee agreed at its meeting held on 30 March 2026.

## 66. DECISION:

THAT THE INFORMATION IN THIS SUBMISSION BE NOTED AND THE DRAFT RESPONSE, AS SET OUT IN ATTACHMENT A, hereunder, BE SENT TO THE HEAD PETITIONER.

## Attachment A Draft Response

## Petition Reference: 137/220/594/492

Thank you for your petition requesting Council review pedestrian access between Harrier Street and Miles Platting Road, Rochedale.

Council acknowledges your concerns regarding the removal of the temporary pedestrian and road access (temporary access) located at 21 Harrier Street, Rochedale. This temporary access was allowed to enable the delivery of residential lots prior to the ultimate road network (final access) being delivered. Many factors determine the final access, which will enable long-term efficient and safe functioning of the road network, in line with best practice road design.

The temporary access between Harrier Street and Miles Platting Road was included as part of a development application for Reconfiguration of a lot (application reference A004873844) on 23 November 2018, with a subsequent change application approval on 31 July 2019 (application reference A005175115). Temporary access was approved to enable the delivery of residential lots prior to the final road layout being delivered.

Approval for the road layout between Harrier Street and Miles Platting Road was included in the development application for Reconfiguration of a lot (application reference A004897067) on 21 August 2019. Council assessed these applications, including traffic impact assessments, against the provisions of Council's Brisbane City Plan 2014 and in accordance with the provisions of the Planning Act 2016 (the Act).

On 28 July 2020, Council approved the 3-stage Multiple Dwelling development (Arbor Residences) (Council reference A005314900) for 38 townhouses including removal of the temporary access upon completion of Stage 3. All relevant development applications were subject to impact assessment, with formal public notification carried out in accordance with the provisions of the Act.

The final road layout provides appropriate, safe and convenient vehicle and pedestrian access for the neighbourhood and aligns with the overall structure planning for the estate. A copy of the relevant development applications can be viewed online via Council's Development.i website at developmenti.brisbane.qld.gov.au, by searching the relevant application reference number.

Private property access is a civil matter, and you are encouraged to raise your concern with Queensland Police Service as the relevant authority who manage anti-social behaviour.

While there are no plans to construct an additional pedestrian connection between Harrier Street and Miles Platting Road beyond the final road layout, Council's Local government infrastructure plan includes the future extension of Gardner Road between Miles Platting and Priestdale Roads which will provide pedestrian access between Raptor Street and Miles Platting Road.

Please let the other petitioners know of this information.

Should you wish to discuss this matter further, please contact Mr Daniel Gray, A/Principal Engineer Strategic Delivery, Policy Strategy and Planning, Transport Assets and Operations, Infrastructure Services, on 3178 8865.

Thank you for raising this matter.

NOTED

## F PETITION – REQUESTING COUNCIL ALLOCATE FUNDING TO RESTORE THE STORY BRIDGE AND KEEP THE STORY BRIDGE TOLL FREE 137/220/594/515

## 614/2025 -26

67. A petition requesting Council allocate funding to restore the Story Bridge (the bridge) and keep the bridge toll -free, was received during the Summer Recess 2025-26.
68. The A/General Manager, Transport Assets and Operations, Infrastructure Services, provided the following information.
69. The petition contains 179 signatures. Of the petitioners, 173 live in the City of Brisbane and 6 live outside the City of Brisbane.
70. Council is currently developing a detailed business case for the restoration of the bridge, which is expected to be completed in 2026. The business case is jointly funded by the Australian Government and will confirm the scope, staging and cost of bridge restoration works.
71. Under the Transport Infrastructure Act 1994 (the Act), Council does not have the power to impose a toll on the bridge unless the Minister for Transport and Main Roads declares the bridge as a tollway under section 105GA of the Act.
72. Neither Council nor the Queensland Government support the introduction of a toll on the bridge. Instead, Council is committed to working with both the Queensland and Australian Governments to fund and deliver the bridge restoration project.

## Consultation

73. As this is a citywide matter, Councillor Ryan Murphy, Civic Cabinet Chair for the Infrastructure Committee, has been consulted and supports the recommendation.

## Customer impact

74. The submission responds to the petitioners' concerns.
75. The A/General Manager recommended as follows and the Committee agreed at its meeting held on 30 March 2026.

## 76. DECISION:

THAT THE INFORMATION IN THIS SUBMISSION BE NOTED AND THE DRAFT RESPONSE, AS SET OUT IN ATTACHMENT A, hereunder, BE SENT TO THE HEAD PETITIONER.

## Attachment A Draft Response

## Petition Reference: 137/220/594/515

Thank you for your petition requesting Council allocate funding to restore the Story Bridge (the bridge) and keep the bridge toll-free.

Council is currently developing a detailed business case for the restoration of the bridge, which is expected to be completed in 2026. The business case is jointly funded by the Australian Government and will confirm the scope, staging and cost of bridge restoration works.

Under the Transport Infrastructure Act 1994 (the Act), Council does not have the power to impose a toll on the bridge unless the Minister for Transport and Main Roads declares the bridge as a tollway under section 105GA of the Act.

Neither Council nor the Queensland Government support the introduction of a toll on the bridge. Instead, Council is committed to working with both the Queensland and Australian Governments to fund and deliver the bridge restoration project.

The above information will be forwarded to the other petitioners via email.

Should you wish to discuss this matter further, please contact Mr Brendan O'Keeffe, Principal Engineer Policy and Strategy, Policy Strategy and Planning, Transport Assets and Operations, Infrastructure Services, on 3403 7671.

Thank you for raising this matter.

## NOTED

## G PETITION – REQUESTING COUNCIL INSTALL SAFETY IMPROVEMENTS AT THE ZEBRA CROSSING ON LOGAN ROAD NEAR GLINDEMANN PARK, HOLLAND PARK WEST 137/220/594/523

## 615/2025 -26

77. A petition requesting that Council install safety improvements at the zebra crossing on Logan Road near Glindemann Park, Holland Park West, was received during the Summer Recess 2025-26.
78. The A/General Manager, Transport Assets and Operations, Infrastructure Services, provided the following information.
79. The petition contains 727 signatures. Of the petitioners, 359 live in Holland Park Ward, 323 live in other wards in the City of Brisbane and 45 live outside the City of Brisbane.
80. Council appreciates how important this crossing is for families, cyclists, and people visiting the park and the new BMX facilities, and values the strong community engagement and commitment shown to making the area safer for everyone.
81. Logan Road at the zebra crossing location is classified as an arterial road in Council's Brisbane City Plan 2014 road hierarchy. These roads connect major centres and form key links in Brisbane's transport and freight network. With Brisbane being one of Australia's fastest-growing cities, more people are moving around our suburbs every day, and this growth brings both challenges and opportunities for our transport network. This context is important because it affects what types of crossings can be safely installed on multi -lane, high-traffic routes such as Logan Road. Attachment B (submitted on file) shows a locality map.
82. The zebra crossing at Glindemann Park was installed over 20 years ago and no longer meets current engineering standards for multi-lane environments. Updated requirements from the Queensland Government's Manual of Uniform Traffic Control Devices, Part 10: Pedestrian Control and Protection , and Australian Standard 1742.10 – 2024 specify that zebra crossings must have a maximum approach speed of 50 km/h or less and are not suitable for multi-lane roads.
83. Council notes the high traffic volumes and arterial road function of Logan Road, limitations of the crossing layout across multiple traffic lanes, and the increasing pedestrian demand associated with the nearby park and the new BMX tracks.
84. To date, Council has implemented a number of measures to improve safety at this location, including installing extensive high-visibility pedestrian warning signs, pavement markings and 2 LED 'SLOW DOWN' signs to increase driver awareness and encourage reduced speeds.
85. Council is also aware of the recent incident involving a young cyclist. Ensuring that residents can move around their suburbs safely is a priority for Council, and we continue to invest in safer roads across Brisbane so people can get home sooner and safer.
86. To support the next stage of decision-making, detailed traffic and pedestrian surveys were scheduled for January (school holiday) and February (school term) 2026. These surveys will provide the most accurate and up-to-date information, and their findings will guide the assessment of potential upgrades. Detailed analysis is anticipated to be completed by the end of June 2026.
87. Some of the concerns raised relate to motorists failing to stop and give way. This is an example of poor driver behaviour. Enforcement of moving traffic offences is the responsibility of Queensland Police

Service and not something Council has the legislative authority to undertake. Anyone witnessing unsafe behaviour is encouraged to contact Policelink.

## Consultation

88. Councillor Krista Adams, Councillor for Holland Park Ward, has been consulted and supports the recommendation.

## Customer impact

89. The submission responds to the petitioners' concerns.
90. The A/General Manager recommended as follows and the Committee agreed at its meeting held on 30 March 2026.

## 91. DECISION:

THAT THE INFORMATION IN THIS SUBMISSION BE NOTED AND THE DRAFT RESPONSE, AS SET OUT IN ATTACHMENT A, hereunder, BE SENT TO THE HEAD PETITIONER.

## Attachment A Draft Response

## Petition Reference: 137/220/594/523

Thank you for your petition requesting Council install safety improvements at the zebra crossing on Logan Road opposite Glindemann Park, Holland Park West.

Council appreciates how important this crossing is for families, cyclists, and people visiting the park and the new BMX facilities, and values the strong community engagement and commitment shown to making the area safer for everyone.

Logan Road at the zebra crossing location is classified as an arterial road in Council's Brisbane City Plan 2014 road hierarchy. These roads connect major centres and form key links in Brisbane's transport and freight network. With Brisbane being one of Australia's fastest-growing cities, more people are moving around our suburbs every day, and this growth brings both challenges and opportunities for our transport network. This context is important because it affects what types of crossings can be safely installed on multi -lane, high-traffic routes such as Logan Road.

The zebra crossing at Glindemann Park was installed over 20 years ago and no longer meets current engineering standards for multi-lane environments. Updated requirements from the Queensland Government's Manual of Uniform Traffic Control Devices, Part 10: Pedestrian Control and Protection , and Australian Standard 1742.10 – 2024 specify that zebra crossings must have a maximum approach speed of 50 km/h or less and are not suitable for multi-lane roads.

Council notes the high traffic volumes and arterial road function of Logan Road, limitations of the crossing layout across multiple traffic lanes, and the increasing pedestrian demand associated with the nearby park and the new BMX tracks.

To date, Council has implemented a number of measures to improve safety at this location, including installing extensive high-visibility pedestrian warning signs, pavement markings and 2 LED 'SLOW DOWN' signs to increase driver awareness and encourage reduced speeds.

Council is also aware of the recent incident involving a young cyclist. Ensuring that residents can move around their suburbs safely is a priority for Council, and we continue to invest in safer roads across Brisbane so people can get home sooner and safer .

To support the next stage of decision-making, detailed traffic and pedestrian surveys were scheduled for January (school holiday) and February (school term) 2026. These surveys will provide the most accurate and up-to-date information, and their findings will guide the assessment of potential upgrades. Detailed analysis is anticipated to be completed by the end of June 2026.

Some of the concerns raised relate to motorists failing to stop and give way. This is an example of poor driver behaviour. Enforcement of moving traffic offences is the responsibility of Queensland Police Service and not something Council has the legislative authority to undertake. Anyone witnessing unsafe behaviour is encouraged to contact Policelink on 131 444.

The above information will be forwarded to the other petitioners via email.

Should you wish to discuss this matter further, please contact Mr Brian Nichol, Senior Transport Network Officer, Transport Network Performance, Transport Assets and Operations, Infrastructure Services, on 3403 7674.

Thank you for raising this matter

## NOTED

## H PETITION – REQUESTING COUNCIL INSTALL PEDESTRIAN CROSSING IMPROVEMENTS ON CLIVE STREET AT THE INTERSECTION OF IPSWICH ROAD, ANNERLEY 137/220/594/485

## 616/2025 -26

92. A petition requesting Council install pedestrian crossing improvements on Clive Street at the intersection of Ipswich Road, Annerley, was presented to the meeting of Council held on 4 November 2025, by Councillor Nicole Johnston, and received.
93. The A/General Manager, Transport Assets and Operations, Infrastructure Services, provided the following information.
94. The petition contains 78 signatures. Of the petitioners, 32 live in Tennyson Ward, 45 live in other wards within the City of Brisbane, and one lives outside of the City of Brisbane.
95. Council acknowledges the petitioners' concerns regarding the width of Clive Street, vehicle speeds and the perceived difficulty and safety risks for pedestrians, cyclists and people with mobility impairments crossing at this location. Clive Street is classified as a neighbourhood road in Council's Brisbane City Plan 2014 road hierarchy, providing access to local shops, businesses and residential properties. Attachment B (submitted on file) shows a locality map.
96. When assessing the suitability of pedestrian crossing facilities, Council is guided by the Queensland Government's Department of Transport and Main Roads (TMR) Manual of Uniform Traffic Control Devices, Part 10: Pedestrian control and protection.
97. Pedestrian zebra crossings are generally installed where there is high pedestrian activity throughout the day and where the posted speed limit is 50 km/h or lower. Council must also consider the potential risks associated with zebra crossings, including:
7. -pedestrians developing a false sense of security and stepping into the crossing without ensuring approaching vehicles are slowing or stopping
8. -drivers becoming conditioned to low pedestrian demand at under-utilised crossings, reducing compliance over time
9. -decreased driver attention at locations close to busy intersections, where motorists may be focused on finding gaps in through-traffic rather than observing crossing points.
98. Given the proximity of Clive Street to Ipswich Road and the nature of turning movements at this intersection, installing a raised wombat zebra crossing would reduce safety for pedestrians and therefore is not supported at this location.
99. Council supports pedestrian safety improvements such as splitter islands or kerb extensions, which shorten crossing distances and improve visibility between pedestrians and motorists. This intersection has been identified for potential future works which will be considered as part of Council's citywide prioritisation of pedestrian safety proposals. At this time, there is no confirmed timeframe or allocated budget for these works.

## Consultation

100. Councillor Nicole Johnston, Councillor for Tennyson Ward, has been consulted and has not indicated whether she supports or opposes the recommendation.

## Customer impact

101. The submission will respond to the petitioners' concerns.
102. The A/General Manager recommended as follows and the Committee agreed at its meeting held on 20 April 2026.

## 103. DECISION:

THAT THE INFORMATION IN THIS SUBMISSION BE NOTED AND THE DRAFT RESPONSE, AS SET OUT IN ATTACHMENT A, hereunder, BE SENT TO THE HEAD PETITIONER.

## Attachment A Draft Response

## Petition Reference: 137/220/594/485

Thank you for your petition requesting Council install pedestrian crossing improvements on Clive Street at the intersection of Ipswich Road, Annerley.

Council acknowledges your concerns regarding the width of Clive Street, vehicle speeds and the perceived difficulty and safety risks for pedestrians, cyclists and people with mobility impairments crossing at this location.

When assessing the suitability of pedestrian crossing facilities, Council is guided by the Queensland Government's Department of Transport and Main Roads (TMR) Manual of Uniform Traffic Control Devices, Part 10: Pedestrian control and protection.

Pedestrian zebra crossings are generally installed where there is high pedestrian activity throughout the day and where the posted speed limit is 50 km/h or lower. Council must also consider the potential risks associated with zebra crossings, including:

- -pedestrians developing a false sense of security and stepping into the crossing without ensuring approaching vehicles are slowing or stopping
- -drivers becoming conditioned to low pedestrian demand at under-utilised crossings, reducing compliance over time
- -decreased driver attention at locations close to busy intersections, where motorists may be focused on finding gaps in through-traffic rather than observing crossing points.

Given the proximity of Clive Street to Ipswich Road and the nature of turning movements at this intersection, installing a raised wombat zebra crossing would reduce safety for pedestrians and therefore is not supported at this location.

Council supports pedestrian safety improvements such as splitter islands or kerb extensions, which shorten crossing distances and improve visibility between pedestrians and motorists. This intersection has been identified for potential future works which will be considered as part of Council's citywide prioritisation of pedestrian safety proposals. At this time, there is no confirmed timeframe or allocated budget for these works.

The above information will be forwarded to the other petitioners via email.

Should you wish to discuss this matter further, please contact Mr Kiran Sreedharan, Senior Transport Network Officer, Transport Network Performance, Transport Assets and Operations, Infrastructure Services, on 3178 1178.

Thank you for raising this matter.

<!-- image -->

Based on the provided image and its crops, the only visible text is the word "NOTED".

The text is in a dark, bold, sans-serif font against a light background. The image is low-resolution and appears blurry.

There are no project names, budget figures, locations, procurement indicators, or council decisions visible in the image.

## I PETITION – REQUESTING COUNCIL INSTALL TRAFFIC SIGNALS AT THE INTERSECTION OF LEVINGTON AND UNDERWOOD ROADS, EIGHT MILE PLAINS 137/220/594/499

## 617/2025 -26

104. A petition requesting Council install traffic signals at the intersection of Levington and Underwood Roads, Eight Mile Plains, was presented to the meeting of Council held on 2 December 2025 , by Councillor Steven Huang, and received.
105. The A/General Manager, Transport Assets and Operations, Infrastructure Services, provided the following information.
106. The petition contains 134 signatures. Of the petitioners, 87 live in MacGregor Ward, 39 live in Runcorn Ward, 5 live in other wards in the City of Brisbane and 3 live outside the City of Brisbane.
107. Underwood Road is classified as a suburban road and Levington Road is classified as a district road in the road hierarchy of Council's Brisbane City Plan 2014. Attachment B (submitted on file) shows a locality map.
108. The petitioners' concern for safety at the intersection is noted. The intersection is listed in Council's Local government infrastructure plan (LGIP) as a future road intersection project. The LGIP supports the city's growth by guiding the coordinated, efficient and financially sustainable planning and delivery of significant infrastructure.
109. There is significant demand for traffic signals and other road network improvements across Brisbane. Therefore, all requests must be prioritised so that Council's resources are directed to the streets and areas most in need of traffic management works, including those that offer the greatest benefit in terms of safety and amenity to the wider community.
110. The future road intersection project may include the installation of traffic and pedestrian signals, subject to further detailed investigations. At this stage, consideration for additional funding to undertake the further detailed investigations, design and construction of this project is subject to an assessment of its priority relative to other citywide projects. As such, there is no current timeframe or allocated budget for this project.
111. Pedestrians crossing Underwood Road near the intersection are encouraged to use the existing pedestrian refuge crossing located approximately 80 metres east of this intersection. Pedestrian refuge islands are Council's preferred crossing treatment on roads with speed limits of 60 km/h or higher, as they support a staged crossing, letting pedestrians navigate each direction of traffic separately, while still ensuring traffic flow is maintained.
112. To highlight the pedestrian refuge crossing to approaching motorists, Council has installed advance 'Refuge Island' 'Pedestrians' and 'Aged' warning signs fitted with large red target boards on both approaches. The refuge includes galvanised steel handrails with reflective bands and 'Safety Zone' signs to delineate the crossing facility for approaching motorists. 'Keep Left' signs are also installed to guide motorists past the centre island. Given the extensive safety signage at the pedestrian refuge crossing, no further enhancements are currently required.

## Consultation

113. Councillor Steven Huang, Councillor for MacGregor Ward, has been consulted and supports the recommendation.
114. Councillor Kim Marx, Councillor for Runcorn Ward, has been consulted and supports the recommendation.

## Customer impact

115. The submission responds to the petitioners' concerns.

116. The A/General Manager recommended as follows and the Committee agreed at its meeting held on 20 April 2026.

## 117. DECISION:

THAT THE INFORMATION IN THIS SUBMISSION BE NOTED AND THE DRAFT RESPONSE, AS SET OUT IN ATTACHMENT A, hereunder, BE SENT TO THE HEAD PETITIONER.

## Attachment A Draft Response

## Petition Reference: 137/220/594/499

Thank you for your petition requesting Council install traffic signals at the intersection of Levington and Underwood Roads, Eight Mile Plains (the intersection).

Your concern for safety at the intersection is noted. The intersection is listed in Council's Local government infrastructure plan (LGIP) as a future road intersection project. The LGIP supports the city's growth by guiding the coordinated, efficient and financially sustainable planning and delivery of significant infrastructure.

There is significant demand for traffic signals and other road network improvements across Brisbane. Therefore, all requests must be prioritised so that Council's resources are directed to the streets and areas most in need of traffic management works, including those that offer the greatest benefit in terms of safety and amenity to the wider community.

The future road intersection project may include the installation of traffic and pedestrian signals, subject to further detailed investigations. At this stage, consideration for additional funding to undertake the further detailed investigations, design and construction of this project is subject to an assessment of its priority relative to other citywide projects. As such, there is no current timeframe or allocated budget for this project.

Pedestrians crossing Underwood Road near the intersection are encouraged to use the existing pedestrian refuge crossing located approximately 80 metres east of this intersection. Pedestrian refuge islands are Council's preferred crossing treatment on roads with speed limits of 60 km/h or higher, as they support a staged crossing, letting pedestrians navigate each direction of traffic separately, while still ensuring traffic flow is maintained.

To highlight the pedestrian refuge crossing to approaching motorists, Council has installed advance 'Refuge Island' 'Pedestrians' and 'Aged' warning signs fitted with large red target boards on both approaches. The refuge includes galvanised steel handrails with reflective bands and 'Safety Zone' signs to delineate the crossing facility to approaching motorists. 'Keep Left' signs are also installed to guide motorists past the centre island. Given the extensive safety signage at the pedestrian refuge crossing, no further enhancements are currently required.

The above information will be forwarded to the other petitioners via email.

Should you wish to discuss this matter further, please contact Mr Daniel Gray, Principal Engineer Strategic Delivery, Policy Strategy and Planning, Transport Assets and Operations, Infrastructure Services, on 3178 8865.

Thank you for raising this matter.

NOTED

- J PETITION – REQUESTING COUNCIL IMPLEMENT TRAFFIC CALMING DEVICES ON THE PARKWAY, STRETTON 137/220/594/502

## 618/2025 -26

118. A petition requesting Council implement traffic calming devices on The Parkway, Stretton, was presented to the meeting of Council held on 9 December 2025, by Councillor Emily Kim, and received.

119. The A/General Manager, Transport Assets and Operations, Infrastructure Services, provided the following information.
120. The petition contains 12 signatures. Of the petitioners, 11 live in Calamvale Ward and one lives outside the City of Brisbane.
121. The Parkway has a default speed limit of 50 km/h and is classified as a neighbourhood road under Council's Brisbane City Plan 2014 (City Plan), Its primary function is to provide access to local residential properties. Attachment B (submitted on file) shows a locality map.
122. The petitioners' request for traffic calming devices on The Parkway, Stretton, has been considered. The installation of traffic calming devices, such as speed platforms and chicanes, may be used to discourage use from non -local traffic and to moderate vehicle speeds. Council considers the installation of traffic calming devices only where there is a combination of both a demonstrated widespread issue of non-local traffic utilising the street and where there is a demonstrated and persistent speeding issue. Speeding issues alone are not sufficient to consider the use of traffic calming devices as speeding is predominately a driver behaviour issue under the jurisdiction of Queensland Police Service (QPS). Residents are encouraged to report ongoing concerns about speeding or hooning behaviour directly to QPS.
123. A review of the road network indicates that The Parkway does not offer time or distance savings for through-traffic and primarily services as an enclosed residential catchment. As a result, most vehicles using The Parkway are local residents or visitors, and the street is operating as intended under Council's City Plan road hierarchy.
124. In October 2025, Council undertook a traffic survey to assess traffic volumes and vehicle speeds on The Parkway (refer Attachment C, submitted on file) with results showing an average traffic volume of 1,583 vehicles per weekday, which is within the acceptable range for a neighbourhood road and average vehicle speeds of 40.2 km/h, indicating reasonable compliance with the 50 km/h speed limit.
125. Council acknowledges the petitioners' concerns for pedestrian safety. The Parkway has concrete footpaths on both sides for its entire length. Combined with the observed low vehicle speeds, these features support safe pedestrian movement and road crossing when due care is taken by all road users.
126. Taking the above factors into consideration, Council has no plans to further investigate or install traffic calming devices on The Parkway.

Consultation

127. Councillor Emily Kim, Councillor for Calamvale Ward, has been consulted and does not support the recommendation.

## Customer impact

128. The submission will respond to the petitioners' concerns.
129. The A/General Manager recommended as follows and the Committee agreed at its meeting held on 20 April 2026.

## 130. DECISION:

THAT THE INFORMATION IN THIS SUBMISSION BE NOTED AND THE DRAFT RESPONSE, AS SET OUT IN ATTACHMENT A, hereunder, BE SENT TO THE HEAD PETITIONER.

## Attachment A Draft Response

Petition Reference: 137/220/594/502

Thank you for your petition requesting Council implement traffic calming devices on The Parkway, Stretton.

The installation of traffic calming devices, such as speed platforms and chicanes, may be used to discourage use from non-local traffic and to moderate vehicle speeds. However, Council only considers the installation of traffic calming devices where there is a combination of both a demonstrated widespread issue of non -local traffic using a street and where demonstrated and persistent speeding issue. Speeding issues alone are not sufficient to consider the use of traffic calming devices as speeding is predominately a driver behaviour issue under the jurisdiction of Queensland Police Service (QPS). You are encouraged to report ongoing concerns regarding speeding or hooning behaviour directly to QPS via the Hoon Hotline on 13 HOON (13 46 66).

A review of the road network indicates that The Parkway does not offer time or distance savings for through-traffic and primarily services as an enclosed residential catchment. As a result, most vehicles using The Parkway are local residents or visitors, and the street is operating as intended under Council's Brisbane City Plan 2014 road hierarchy.

In October 2025, Council undertook a traffic survey to assess traffic volumes and vehicle speeds on The Parkway with results showing an average traffic volumes of 1,583 vehicles per weekday, which is within the acceptable range for a neighbourhood road and average vehicle speeds of 40.2 km/h, indicating reasonable compliance with the 50 km/h speed limit.

Council acknowledges your concerns for pedestrian safety. The Parkway has concrete footpaths on both sides for its entire length. Combined with the observed low vehicle speeds, these features support safe pedestrian movement and road crossing when due care is taken by all road users.

Taking the above factors into consideration, Council has no plans to further investigate or install traffic calming devices on The Parkway.

The above information will be forwarded to the other petitioners via email.

Should you wish to discuss this matter further, please contact Mr Kiran Sreedharan, Senior Transport Network Officer, Transport Network Performance, Transport Assets and Operations, Infrastructure Services , on 3178 1178.

Thank you for raising this matter.

## NOTED

## K PETITION – REQUESTING COUNCIL INSTALL A TEMPORARY PEDESTRIAN CROSSING AND OTHER SAFETY MEASURES ON SYLVAN ROAD, TOOWONG 137/220/594/511

## 619/2025 -26

131. A petition requesting Council install a temporary pedestrian crossing and other safety measures on Sylvan Road, Toowong, was received during the Summer Recess 2025-26.
132. The A/General Manager, Transport Assets and Operations, Infrastructure Services, provided the following information.
133. The petition contains 40 signatures. Of the petitioners 6 live in Paddington Ward, 12 live in Walter Taylor Ward, 21 live in other wards within the City of Brisbane, and one lives outside of the City of Brisbane.
134. The Toowong intersection improvements and Sylvan Road bikeway project (the project) focuses on upgrading Sylvan Road to provide safer, separated active transport facilities and better connections to local shops, public transport, community facilities and the wider bikeway network. Attachment B (submitted on file) shows a locality map.
135. Council understands the community's desire for immediate safety improvements. However, to ensure a coordinated and effective upgrade for the entire corridor, Council is prioritising the progression of the full design rather than implementing temporary measures. Concept design for this project is currently underway, this phase incorporates community feedback provided through consultation in mid-2025 with technical assessments and relevant Australian standards. Attachment C (submitted on file) shows the community engagement update newsletter distributed in January 2026.

136. While the project planning continues, pedestrians can cross Sylvan Road using the nearby signalised crossing at Land Street, Toowong. The existing pedestrian refuge island at the intersection of Sylvan Road and Bennett Street, Toowong also provides a place to wait and let pedestrians navigate each direction of traffic separately, while still ensuring traffic flow is maintained. For accessing Toowong Village from Bennett Street, pedestrians can use stairs located near the car park entrance on the eastern side, or at the signalised intersection of Lissner and Jephson Streets, Toowong. Council advises there are no current plans to install additional pedestrian crossing facilities on Bennett Street in locations outside the scope of the project.
137. Council acknowledges the petitioners' concerns regarding pedestrian safety and community safety remains a key consideration of the project. Concept designs are expected to be shared with the community in the coming months, with further opportunities for feedback as the project progresses.

## Consultation

138. Councillor Penny Wolff, Councillor for Walter Taylor Ward, has been consulted and supports the recommendation.
139. Councillor Seal Chong Wah, Councillor for Paddington Ward, has been consulted and does not support the recommendation.

## Customer impact

140. The submission will respond to the petitioners' concerns.
141. The A/General Manager recommended as follows and the Committee agreed at its meeting held on 20 April 2026.

## 142. DECISION:

THAT THE INFORMATION IN THIS SUBMISSION BE NOTED AND THE DRAFT RESPONSE, AS SET OUT IN ATTACHMENT A, hereunder, BE SENT TO THE HEAD PETITIONER.

## Attachment A Draft Response

## Petition Reference: 137/220/594/511

Thank you for your petition requesting Council install a temporary pedestrian crossing and other safety measures on Sylvan Road, Toowong.

The Toowong intersection improvements and Sylvan Road bikeway project (the project) focuses on upgrading Sylvan Road to provide safer, separated active transport facilities and better connections to local shops, public transport, community facilities and the wider bikeway network.

Council understands the community's desire for immediate safety improvements. However, to ensure a coordinated and effective upgrade for the entire corridor, Council is prioritising the progression of the full design rather than implementing temporary measures. Concept design for this project is currently underway, this phase incorporates community feedback provided through consultation in mid-2025 with technical assessments and relevant Australian standards.

While the project planning continues, pedestrians can cross Sylvan Road using the nearby signalised crossing at Land Street, Toowong. The existing pedestrian refuge island at the intersection of at Sylvan Road and Bennett Street, Toowong also provides a place to wait and let pedestrians navigate each direction of traffic separately, while still ensuring traffic flow is maintained. For accessing Toowong Village from Bennett Street, pedestrians can use stairs located near the car park entrance on the eastern side, or cross at the signalised intersection of Lissner and Jephson Streets, Toowong. Council advises there are no current plans to install additional pedestrian crossing facilities on Bennett Street in locations outside the scope of the project.

Council acknowledges your concerns regarding pedestrian safety and community safety remains a key consideration of the project. Concept designs are expected to be shared with the community in the coming months, with further opportunities for feedback as the project progresses.

The above information will be forwarded to the other petitioners via email.

Should you wish to discuss this matter further, please contact the project team, Project Management, Infrastructure Services, by phone on 3178 5413 during business hours or email CityProjects@brisbane.qld.gov.au.

Thank you for raising this matter.

NOTED

## L PETITION – REQUESTING COUNCIL IMPROVE CROSSING FACILITIES ON ERIC CRESCENT ADJACENT TO MACKENZIE PLACE PARK, ANNERLEY 137/220/594/522

## 620/2025 -26

143. A petition requesting Council improve crossing facilities on Eric Crescent adjacent to MacKenzie Place Park, Annerley, was received during the Summer Recess 2025-26 .
144. The A/General Manager, Transport Assets and Operations, Infrastructure Services, provided the following information.
145. The petition contains 152 signatures. Of the petitioners, 92 reside within the Moorooka Ward, 57 reside in other wards within the City of Brisbane and 3 live outside the City of Brisbane.
146. Council acknowledges the petitioners' concerns about limited visibility due to parked vehicles, the absence of kerb ramps and vehicles travelling above the 50 km/h speed limit. Council also notes the petitioners' suggested treatments, including a raised wombat crossing or shared zone, to improve safety and accessibility for pedestrians crossing Sarah Street, Annerley. Attachment B (submitted on file) shows a locality map.
147. Council has reviewed the location adjacent to MacKenzie Place Park and considers the existing 50 km/h speed limit to be appropriate. At this time, the installation of a wombat crossing or shared zone is not supported. The existing pedestrian refuge crossings in the vicinity remain the preferred and recommended crossing points.
148. Council understands the concerns raised regarding driver behaviour, including speeding. While Council is responsible for road design and infrastructure, enforcement of speed limits is the responsibility of Queensland Police Service (QPS). Residents are encouraged to report hooning or dangerous driving directly to QPS.
149. Council will continue to consider feedback from local residents when assessing future improvement opportunities in the area.

## Consultation

150. Councillor Steve Griffiths, Councillor for Moorooka Ward, has been consulted and does not support the recommendation.

Customer impact

151. The submission will respond to the petitioners' concerns.
152. The A/General Manager recommended as follows and the Committee agreed at its meeting held on 20 April 2026.

## 153. DECISION:

THAT THE INFORMATION IN THIS SUBMISSION BE NOTED AND THE DRAFT RESPONSE, AS SET OUT IN ATTACHMENT A, hereunder, BE SENT TO THE HEAD PETITIONER.

## Attachment A Draft Response

## Petition Reference: 137/220/594/522

Thank you for your petition requesting Council install a wombat crossing or shared zone on Eric Crescent outside Mackenzie Place Park, Annerley.

Council acknowledges your concerns regarding limited visibility due to parked vehicles, the absence of kerb ramps and vehicles travelling above the 50 km/h speed limit. Council also notes your suggested treatments, including a raised wombat crossing or a shared zone, to improve safety and accessibility pedestrians crossing Sarah Street, Annerley.

Council has reviewed the location adjacent to MacKenzie Place Park and considers the existing 50 km/h speed limit to be appropriate. At this time, the installation of a wombat crossing or shared zone is not supported. The existing pedestrian refuge crossings in the vicinity remain the preferred and recommended crossing points.

Council understands the concerns raised regarding driver behaviour, including speeding. While Council is responsible for road design and infrastructure, enforcement of speed limits is the responsibility of Queensland Police Service (QPS). Residents are encouraged to report hooning or dangerous driving directly to QPS on 13 HOON (13 46 66).

The above information will be forwarded to the other petitioners via email.

Should you wish to discuss this matter further, please contact Mr Kiran Sreedharan, Senior Transport Network Officer, Transport Network Performance, Transport Assets and Operations, Infrastructure Services, on 3178 1178.

Thank you for raising this matter.

## NOTED

## CITY PLANNING , SUBURBAN RENEWAL AND ECONOMIC DEVELOPMENT COMMITTEE

The Chair then drew the Councillors' attention to the report setting out the decisions of the Establishment and Coordination Committee as delegate of the Council during the Autum Recess 2026, on matters usually considered by the City Planning, Suburban Renewal and Economic Development Committee.

Upon being submitted to the Chamber, the report was declared carried on the voices.

Thereupon, Councillors Jared CASSIDY and Lucy COLLIER immediately rose and called for a division, which resulted in the motion being declared carried .

The voting was as follows:

| AYES: 18  -    | The DEPUTY MAYOR, Councillor Fiona CUNNINGHAM, and Councillors  Krista ADAMS, Greg ADERMANN, Adam ALLAN, Lisa ATWOOD,  Tracy DAVIS, Julia DIXON, Alex GIVNEY, Vicki HOWARD, Steven HUANG,  Sarah HUTTON, Sandy LANDERS, Kim MARX, Ryan MURPHY, Danita PARRY,  Steven TOOMEY, Andrew WINES and Penny WOLFF.   |
|----------------|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| NOES: 8  -     | The Leader of the OPPOSITION, Councillor Jared CASSIDY, and Councillors  Lucy COLLIER, Steve GRIFFITHS, Emily KIM, Charles STRUNK,  Seal CHONG WAH, Trina MASSEY and Nicole JOHNSTON.                                                                                                                        |

The report read as follows

## A PETITION – REQUESTING COUNCIL REJECT PROPOSED DEVELOPMENTS AT 188 GRAHAM ROAD (A006638485) AND 206 GRAHAM ROAD (A006724928), BRIDGEMAN DOWNS 137/220/594/506

## 621/2025 -26

1. A petition requesting Council reject proposed developments at 188 Graham Road (A006638485) and 206 Graham Road (A006724928), Bridgeman Downs, was received during the Summer Recess 2025-26.
2. The Group Executive, City Planning and Economic Development Services, provided the following information.
3. The petition contains 10 signatures. Of the petitioners, 8 live in McDowall Ward and 2 live in other wards within the City of Brisbane.
4. The petitioners have raised concerns about the developments causing damage to the local ecosystem through the loss of greenspace and noted the development sites form a vital ecological corridor containing an array of local wildlife.
5. On 18 October 2024, development application (DA) A006638485 was received by Council for a Reconfiguration of a Lot (2 into 30 residential lots and bio-basin lot) and was properly made on 30 October 2024. On 27 November 2024, Council issued an Information Request to the applicant. The applicant provided a response to the Information Request on 10 April 2025. The proposed development required referral to the State Assessment and Referral Agency (SARA) due to the site's proximity to a State transport corridor who provided their response to Council on 10 November 2025. On 20 January 2026, Council issued a further advice letter to the applicant as additional information is required to address outstanding assessment matters. The decision period has been extended to 1 May 2026 and no decision has been made. The DA is being assessed by Council against the requirements of Brisbane City Plan 2014 (City Plan) and in accordance with the provisions of the Planning Act 2016 (the Act).
6. The proposed development site consists of 2 allotments with a combined area of approximately 23,190 m 2 . The site is included in the Low density residential zone and the Bridgeman Downs residential precinct (NPP-001) of the Bridgeman Downs neighbourhood plan as per City Plan. It is currently occupied by a single residential dwelling and ancillary buildings located close to Graham Road where vehicle and pedestrian access is obtained.
7. The southern part of the development site is also included in the Bridgeman Downs neighbourhood plan as 'Ecological and waterway values' and in the High ecological significance and High ecological significance strategic sub-categories of the Biodiversity areas overlay. This is also being assessed against City Plan, including the acceptable and performance outcomes of the Bridgeman Downs neighbourhood plan, which envisions residential development with a minimum lot size of 500 m 2 for the site, and the acceptable and performance outcomes of the Biodiversity areas overlay code.
8. The DA is subject to code assessment and does not require formal public notification or afford submitter or petitioner appeal rights to the Queensland Planning and Environment Court in accordance with the Act. However, all matters and concerns raised by submitters and petitioners are considered by Council as part of the assessment process. As the DA is currently being assessed by Council, it is inappropriate for Council to comment on what the outcome may be at this stage.
9. On 28 February 2025, DA A006724928 was received by Council for a Reconfiguration of a Lot (1 into 16 lots) and a new road, and was properly made on 14 March 2025. This development site has an area of 10,016 m 2 and is also included in the Low density residential zone and NPP-001 of the Bridgeman Downs neighbourhood plan as per City Plan. However, this site is not included in the 'Ecological and waterway values' area of the Bridgeman Downs neighbourhood plan, nor the Biodiversity areas overlay code.
10. This application was approved, subject to conditions, by Council on 15 August 2025. The DA was subject to impact assessment and underwent public notification from 15 May to 5 June 2025. A total of 2 submissions were received and considered as part of the assessment process. Under the Act, Council is unable to revert its decision on the application. While there were no City Plan requirements for the

retention of vegetation on the site, the conditions of approval include a fauna spotter catcher to manage the protection and relocation of any fauna prior to and during vegetation clearing.

## Consultation

11. Councillor Tracy Davis, Councillor for McDowall Ward, has been consulted and supports the recommendation.

## Customer impact

12. The submission will respond to the petitioners' concerns.
13. The Group Executive recommended as follows and the Committee agreed at its meeting held on 30 March 2026.

## 14. DECISION:

THAT THE INFORMATION IN THIS SUBMISSION BE NOTED AND THE DRAFT RESPONSE, AS SET OUT IN ATTACHMENT A, hereunder, BE SENT TO THE HEAD PETITIONER.

## Attachment A Draft Response

## Petition Reference: 137/220/594/506

Thank you for your petition requesting Council reject proposed developments at 188 Graham Road (A006638485) and 206 Graham Road (A006724928), Bridgeman Downs (the developments).

Your concerns about the developments causing damage to the local ecosystem through the loss of greenspace and ecological corridor is noted.

On 18 October 2024, development application (DA) A006638485 was received by Council for a Reconfiguration of a Lot (2 into 30 residential lots and bio-basin lot) and was properly made on 30 October 2024. On 11 December 2025, Council requested an extension to the decision period under section 22(1) of the Planning Act 2016 (the Act), along with further extensions on 28 January and 23 February 2026, which were agreed to by the applicant. The decision period has been extended to 1 May 2026 and no decision has been made. The DA is being assessed by Council against the requirements of Brisbane City Plan 2014 (City Plan) and in accordance with the provisions of the Act.

The proposed development site consists of 2 allotments with a combined area of approximately 23,190 m 2 . The site is included in the Low density residential zone and the Bridgeman Downs residential precinct (NPP-001) of the Bridgeman Downs neighbourhood plan as per City Plan. It is currently occupied by a single residential dwelling and ancillary buildings located close to Graham Road where vehicle and pedestrian access is obtained.

The southern part of the development site is also included in the Bridgeman Downs neighbourhood plan as 'Ecological and waterway values' and in the High ecological significance and High ecological significance strategic sub-categories of the Biodiversity areas overlay. This is also being assessed against City Plan, including the acceptable and performance outcomes of the Bridgeman Downs neighbourhood plan, which envisions residential development with a minimum lot size of 500 m 2 for the site, and the acceptable and performance outcomes of the Biodiversity areas overlay code.

The DA is subject to code assessment and does not require formal public notification or afford submitter or petitioner appeal rights to the Queensland Planning and Environment Court in accordance with the Act. However, all matters and concerns raised by submitters and petitioners are considered by Council as part of the assessment process. As the DA is currently being assessed by Council, it is inappropriate for Council to comment on what the outcome may be at this stage.

On 28 February 2025, DA A006724928 was received by Council for a Reconfiguration of a Lot (1 into 16 lots) and a new road, and was properly made on 14 March 2025. This development site has an area of 10,016 m 2 and is also included in the Low density residential zone and NPP-001 of the Bridgeman Downs neighbourhood plan as per City Plan. However, the site is not included in the 'Ecological and waterway values' area of the Bridgeman Downs neighbourhood plan, nor the Biodiversity areas overlay code.

This application was approved, subject to conditions, by Council on 15 August 2025. The DA was subject to impact assessment and underwent public notification from 15 May to 5 June 2025. A total of 2 submissions were received and considered as part of the assessment process. In accordance with the Act, Council is unable to revert its decision on the application. While there were no City Plan requirements for the retention of vegetation on the site, the conditions of approval include a fauna spotter catcher to manage the protection and relocation of any fauna prior to and during vegetation clearing.

You can view a copy of the development applications including the proposed and approved plans and documents by visiting Council's Development.i website at developmenti.brisbane.qld.gov.au by searching application references 'A006638485' and 'A006724928' respectively.

The above information will be forwarded to the other petitioners via email.

Should you wish to discuss this matter further, please contact Ms Hayley Steel, A/Team Manager, Planning Services, Development Services, City Planning and Economic Development Services, on 3178 0022.

Thank you for raising this matter.

## NOTED

## B PETITION – REQUESTING COUNCIL REJECT THE PROPOSED DEVELOPMENT AT 405 AND 407 BECKETT ROAD, BRIDGEMAN DOWNS (A006547920), AND RETAIN THE ECOLOGICAL CORRIDOR 137/220/594/507

## 622/2025 -26

15. A petition requesting Council reject the proposed development at 405 and 407 Beckett Road, Bridgeman Downs (the site) (application reference A006547920), and retain the ecological corridor, was received during the Spring Recess 2025.
16. The Group Executive, City Planning and Economic Development Services, provided the following information.
17. The petition contains 41 signatures. Of the petitioners, 37 live in McDowall Ward and 4 live in other wards within the City of Brisbane.
18. The petitioners have raised the following concerns about the development application:
5. -the site forms a vital ecological corridor containing an array of local wildlife
6. -damage to the local ecosystem and loss of greenspace.
19. The site has a total area of 13,029 m 2 and is included in the Low density residential zone and Bridgeman Downs neighbourhood plan within Brisbane City Plan 2014 (City Plan). The site previously contained a single dwelling fronting Beckett Road. The majority of the site is not included within City Plan or Queensland Government overlays relating to ecological values or natural habitat.
20. A narrow area along the northern boundary of 407 Beckett Road is included within the following relevant City Plan and Queensland Government overlays:
9. -City Plan overlay: Biodiversity areas overlay – Matters of State Environmental Significance (MSES)
10. -Queensland Government overlay: Koala habitat area – Core koala habitat area.
21. On 13 June 2024, a development application for Reconfiguring a Lot (2 into 21 and new road) and Preliminary Approval for Operational work (Filling and excavation) was received by Council. The development application was properly made on 19 June 2024. Council approved the development application on 12 December 2024, after assessment against the provisions of City Plan and in accordance with the provisions of the Planning Act 2016 (the Act). Under the Act, Council is unable to rescind this development approval.

22. The responsibility for managing MSES and Core koala habitat areas rests with the Queensland Government, and Council does not have jurisdiction over these matters. The development application did not require referral to the State Assessment and Referral Agency (SARA) as proposed tree removal was either not within the relevant overlays or met relevant exemptions under the Planning Regulation 2017 .
23. In achieving compliance with City Plan, it was determined that the development would not result in significant adverse impacts to identified biodiversity values, ecological features or natural habitat. The site was generally clear of vegetation and the development will retain existing trees on adjoining land included under the Biodiversity areas overlay.
24. The development application was subject to code assessment which did not require formal public notification; and did not afford submitter/petitioner appeal rights to the Queensland Planning and Environment Court in accordance with the Act.
25. A copy of the development application and Council's decision, including conditions, can be located online via Council's Development.i website at developmenti.brisbane.qld.gov.au by searching application reference 'A006547920'.

## Consultation

26. Councillor Tracy Davis, Councillor for McDowall Ward, has been consulted and supports the recommendation.

## Customer impact

27. The submission will respond to the petitioners' concerns.
28. The Group Executive recommended as follows and the Committee agreed at its meeting held on 30 March 2026.

## 29. DECISION:

THAT THE INFORMATION IN THIS SUBMISSION BE NOTED AND THE DRAFT RESPONSE, AS SET OUT IN ATTACHMENT A, hereunder, BE SENT TO THE HEAD PETITIONER.

## Attachment A Draft Response

## Petition Reference: 137/220/594/507

Thank you for your petition requesting Council reject the proposed development at 405 and 407 Beckett Road, Bridgeman Downs (the site) (application reference A006547920), and retain the ecological corridor.

Council notes the concerns you have raised about:

- -the site forming a vital ecological corridor containing an array of local wildlife.
- -damage to the local ecosystem and loss of greenspace.

The site has a total area of 13,029 m 2 and is included in the Low density residential zone and the Bridgeman Downs neighbourhood plan within Brisbane City Plan 2014 (City Plan). The site previously contained a single dwelling fronting Beckett Road. The majority of the site is not included within City Plan or Queensland Government overlays relating to ecological values or natural habitat.

A narrow area along the northern boundary of 407 Beckett Road is included within the following relevant City Plan and Queensland Government overlays:

- -City Plan overlay: Biodiversity areas overlay – Matters of State Environmental Significance (MSES)
- -Queensland Government overlay: Koala habitat area – Core koala habitat area.

On 13 June 2024, a development application for Reconfiguring a Lot (2 into 21 and new road) and Preliminary Approval for Operational work (Filling and excavation) was received by Council. The development application was properly made on 19 June 2024. Council approved the development application on 12 December 2024, after assessment against the provisions of City Plan and in accordance with the provisions of the Planning Act 2016 (the Act). Under the Act, Council is unable to rescind this development approval.

The responsibility for managing MSES and Core koala habitat areas rests with the Queensland Government and Council does not have jurisdiction over these matters. The development application did not require referral to the State Assessment and Referral Agency (SARA) as proposed tree removal was either not within the relevant overlays or met relevant exemptions under the Planning Regulation 2017 .

In achieving compliance with City Plan, it was determined that the development would not result in significant adverse impacts to identified biodiversity values, ecological features or natural habitat. The site was generally clear of vegetation and the development will retain existing trees on adjoining land mapped under the Biodiversity areas overlay.

The development application was subject to code assessment which did not require formal public notification and did not afford submitter/petitioner appeal rights to the Queensland Planning and Environment Court in accordance with the Act.

You can view a copy of the development application and Council's decision, including conditions, online via Council's Development.i website at developmenti.brisbane.qld.gov.au by searching using application reference 'A006547920'.

The above information will be forwarded to the other petitioners via email.

Should you wish to discuss this matter further, please contact Mr Ben Clothier, A/Team Manager, Planning Services, Development Services, City Planning and Economic Development Services, on 3403 7185.

Thank you for raising this matter.

## NOTED

## ENVIRONMENT, PARKS AND SUSTAINABILITY COMMITTEE

The Chair then drew the Councillors' attention to the report setting out the decisions of the Establishment and Coordination Committee as delegate of Council during the Autumn Recess 2026, on matters usually considered by the Environment, Parks and Sustainability Committee.

Upon being submitted to the Chamber, the report was declared carried on the voices.

The report read as follows

- A PETITION – REQUESTING COUNCIL ESTABLISH A PLAQUE OR SIGN TO FORMALLY RECOGNISE PATRICIA LESINA FOR HER WORK TO MAINTAIN LAND ADJACENT TO STABLE SWAMP CREEK, SUNNYBANK HILLS 137/220/594/488

## 623/2025 -26

1. A petition requesting Council establish a plaque or sign to formally recognise Patricia Lesina for her work to maintain land adjacent to Stable Swamp Creek, Sunnybank Hills, was presented to the meeting of Council held on 11 November 2025, by Councillor Kim Marx, and received.
2. The Group Executive, Environment, Parks and Sustainability Services, provided the following information.
3. The petition contains 9 signatures. Of the petitioners, 6 live in Runcorn Ward, 2 work in Runcorn Ward, and one lives in Holland Park Ward.
4. This section of Stable Swamp Creek runs north-south through Lang Street East Park (D2294, B -RE -2922) (the park) which is classified as a local corridor park for access / recreation. The park is irregular in shape defined by the waterway and the residential properties that border it. Attachment B (submitted on file) shows a locality map.

5. Council values and recognises the people who contribute to their local neighbourhoods and communities and receives numerous requests for tributes dedicated to these individuals. As parks and public spaces serve many purposes and provide significant community benefits, careful consideration is given to ensure new tributes enhance these places.
6. A passionate gardener, Patrcia has extended her garden into the Garro and Lang Street road reserves of her corner block, and into elevated sections of the waterway at the rear of her property adjacent to the park.
7. While Council appreciates Patricia's efforts to landscape the verges and creek area, it receives numerous requests for plaques and tributes in parks and public spaces. To manage these consistently and to maintain public areas for the benefit of the community, Council must apply its established policies and ensure compliance with regulations. While gardens in road reserves are supported under Council's Verge Garden Guidelines, the installation of plaques, signs or other structures within verge gardens is not permitted. For these reasons, Council does not support a plaque or sign in any part of the park.
8. Alternative ways to celebrate Patricia's contribution on local platforms, such as sharing her story through Sunnybank Hills Stories, the Rotary Club of Sunnybank Hills or the Sunnybank Probus Gardening Club should be considered, and may also inspire others in the community.

## Consultation

9. Councillor Kim Marx, Councillor for Runcorn Ward, has been consulted and supports the recommendation.

## Customer impact

10. The submission will respond to the petitioners' request.
11. The Group Executive recommended as follows and the Committee agreed at its meeting held on 30 March 2026.

## 12. DECISION:

THAT THE INFORMATION IN THIS SUBMISSION BE NOTED AND THE DRAFT RESPONSE, AS SET OUT IN ATTACHMENT A, hereunder, BE SENT TO THE HEAD PETITIONER.

## Attachment A Draft Response

## Petition Reference: 137/220/594/488

Thank you for your petition requesting recognise Patricia Lesina through a plaque or sign to recognise her contribution to maintaining a parcel of land along Stable Swamp Creek, Sunnybank Hills.

Brisbane City Council greatly values residents who care for their local environment and Mrs Lesina's dedication to her garden and the adjoining Council land has brought enjoyment to many and helped maintain the beauty of the area.

While Council appreciates Mrs Lesina's efforts to landscape the verges and creek area, it receives numerous requests for plaques and tributes in parks and public spaces. To manage these consistently and to maintain public areas for the benefit of the community, Council must apply its established policies and ensure compliance with regulations. While gardens in road reserves are supported under Council's 'Verge Garden Guidelines', the installation of plaques, signs or other structures within verge gardens is not permitted. For these reasons, Council does not support a plaque or sign in any part of Lang Street East Park.

To recognise Mrs Lesina's long-standing contribution to the Sunnybank Hills community we encourage alternative ways to celebrate Patricia, such as sharing her story through local platforms like Sunnybank Hills Stories, the Rotary Club of Sunnybank Hills, or the Sunnybank Probus Gardening Club, which may also inspire others in her community.

Thank you again for your thoughtful request and for recognising the positive impact Patricia has had on the neighbourhood.

Should you wish to discuss this matter further, please contact Tania Metcher, Program Officer, Parks Policy and Planning, Natural Environment, Water and Sustainability, Environment, Parks and Sustainability Services on 3178 2278.

Thank you for raising this matter.

## NOTED

## B PETITION – REQUESTING COUNCIL PROMOTE YOUTH CULTURE BY EXPANDING THE SKATE PARK WITHIN WALLY TATE PARK, KURABY 137/220/594/518

## 624/2025 -26

13. A petition requesting Council promote youth culture by expanding the skate park within Wally Tate Park (the park), Kuraby, was received during the Summer Recess 2025-26.
14. The Group Executive, Environment, Parks and Sustainability Services, provided the following information.
15. The petition contains 6 signatures. Of the petitioners, one lives in Runcorn Ward and 5 live in other wards in the City of Brisbane.
16. Along with the skate park, the park features:
5. -a basketball halffcourt
6. -pathways
7. -public toilets
8. -a car park
9. -picnic facilities
10. -fitness station
11. -community and sporting leased facilities.
17. The park's proximity to Kuraby railway station makes it well suited to provide active recreation for young people from surrounding areas. Council has hosted school holiday events for youth at the skate park such as 'learn to freestyle scooter,' which was well received by the community.
18. The Queensland Government's Department of Transport and Main Roads is currently undertaking the Kuraby station precinct and level crossing upgrade (the project) as part of the Logan and Gold Coast Faster Rail project. The project will see upgrades to the level crossing on Beenleigh Road which will impact the park.
19. Council has provided input to the project to ensure that facilities at the park, including the skate park, remain safe and functional throughout the project. No improvements to the skate park will be completed during the project, however, Council will seek improved outcomes for youth facilities at the park as part of the project upgrades.

## Consultation

20. Councillor Kim Marx, Councillor for Runcorn Ward, has been consulted and supports the recommendation.

## Customer impact

21. The submission will respond to the petitioners' concerns.
22. The Group Executive recommended as follows and the Committee agreed at its meeting held on 30 March 2026.

## 23. DECISION:

THAT THE INFORMATION IN THIS SUBMISSION BE NOTED AND THE DRAFT RESPONSE, AS SET OUT IN ATTACHMENT A, hereunder, BE SENT TO THE HEAD PETITIONER.

## Attachment A Draft Response

## Petition Reference: 137/220/594/518

Thank you for your petition requesting Council promote youth culture by expanding the skate park within Wally Tate Park (the park), Kuraby.

Council acknowledges the role facilities like the skate park play in promoting active and healthy lifestyles amongst young people. The park's proximity to Kuraby railway station is well suited to provide active recreation for young people from surrounding areas. Council has hosted school holiday events for youth at the skate park during school holidays such as 'learn to freestyle scooter,' which was well received by the community.

The Queensland Government's Department of Transport and Main Roads (TMR) is currently undertaking the Kuraby station precinct and level crossing upgrade (the project) as part of the Logan and Gold Coast Faster Rail project. The project will see upgrades to the level crossing on Beenleigh Road which will impact the park. For further details about the project and to register for updates please visit the TMR website at tmr.qld.gov.au and search for 'Logan and Gold Coast faster rail'.

Council has provided input to the project to ensure that facilities at the park, including the skate park, remain safe and functional throughout the project. No improvements to the skate park will be completed during the project. However, Council will seek improved outcomes for youth facilities at the park as part of the project upgrades.

The above information will be forwarded to the other petitioners via email.

Should you wish to discuss this matter further, please contact Ms Helen Favelle, Senior Program Officer, Parks Policy and Planning, Natural Environment, Water and Sustainability, Environment, Parks and Sustainability Services, on 3403 4678.

Thank you for raising this matter.

## CUSTOMER SERVICES COMMITTEE

The Chair then drew the Councillors' attention to the report setting out the decisions of the Establishment and Coordination Committee as delegate of Council during the Autumn Recess 2026, on matters usually coming under the jurisdiction of the Customer Services Committee.

Upon being submitted to the Chamber, the report was declared carried on the voices.

The report read as follows

- A PETITION – REQUESTING COUNCIL INVESTIGATE ALLEGED UNLAWFUL BUSINESS ACTIVITY AND PUBLIC NUISANCE AT 54 WEAVER STREET, COOPERS PLAINS 137/220/594/512

625/2025 -26

1. A petition requesting Council investigate alleged unlawful business activity and public nuisance at 54 Weaver Street, Coopers Plains (the site), was received during the Summer Recess 2025-26.
2. The Group Executive, Customer Services, provided the following information.
3. The petition contains 13 signatures. All petitioners live in Moorooka Ward.

<!-- image -->

Based on the original image and the provided crops, here is a description:

The image displays the single word "**NOTED**" in a bold, black, sans-serif, uppercase font against a light, possibly white or grey, background. The entire image is low-resolution and appears blurry or out of focus.

There are no project names, budget figures, locations, specific procurement indicators, or council decisions visible in the image. The word "NOTED" itself is often used in official documents, such as council meeting minutes, to indicate that a report or piece of information has been formally acknowledged by the members, but it does not represent a specific project or decision on its own.

4. The site is located within a General industry B zone (the zone) under Brisbane City Plan 2014 (City Plan) . The zone allows non -industrial activities, and business uses that support industrial activities. The petitioners have raised concerns about the site allegedly being used as an unauthorised restaurant and café, with associated food trucks attracting large crowds and causing noise, traffic, littering and public nuisance.
5. Between July 2024 and November 2025, Council received 28 complaints regarding:
3. -home business operations and alleged unlawful use
4. -food premises and unsafe food practices
5. -overflowing bins
6. -illegal parking.
6. In September and October 2024, Council conducted inspections at the site and observed catering vans and food outlets operating from the site. Enforcement action was initiated, which included education on the laws relating to home businesses, food safety and parking. Subsequently, Show Cause Notices were issued under the Planning Act 2016 .
7. In November 2024, a Material Change of Use development application (application reference A00666305) was lodged for a food and drink outlet and caretakers' accommodation at the site. The application was approved on 28 May 2025, permitting the use of the premises as a food and drink outlet.
8. The site and surrounding area have been in an Industry or future industry zone for several decades. Development applications in this zone are assessed in accordance with the relevant assessment benchmark, being the Industry code. City Plan recognises that industry areas play an important role in supporting the local economy and ensures that food and drink outlets can continue to serve the workforce while supporting the broader economic purpose of the precinct. It is acknowledged that the existing detached houses in the immediate vicinity of this site have historically been in an Industry zone. As the zone is intended for industry and related uses, the Industry code does not require specific restrictions on hours of operation and noise, where located more than 250 metres from a sensitive residential zone. The detached houses are not located in a sensitive zone, being with the General industry B zone and, as such, noise -limiting conditions and hours of operation for the use was not required to be included in the approval.
9. In November 2025, food safety concerns identified during inspections at the site were addressed directly with vendors and audits identified minor non -compliances. These issues were rectified at the time of inspection and did not warrant enforcement action. In January 2026, one food business at the site permanently ceased operations.
10. Council referred the sale of betel nut to Queensland Health, and community safety concerns to Queensland Police Service (QPS). Council has been advised by these agencies that inspections were undertaken and compliance measures within their jurisdiction were implemented.
11. Complaints regarding waste management, food safety and illegal parking should be reported to Council's 24 -hour Contact Centre on 3403 8888. Consistent reporting assists in identifying complaint patterns and supports compliance action where appropriate. Behavioural issues such as noise disturbances or activities impacting public order are under the jurisdiction of QPS. Residents are encouraged to raise any behavioural concerns directly with QPS via Policelink on 131 444.

## Consultation

12. Councillor Steve Griffiths, Councillor for Moorooka Ward, has been consulted and supports the recommendation.

## Customer impact

13. The submission will respond to the petitioners' concerns.
14. The Group Executive recommended as follows and the Committee agreed at its meeting held on 23 March 2026.

## 15. DECISION:

THAT THE INFORMATION IN THIS SUBMISSION BE NOTED AND THE DRAFT RESPONSE, AS SET OUT IN ATTACHMENT A, hereunder, BE SENT TO THE HEAD PETITIONER.

## Attachment A Draft Response

## Petition Reference: 137/220/594/512

Thank you for your petition requesting Council investigate alleged unlawful business activity and public nuisance at 54 Weaver Street, Coopers Plains (the site) .

The site is located within a General industry B zone (the zone) under Brisbane City Plan 2014 (City Plan) . The zone allows non -industrial activities and business uses that support industrial activities. Council notes you have raised concerns about the site being used as an alleged unauthorised restaurant and café, with associated food trucks attracting large crowds and causing noise, traffic, littering and public nuisance.

Between July 2024 and November 2025, Council received 28 complaints regarding:

- -home business operations and alleged unlawful use
- -food premises and unsafe food practices
- -overflowing bins
- -illegal parking.

In September and October 2024, Council conducted inspections at the site and observed catering vans and food outlets operating from the site. Enforcement action was initiated, which included education on the laws relating to home businesses, food safety and parking. Subsequently, Show Cause Notices were issued under the Planning Act 2016 .

In November 2024, a Material Change of Use development application (application reference A00666305) was lodged for a food and drink outlet and caretakers' accommodation at the site. The application was approved on 28 May 2025, permitting the use of the premises as a food and drink outlet.

The site and surrounding area have been in an Industry or future industry zone for several decades. Development applications in this zone are assessed in accordance with the relevant assessment benchmark, being the Industry code. City Plan recognises that industry areas play an important role in supporting the local economy and ensures that food and drink outlets can continue to serve the workforce while supporting the broader economic purpose of the precinct. It is acknowledged that the existing detached houses in the immediate vicinity of this site have historically been in an Industry zone. As the zone is intended for industry and related uses, the Industry code does not require specific restrictions on hours of operation and noise, where located more than 250 metres from a sensitive residential zone. The detached houses are not located in a sensitive zone, being with the General industry B zone and, as such, noise -limiting conditions and hours of operation for the use was not required to be included in the approval.

In November 2025, food safety concerns identified during inspections at the site were addressed directly with vendors and audits identified minor non -compliances. These issues were rectified at the time of inspection and did not warrant enforcement action. In January 2026, one food business at the site permanently ceased operations.

Council referred the sale of betel nut to Queensland Health, and community safety concerns to Queensland Police Service (QPS). Council has been advised by these agencies that inspections were undertaken and compliance measures within their jurisdiction were implemented.

Complaints regarding waste management, food safety and illegal parking should be reported to Council's 24 -hour Contact Centre on 3403 8888. Consistent reporting assists in identifying complaint patterns and supports compliance action where appropriate. Behavioural issues such as noise disturbances or activities impacting public order are under the jurisdiction of QPS. Residents are encouraged to raise any behavioural concerns directly with QPS via Policelink on 131 444.

Please let the other petitioners know of this information.

Should you wish to discuss this matter further, please contact Dave Armanelli, A/Business Manager Built Environment, Community Standards, Health and Biosecurity, Compliance and Regulatory Services, Customer Services, on 3407 0184.

Thank you for raising this matter.

## PRESENTATION OF PETITIONS

Chair:

Councillors, are there any petitions?

Councillor COLLIER.

Councillor COLLIER:

Chair, I have a petition on behalf of residents requesting that Council upgrade the skate park at Perth Street Park, Camp Hill.

Chair:

Councillor WINES.

Councillor WINES:

Madam Chair, I have a petition from a range of residents from across the city calling for an enforcement fine to be created for e-scooters.

Chair:

Councillor DIXON, may I have a motion for receipt of the petitions?

626/2025 -26

It was resolved on the motion of Councillor Julia DIXON, seconded by Councillor Lucy COLLIER, that the petitions as presented be received and referred to the Committee concerned for consideration and report.

The petitions were summarised as follows:

| File No.        | Councillor    | Topic                                                                       |
|-----------------|---------------|-----------------------------------------------------------------------------|
| 137/220/594/559 | Lucy Collier  | Requesting Council upgrade the skate park in Perth Street Park,  Camp Hill. |
| 137/220/594/561 | Andrew Wines  | Requesting Council enforce penalties for misparked e-mobility  devices.     |

## GENERAL BUSINESS

Chair:

Councillors, are there any statements required as a result of an Office of the Independent an Assessor or Councillor Ethics Committee order?

Councillors, we’ll now move to General Business. Are there any speakers?

Councillor MARX.

Councillor MARX:

Yes, thank you, Madam Chair. I rise to speak very briefly on a day of the weekend that was held very special to probably more than half of the Councillors here in this room and that was Mother’s Day. Unfortunately, I no longer have my mother or mother - in - law with me —

Councillor JOHNSTON:

Point of order.

Councillor MARX:

—b —but I was able to spend a Saturday—

Chair:

Sorry, one moment please, Councillor MARX.

Point of order, Councillor JOHNSTON.

Councillor JOHNSTON:

Look, mothers are universal. We all have them —

Chair:

No, no, no, no, no.

Councillor JOHNSTON:

— even if we are not mothers. It is offensive that apparently only half of us—

Chair:

Councillor, I’m sorry, it is not your General Business.

NOTED

| Councillor JOHNSTON:      | — care about Mother’s Day.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      |
|---------------------------|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Chair:                    | You do not debate someone else’s General Business.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              |
| Councillor JOHNSTON:      | I would like it to be withdrawn.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                |
| Chair:                    | Absolutely not. It is not your General Business.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                |
| Councillor interjecting.  |                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 |
| Chair:                    | No, Councillor, I do not uphold that point of order. It is totally, totally  inappropriate for you to get up and do that to another Councillor for their General  Business.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     |
| Councillor interjecting.  |                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 |
| Chair:                    | What you are doing now is what is offensive.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    |
| Councillor interjecting.  |                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 |
| Chair:                    | This is offensive.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              |
| Councillor interjecting.  |                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 |
| Chair:                    | Totally inappropriate, Councillor, to do that to another Councillor during their GB.  I have no doubt we’re about to hear from other Councillors where people may not  like what they’re saying in their GB, but you do not do that.                                                                                                                                                                                                                                                                                                                                                                                                                            |
| Councillors interjecting. |                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 |
| Chair:                    | Excuse me, Councillor MASSEY, do not put words in my mouth either.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              |
| Councillor interjecting.  |                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 |
| Chair:                    | That is totally disingenuous and inappropriate.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 |
| Councillor MASSEY:        | Point of order, Chair.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          |
| Chair:                    | Point of order, Councillor MASSEY.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              |
| Councillor MASSEY:        | I just wanted to clarify, I didn’t say that you said that, but that’s what was said.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            |
| Chair:                    | Councillor MASSEY, I heard what you said. Now, resume some—                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     |
| Councillor COLLIER:       | Point of order.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 |
| Chair:                    | — form of— f—                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   |
|                           | I’m speaking, Councillor COLLIER. Please be seated till I’m finished.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           |
|                           | I do expect better behaviour from Councillors in this Chamber and that is what  I’m trying to achieve. I ask that you all have some decorum, respect another  Councillor when they’re on their feet, which is what I try to achieve the whole  meeting. When a Councillor is speaking, you do not interrupt them. You let them  speak in General Business on their GB. If you don’t agree with what they’re  saying, you have the absolute opportunity to then get up and do a General  Business. That’s how it works. You don’t get up and throw barbs and criticise  people for what they’re talking about and the Councillor hasn’t even finished  speaking. |
|                           | Councillor MARX.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                |
| Councillor COLLIER:       | Point of order.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 |
| Chair:                    | Point of order, Councillor COLLIER.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             |
| Councillor COLLIER:       | I claim to be misrepresented.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   |
| Chair:                    | Have you spoken yet and someone—                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                |
| Councillor interjecting . |                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 |
| Chair:                    | No, your misrepresentation would be something that either Councillor  JOHNSTON or Councillor MARX just said about something you said today. That  is a misrep, okay?                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            |

Councillor JOHNSTON:

Point of order.

Councillor MARX:

Madam Chair, I refuse to speak any further in this Chamber on this matter.

Chair:

Thank you.

Councillor JOHNSTON:

Point of order.

Chair:

Point of order, Councillor JOHNSTON.

627/2025 -26

It was moved by Councillor Nicole JOHNSTON, seconded by Councillor Trina MASSEY, that the Chair is engaging in unsuitable meeting conduct.

At that time, 5.34pm, the Chair retired from the meeting room and associated public places for the duration of the debate. The Deputy Chair presided at the meeting .

Deputy Chair:

Councillor JOHNSTON:

Councillor JOHNSTON.

Yes, look I rise to speak on the inconsistent and unfair and biased, obviously biased, ruling of the Chair, Councillor Sandy LANDERS, yet again today. I don't know what is going on, but this has been an appallingly managed meeting by Councillor LANDERS. Now, I'm drawing to the attention of everybody who's watching, when I spoke immediately before Councillor MARX, Councillor HOWARD got up, interrupted me, did not make a proper point of order, simply debated something that I was saying, insisted that I withdraw it because she was offended and Councillor LANDERS allowed her to do that, asked me to withdraw it, even though I had not said anything unreasonable, offensive, unfair. I just mentioned perhaps Councillor HOWARD might retire one day .

I then responded by saying, fine, I'll withdraw. Councillor HOWARD will rule forever in Central Ward. Councillor HOWARD started shouting, clapping, as did all the other LNP Councillors. Again, interjecting, interrupting the meeting, disrupting the meeting, which Councillor LANDERS has been picking on Labor and Opposition Councillors all day, when they even mumble under their breath. When it is done in an obvious, loud, disruptive way by the LNP, that is no problem, none.

Now, I rose on a valid point of order, because Councillor MARX, I don't know why, said on a matter of importance to half the Chamber. Now, I don't know what she was talking about, whether she meant just the mothers in the room or whatever. I don't know. But all of us have mothers, all of us care about Mother's Day and I don't think there's a single person in this room that doesn't. I think she probably just misspoke, I don't know. I simply asked her to withdraw. Councillor LANDERS then goes off the deep end, don't interrupt anybody, you can't interrupt anybody. But that's exactly what Councillor HOWARD had done and that was perfectly okay.

I am sick and tired of Councillor LANDERS' incompetent, biased and outrageous chairing of the meeting and today has been the worst in the 2 years that she has been the Chair. I do not know what she is thinking because her behaviour is under scrutiny in a big way by an independent body, the Supreme Court of Queensland. There is no way—no way—that this kind of action by Councillor LANDERS today, whether it's against Councillor GRIFFITHS—I mean, Councillor LANDERS made a ruling about a Councillor who hadn't done anything wrong and Councillor CASSIDY raised that.

But you cannot say it's perfectly okay for a Councillor, like Councillor HOWARD, to stand up and say she didn't like I mentioned she might retire—that was it, it wasn't a point of order, a procedural point of order, she did not like what I said— d— and then allow her to disrupt the meeting as she did. Right? Then to go off the deep end at me for simply making an it's-not-appropriate comment about Councillor MARX and like I'd done something wrong, is madness. Madness. Within 4 minutes, Councillor LANDERS had shown on the record in black and white how incompetent and how biased she is and how deliberate her behaviour has been in this Chamber today. It is unsuitable meeting conduct.

|                          | She is required to act fairly and justly and in accordance with the rules and is  failing to do so by giving the LNP a free pass on everything and nitpicking on  Opposition Councillors every single meeting and particularly today. It is  outrageous, wrong and it is unsuitable meeting conduct.                                                                                                                                                                                                                                                                                                                                                                                                                                 |
|--------------------------|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Deputy Chair:            | Further speaker?                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     |
|                          | Councillor DAVIS.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    |
| Councillor DAVIS:        | Thank you very much, Deputy Chair and once again, I rise to speak in defence of  our Chair of Council, Councillor LANDERS, who has a very difficult job. Across  the Chamber, seems to enjoy nothing more than putting forward these motions  each and every week, just so that they can have something to say, because quite  frankly, they have not got much else to say in this Chamber. They waste time, they  do not deal with the matters that this Chamber is meant to deal with on a Tuesday.  To hear Councillor JOHNSTON carry on—I don’t think she hears herself in what  she says in this Chamber. Coming in here and listening to the diatribe that comes  from across the Chamber is an embarrassment to this Chamber. |
|                          | I have no idea why those opposite do not want to deal with the matters that are put  in front us, the things that matter to the people of Brisbane. This is nothing more  than grandstanding, for the sake of grandstanding, while bullying and putting  down our Chair of Council, who has a very difficult job dealing with teenagers  across the Chamber. It is absolutely unfortunate that we have to come in week in  and week out and listen to this ridiculous behaviour by across the Chamber and  Deputy Chair—                                                                                                                                                                                                             |
| Councillor COLLIER:      | Point of order, Chair.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               |
|                          | Yes, point of order.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 |
| Councillor COLLIER:      | Chair, saying that people—inferring that people are teenagers and that’s insulting  is actually quite offensive to teenagers.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        |
| Deputy Chair:            | Sorry, that’s not for you to debate.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 |
| Councillor COLLIER:      | No, no, I take personal offence and I ask Councillor DAVIS to withdraw those  comments.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              |
| Councillor DAVIS:        | Deputy Chair, I withdraw saying teenagers. They act like teenagers.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  |
| Councillor interjecting. |                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      |

## PROCEDURAL MOTION – MOTION BE NOW PUT

628/2025 -26

It was moved by Councillor Tracy DAVIS, seconded by Councillor Julia DIXON, that the motion be now put.

Upon being submitted to the Chamber, the procedural motion was declared carried on the voices.

Deputy Chair:

Councillor JOHNSTON, right of reply.

Councillor JOHNSTON:

We’ve got to a point in this Chamber where it is completely dysfunctional and that tone has been set by the Chair, Councillor Sandy LANDERS, who, in the course of 2 years, has not improved her chairmanship. If anything, it is getting worse. The person who is nitpicking and bullying is Councillor LANDERS. She is calling out Opposition Councillors for doing nothing, while allowing LNP Councillors, who do far worse, a free ride; that is not acceptable. That is not acceptable. That’s what’s been going on here.

This Council is now in a mess, which the CEO has to clean up and it will cost Council a lot of money because the Chair of Council does not have the ability to manage the room, manage the rules in a fair, just and reasonable way. Because no one can sit back and say what Councillor HOWARD did, interrupting me, not making a proper point of order, claiming to be outraged, jumping up and down and interjecting afterwards, that all of that’s perfectly fine and if Councillor—if the Councillors, CASSIDY and— d— oh my God—COLLIER, are basically talking to each other, they’re in trouble for shouting across the room.

No one, no one with a brain can watch that and go, well that's okay. It's not. It's not okay for Councillor LANDERS to say it's perfectly fine for Councillor HOWARD or Councillor Adam ALLAN earlier today, who wasn't talking about what was in the report for the whole 4 minutes, pretty much, talking about Labor Federal Members because it was politically fun for him and then to see the browbeating of Councillor KIM. This is madness.

It's going to be scrutinised. It is not reasonable and the person who must and should change the way that they are professionally—well, not professionally, in my view—running this meeting, is Councillor LANDERS. She is not acting in accordance with her commitments under the Code of Conduct. She is not acting fairly. She is not acting justly. She is not acting reasonably and it is not okay to allow Councillors like Councillor HOWARD to interject and jump up and down, or Councillor KIM, who says only half the Chamber cares about Mother's Day. Honestly, who would even try and say something like that? All of us care about Mother's Day, but to go off the deep end at me for simply raising it, is just—it's nuts. It's nuts. I did nothing wrong other than stand up and speak.

It is my presence and the presence of Labor Councillors that offends Councillor LANDERS. She's deliberately doing this. It's like Councillor ADAMS when she used to be told by Councillor Quirk, 'it's time to kick them out, it's time to get rid of her.' This is deliberate, it is organised and when Councillor DAVIS stands up and says this is because we don't want to deal with the matters that are on the agenda, we can't, because you changed the rules last year. The LNP changed the rules last year to restrict debate to 3 hours—3 hours for the whole meeting for debate — limit us to 5 minutes, so the reason we can't talk about local issues is because you changed the rules to stop us, because you can't handle anybody disagreeing with you.

Not only that, when we raise local motions of importance to us, you block them, you table them and you leave them on the agenda for 12 months or more. That's what you do. So when you say we don't want to deal with local issues, oh yes, we do. But you changed the rules, you voted for it, you block the local motions every single time. So, please, don't stand up here holier-than-thou and say this is about us not wanting to talk about the issues, because we do and I do clearly. You changed the rules, so we can't. We can't and that is what you did, Councillor DAVIS, with your LNP majority that are, in Councillor HOWARD's words, born to rule, not going to leave, going to do whatever they're going to do—

Councillor interjecting.

Councillor JOHNSTON:

— and that is rule, yes and that is it.

Councillor interjecting.

Councillor JOHNSTON:

So yes, not serve, rule. Rule.

Councillor interjecting.

Councillor JOHNSTON:

So, the problem in this Chamber is Councillor LANDERS, and it just can’t—

Deputy Chair:

Councillor JOHNSTON, your time has expired.

I now put the motion to the vote.

Upon being submitted to the Chamber, the motion was declared lost on the voices.

Thereupon, Councillors Nicole JOHNSTON and Trina MASSEY immediately rose and called for a division, which resulted in the motion being declared lost .

The voting was as follows:

| AYES: 8  -    | The Leader of the OPPOSITION, Councillor Jared CASSIDY, and Councillors  Lucy COLLIER, Steve GRIFFITHS, Emily KIM, Charles STRUNK,  Seal CHONG WAH, Trina MASSEY and Nicole JOHNSTON.   |
|---------------|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| NOES: 16  -   | The DEPUTY MAYOR, Councillor Fiona CUNNINGHAM, and Councillors  Krista ADAMS, Greg ADERMANN, Adam ALLAN, Lisa ATWOOD,                                                                   |

Deputy Chair:

Tracy DAVIS, Julia DIXON, Vicki HOWARD, Steven HUANG, Sarah HUTTON, Kim MARX, Ryan MURPHY, Danita PARRY, Steven TOOMEY, Andrew WINES and Penny WOLFF.

Can someone please advise the Chair to come back to the Chamber?

Madam Chair, the Chamber has decided that you have not engaged in unsuitable meeting conduct, please come back to the Chair.

At that time, 5.47pm, the Chair presided at the meeting .

Chair:

Councillor COLLIER:

Further speakers on General Business?

Councillor COLLIER.

Thanks, Chair. I have 3 items of General Business to talk about today. Firstly, Mullens Street and Riding Road intersection. Secondly, Maternal Mental Health Day, Bereaved Mother's Day and Mother's Day. Thirdly, just reflections on this place. So, firstly, I just wanted to raise awareness, I guess, and attention of this Council and, in particular, Councillor MURPHY. This is a longstanding community issue affecting residents who live at the intersection of Mullens Street and Riding Road and it is a very popular area, close by to a local school. It's an emerging medical precinct as well, there's a number of doctors in the area and of course there's just growth in the community.

Council have, in the past, looked at options to improve this intersection and it was a bit of back and forth, it was during COVID, some options were supported by local residents, others weren't. But what has become clear in more recent times is that this is becoming a more frequented intersection and therefore the instances of crashes and danger are increasing. So residents have asked me to come to this place today and raise awareness about this intersection.

I have gotten my colleague, Councillor STRUNK, to ask a Question on Notice in the Infrastructure Committee today. I have logged it with Council officers. I've looked back through all of the history and we just would love to hear what the options are to fix it. The first option that the residents would love to see actioned is, of course, an extension of yellow lines either side to improve sight and visibility. That would be their preferred option. I haven't done community consultation, because I'd love to understand what Council would like to do to improve the safety in this community. So I wanted to put the residents' concerns on the record in this place here today and hopefully we can work to find a solution.

Secondly, I just want to make some remarks on a few things that have happened over the last couple of weeks, including Maternal Mental Health Day, which was a couple of weeks ago. This is an incredibly important day to raise awareness about the impacts that being a mum or trying to become a mum or mothering in general can impact on your mental health, whether that is through the physiological shifts that happen to your body, or the changes, the big changes—we call that matrescence and I've used that word in this place a number of times—can have on your identity and your wellbeing. So I just wanted to again raise awareness.

Maternal mental health is serious. There are all sorts of ways in which your mental health is impacted. I personally have been impacted by poor mental health during my journey, whether that's through intrusive thoughts or anxiety. So I just really wanted to share it's okay not to feel okay but, more importantly, you don't have to think, am I sick enough to get help. Just reach out, whether that's through your formal support or your informal support network, that really can make a huge difference.

I also, on that note, just want to reflect on Mother's Day and previously, the week before, was actually Bereaved Mother's Day as well. That day can bring up a whole lot of feelings for a whole lot of people, Mother's Day itself and it is really important to acknowledge Bereaved Mother's Day because if you're not holding your baby in your arms, you are still a mother. I want to really acknowledge that, because that is quite painful for a lot of people. Of course Mother's Day itself, it's a day to acknowledge—I feel really quite conflicted about using the word Chair:

|                       | celebrate sometimes, because as mums we want to be celebrated but also, at the  same time, walk alongside people who might be grieving the loss of a child, the  loss of their mum or the absence of a mother figure in their life. So it is a really  important one to shout out all the things that mums do, they’re amazing, but it is  complicated. It’s absolutely complicated.  Lastly, I just want to make some reflections upon this place. I mean, on the topic  of mental health, my mental health is never better when I spend time away from  this place, because it is just so dysfunctional. That is a real shame, honestly. There  needs to be some sort of reformation in the way that this place functions and I do  think that that starts with consistent enforcement of Meeting Local Law and the  rules in this place. We should be striving for so much better. That really does come    |
|-----------------------|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Chair:                | Further speakers?                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              |
|                       | Councillor DIXON.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              |
| Councillor DIXON:     | Chair, I wish to rise on 2 items of General Business, Small Business Month and  Queensland Day. May is Small and Family Business Month and as a way to  support businesses in my local area, I team up with the local State MP,  Tim Nicholls and we run a Shop Local campaign, like an old-fashioned voucher  system; businesses put forward a deal and residents can go and support them. So  we’ve had some regulars that have come back on board, such as Grazing Italians  and Jocelyn’s Provisions who, by the way, celebrated 30 years being in business  a few weeks ago, so well done to Jocelyn’s. But we’ve also had some new  additions, such as Studio Pilates and Settebello’s, which is amazing pizza.                                                                                                                                                                                          |
|                       | I just want to say a thank you to all the businesses that have participated and to all  the residents that have already grabbed vouchers from our offices. Also, just a big  thank you to each and every small and family business in the Hamilton Ward who  get up every day, back themselves, put themselves out there and see risk as an  opportunity. So I have been using the vouchers this month and getting lots of  positive feedback. So I just want to encourage you all to shop local for the month  of May and also beyond that.                                                                                                                                                                                                                                                                                                                                                                   |
|                       | The second item of General Business that I have is Queensland Day, which is on  6 June; a great day to celebrate a great State. Now, we will be celebrating in the  Hamilton Ward with a family fun day to bring the community together, but I want  to highlight something else that is great about Queensland Day. It is the chance  for the community to nominate best of. In the Hamilton Ward, there’s actually a  couple of contenders at the moment that are high up in the ranks of best of. So  some of you may have heard me talk about Charlie Parrella before, the barber in  Hendra, barber to the stars. He is now running for best of barbers and he’s actually  in the top 3. So here’s hoping we can get him over the line, so I encourage  everyone to get on and vote for Charlie. Also, 4 Pines at Brisbane Airport is also  in the running for best of pub.                               |
|                       | So I just want to place on the record, I love Queensland, I love Brisbane and who  would want to be anywhere else? Thank you, Chair.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           |
| Chair:                | Further speakers?                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              |
|                       | Councillor CHONG WAH.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          |
| Councillor CHONG WAH: | Thank you, Chair. I rise on the petitions, 12 petitions, pedestrian safety petitions  and unfortunately, again, because of the Local Law, our debate was cut and I think  this is actually important to raise. So I rise to speak on Infrastructure Committee  Report regarding all 12 pedestrian safety infrastructure petitions. These petitions  are signed by over 1,700 residents, with some duplication. There are over  1,000 voices calling for this LNP Council to make streets safer to walk.                                                                                                                                                                                                                                                                                                                                                                                                        |
|                       | One with 34 signatures calls for the pedestrian crossing or traffic signal upgrade  so that Moreton Bay College students aren’t forced to sprint across to a refuge  between truck traffic. Another with 224 signatures calls for this Council to build                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        |

Councillor WOLFF:

footpaths on ordinary streets, something that should be this Council's bread and butter. Another, with a massive 727 signatures, calls for this Council to make a pedestrian crossing safer after a child was hospitalised by a car.

Astoundingly, in response to these 12 petitions, the LNP Administration won't fund a single one of those. This is truly shameful when you consider the near misses, injuries and fatal accidents that have occurred across our city over the years. This is a same Administration whose LORD MAYOR called traffic lights and pedestrian crossings downgrades. At the last election, to fix the exact safety problems that the petitioners have raised, the Greens ran on building 200 new pedestrian crossings, 200 kilometres of footpath and 100 new traffic calming upgrades across the city in 4 years, all funded through diverting money from the road and intersection widening. That's what it means to make streets safe. It means building infrastructure that protects people when they walk of all ages and abilities.

We have an LNP Administration that doesn't care about pedestrian safety. This Administration is wedded to car traffic, that they will keep on funding road widenings, which will induce more traffic while underfunding any alternatives. About one in 6 car trips in Brisbane is under 2 kilometres and another one in 5 car trips are between 2 and 4 kilometres. That means thousands of car trips could become a walk or a short bike ride if people felt like it was safe and convenient. If thousands of trips aren't taken by cars, then the people who can't avoid driving won't be caught in so much traffic congestion. It's pretty simple.

If you fund car infrastructure, everyone gets caught in car traffic. Everyone is less safe and more pedestrians get hurt. However, if you fund the alternatives like these petitioners are calling for, it's better for everyone. If you fund crossings, footpaths and traffic calming, more people can walk safely. If you fund bikeways, then more people can cycle. Every time someone walks or cycles, there is one less car causing congestion on the road. We need to rebuild streets for people.

Further speakers?

Councillor WOLFF.

Thank you very much, Madam Chair, and I rise to speak broadly on 2 items. Firstly, broadly, community events and secondly, cultural events. How wonderful has it been to be out and about in our wards during the recess period, hasn't it just been fantastic? I've certainly enjoyed it. It's been wonderful to support and celebrate numerous community events and activities over this recess. A highlight for me has been visiting many schools and community clubs and groups. Fig Tree Pocket State School, I had the pleasure of attending their school disco and awarding the best dressed in the disco and also their National Ride2School Day, which was fantastic to see so many young children proudly decorating their bikes and scooters and getting into active and healthy travel to school.

We also hosted a movie in the park for Easter, which was wonderful. I'd just like to give a shout out to Ray White Indooroopilly for their support and their involvement with the old -school Easter bonnet parade. So wholesome and so amazing to see all the students decorating their bonnets.

Also, not forgetting, in the past weeks, many of us attended numerous Anzac Day services and I just wanted to give a shout out to my local schools and also Toowong RSL (Returned and Services League) and Sherwood Indooroopilly RSL for their commitment to these days. It's really important that we remember the service and sacrifice of our veterans and the importance of passing those stories on to our younger generations.

As well, I was delighted to attend Indooroopilly Men's Shed and Indooroopilly Activity Hub did a united soiree for the first time. They've come together and created a beautiful soiree with a celebration attached. These 2 groups are side by side in Keating Park but have never before come together to celebrate. So it was lovely to see the 2 unite and have a celebration together.

Also in our community, we are enriched with incredible cultural diversity and that means that we also get to celebrate with these cultural groups. During the recess, Chair:

Councillor MASSEY:

I attended the vibrant Nowruz celebration on Queen Street Mall, which marked the Persian New Year. I also attended with Councillor HUTTON and we had a great time at the Festival of Chariots, the Ratha Yatra, which is hosted by ISKCON (International Society for Krishna Consciousness) Brisbane. Huge shout out to them. It was an incredible, happy celebration, so many happy people all in one place celebrating.

Not forgetting the Brisbane Bubble Tea. I know many of us were there. That festival was also a highlight. Thank you for all who joined me with that. Thank you to Dana and the organisers for the first-ever Brisbane Bubble Tea Festival. It was wonderful. I also attended the Holocaust Remembrance Day at the University of Queensland, which was an important opportunity to reflect, remember and reaffirm our collective responsibility to stand against hatred, discrimination and anti -Semitism.

These events are all community-based. This is what being a Councillor is all about. It's the work of everyone in our community putting these activities together that make being a Councillor an absolute joy and I just want to thank everybody for the great times that were had during recess, so thank you.

## Further speakers?

## Councillor MASSEY.

Thanks, Chair. I rise to speak on 4 items, The first 2 being 2 events, the QENDO (Queensland Endometriosis) Long Lunch, the West End State School Disco, the third one is reflections on today's meeting and then I'm going to roll that into pedestrian safety upgrades.

So, firstly, I did want to thank QENDO and their team, Jess, the CEO, for their invite again to the QENDO Long Lunch. QENDO isn't just about endometriosis, which affects one in 6 women in Queensland, one in 10 in Australia, noting that it is on average of a decade before women that experience this very painful and challenging illness are able to be diagnosed because of the patriarchy of the healthcare system. I just want to acknowledge everyone that was there and I want to acknowledge the facilitators and the organisations.

The thing that I can say about it is that there is probably maybe only a week or 2 that goes past where I don't have a conversation with someone where I eventually say, hey maybe you've got something else, have you thought about it? The tools in relation to pelvic pain, endometriosis and other pain in that area, the tools to be able to have those conversations were given to me by connecting with QENDO and I have been connecting with them for over 3 years. So I highly suggest everyone goes to the Long Lunch next week and I thank the organisation.

West End State School also this weekend had a disco. It's called a disco but when I arrived, it was actually a full-on fair. So I want to always give the shout out to not only West End School but also the Parent and Citizens Association and all the volunteers that make it happen. When I talk about a fete and a fare, I'm talking there were thousands of people there. It takes a lot of effort to put things like this on and the West End State School community and the West End community is very strong and very connected. I thank them for their invitation, always welcoming me and being a part of it.

Reflections on today, I just wanted to say there were moments today where— firstly, I'm going to say, I'm going to put it on the record, Councillor KIM, through you, Chair, I understood what you were saying. I understood your comparison, because there is — and to use the terms of potentially the Liberal Party might understand, there's opportunity costs when you leave. That is, a Neoliberal, that is a classical economic term, when you are doing something else, there is an opportunity cost. When the LORD MAYOR is not in the city, that opportunity cost is Brisbane.

So I do recognise that there was amazing parts in today's meeting where we should have the right, as Opposition Councillors, any Councillor, to question decisions that are made here in the Chambers. But there is always very clearly a refusal for that to happen, which brings me to pedestrian safety. I want to thank Councillor Chair:

Councillor GRIFFITHS:

Chair:

Councillor GRIFFITHS:

Chair:

Councillor GRIFFITHS:

Councillor interjects.

Councillor GRIFFTHS:

CHONG WAH for bringing that up, because we didn't get to speak to the 17, I believe, petitions that were on the agenda.

Often in here, Opposition Councillors can be told that they don't want to talk about local issues, but the most clear local issues are the ones that residents, or even local Councillors, petition for. These are the issues that we are fighting for and what residents are fighting for across the city. Because of the structure now of these meetings, there is rarely a chance outside of General Business. That is the shame, because there were 11 — 12 pedestrian safety petitions today. These are residents. This is asking us to consider because people do not want to get hurt.

If Brisbane City Council's main—if we are here to serve, not rule, then we should be serving our communities by ensuring that these voices are heard and considered, because budgets are choices. We're going to be at a budget very soon and we will see the choices that the LNP Administration makes and whether it prioritises people or not. Knowing what the LORD MAYOR said, that pedestrian safety is downgrades, I don't have much faith in this Council.

Further speakers in General Business.

Yes.

Just one moment, Councillor.

Councillor GRIFFITHS.

Thank you, Madam Chair, and I understand you going side-to-side was making sure you saw me.

Yes.

I'd just like to speak about 2 things, today's meeting and also the changes to SEF funding. Firstly, my observation in relation to today's meeting is leadership is set at the top and I think it says it all, when we look at the middle of the room today and the MAYOR isn't here. The MAYOR of our city, who was elected by the majority of residents is not here in this Chamber. The MAYOR of this city has been on 5 international trips since he was elected. Most of his chairpersons have been on international trips and this Council is just getting into a worse and worse state with delivery on the ground. I can compare it from how it was 23 years ago to now and it is appalling. It is at its worst point and the Chamber I've never seen function in a more aggressive, nasty and I'd say bullying way. So that's my observation of today's meeting.

I want to speak about SEF funding. It was nice to get a compliment from the MAYOR, because a few weeks ago, before we went onto break, I brought in 2 possum boxes and it was a bit of a laugh, but for Council to put up those 2 possum boxes and provide them as $10,000 and I went to a Men's Shed and was able to get those 2 possum boxes for $50. Interestingly, staff have told me there was no cost to put up those possum boxes and today the LORD MAYOR says there's a $425 cost. So I'm chasing that up with the CEO, because I want to know why the discrepancy in the information I'm being given.

In relation to — I just want to talk about our SEF funding and this, for me, is the appalling management by the LORD MAYOR and the LNP Councillors who've been here for 23 years, which I think—and residents think—is way too long. I think this Council has become tired, bitter and out of ideas. All you've got to do is watch one of these meetings. But let me give you some examples from my ward of how money is being spent or not spent. I've now been waiting—residents have now been waiting 2 years for a tap in a park at a cost of $44,000. So paying $44,000, which I think is obscene and then waiting 2 years for this tap to be connected. Councillor MURPHY, that's not good.

Trees in a park, now I object to having to pay to plant trees in a park. I got charged $38,000 for that. I don't think there are any Liberal Councillors that get charged to plant trees in a park. When I've asked that question before, no one's answered. We collect $21 million a year to plant trees and yet I have to pay for them. Well, it has now been 2 years I've been waiting for these trees to be planted and just the Chair:

Councillor GRIFFITHS:

Chair:

Councillor interjecting.

Chair:

Councillor STRUNK:

other day I get a call from the officer going, oh the plan's wrong. The plan that we quoted you for is wrong. Do you understand what's going on in this Council if they can't even get a plan that they give you in the first place right?

I think the performance in Council the moment is shocking—shocking. I know that on this site, I've had 12 staff, a number of executives, go out and look at this site and go, oh that's shocking—and we still can't get it done. Is this General Business or is this how we do business for Labor Councillors and we have a different performance standard for Liberal Councillors? What executives tell me—and I'll give you some words they tell me—is, 'we work for the majority,' the majority being the LNP. This is executives. Or: 'pay more, you get more, Councillor, which is how we deliver.'

Or the best one is, 'Councillor, a lot of the work in your ward, that's on the never-to -do list. That is on the never -to -do list.' That executive who said that has just gone from a Project Officer to an executive under an LNP Council after cutting a building in half—wow—for a developer. I just find the way this Council is running and yes, Councillor MURPHY—

Councillor GRIFFITHS, your time has expired.

Appalling.

Are there any further speakers—

— for General Business?

Councillor STRUNK.

Thank you, Chair. Listen, I rise to speak on a couple of events that have happened since we were last in the Chamber and also one petition. I'll start with the petition first. The community came to me shortly after one of our most beloved Indigenous leaders, Albert Holt, passed away in his 80s. They said, 'well, can we do something to commemorate his memory?' I said, well, as a Councillor, I haven't actually facilitated a naming of a park. They said, 'well, can we pick the park?' I thought I knew which park that they would like to pick—and then start a petition, by the way, which they've done—and that's Thrush Street Park, which is just in the middle of Inala, actually.

It's a meeting place for a lot of our Indigenous community. So I said, yes, we'll throw it up in an ePetition and a paper petition and do all that. It's on Facebook, we put it up on Facebook and it was shared, I think, 57 times. So you can imagine how many views it's had. But I just wanted to put it out there that when we do name parks, it's really got to be named after people that really have done a terrific job for the community. Most of the parks that are named in my ward are those community people, right, that have done an unbelievable job in the community for years and years and years.

Okay, as far as events go, I've never been to the commemoration of the Battle of the Coral Sea at Newstead Park and I went off there on Saturday and was very impressed with what the Australian American Association have done for many, many years. Now, I don't know if they've done it for all 79 years, but certainly from what I saw and from what I heard, they've obviously done it for a number of years. Councillor DIXON was there, Minister Nicholls was there, former Senator Claire Moore was there and myself and one of my team members was there as well.

I didn't really understand Coral Sea and the implications of the battle not going our way and what could have happened if we had had—it was a bit of a tie as far as between the Japanese and the Americans, right, but it stopped the invasion of Port Moresby by the Japanese and consequently, of course, the supply lines into Australia were not broken. Of course, the cenotaph or the monument that's there, they said, is quite a special one, Very Romanesque looking, right and if you haven't actually seen it, if you've never seen it, have a look, because it's really quite a special type of space just on the river there, actually. Of course the CityCats are running up and down. It was a really great day, great weather as well.

Chair:

Councillor MURPHY:

Then finally, Anzac Day, the RSL subbranch for Forest Lake and Darra do a terrific job in my ward and I'm sure they do it in the Jamboree Ward as well, to facilitate the connection with the schools, to help them actually structure a commemorative day as well, before Anzac Day and then some do it after as well. But I just want to pay tribute to them, because it was a fantastic—I've got 13 schools in my ward and I'm pretty sure all 13 actually held a ceremony. I couldn't get to every one of them, of course, but they all contribute to remember the Anzacs. I really just want to pay tribute to the sub-branches, as well as the schools, for doing that, for ongoing and doing that. For all the years that I've been a Councillor, they've always done that and I'm sure it was years before as well. Thank you, Chair.

Further speakers? No further speakers? That now—

Sorry, Councillor MURPHY, got to be quick or I'll finish.

Councillor MURPHY.

Yes, thanks very much, Madam Chair. Just rise quickly to speak about the Infrastructure Committee Report here in General Business, because unfortunately we didn't get to it. I think it's sad we didn't get to it, because it was a record. I think 12 petitions through and in the recess, many of which were of interest to Councillors here in this place, covering the width and breadth of our great City of Brisbane. I won't speak to any of the petitions specifically. Each petition is grounded in its local issues and the community concerns there. Councillors will note, though, that the responses are very much grounded in logic and reasoning. We always consider what is best for the city. We don't try to play political games with these petitions.

Across all of these petitions, whether they relate to Suburban Enhancement Fund projects, crossings near schools, arterial roads like Logan Road or basically neighbourhood streets, Madam Chair, what you would see reading through the petition responses is that safety is the core priority of all of them. Every location is assessed against engineering standards, the road hierarchy classification and our observations, whether those are sometimes, as they have to be, desktop observations of whether we've actually gone out there and physically surveyed the site, spoken to people, so on and so forth.

Where existing infrastructure is already meeting safety expectations, which is then supported by crash data or traffic surveys, we have used clear and evidence-based responses in these petition responses. I think it was mentioned by one of the Opposition Councillors before, I think Councillor CHONG WAH, that we haven't done anything in terms of responding to any single one of the petitions, which is patently untrue if you read the responses. There are many responses where we are taking action or we have already taken action and there are other responses where we've actually agreed with what the petitioners have asked us to do, but we have said this is subject to future funding and budget prioritisation.

As we all do individually in our own wards through SEF, the $16 million that's allocated across all of our wards every year, we choose what our priority projects are, where we think the funding is necessary to go. It's in that vein that we are delivering simpler SEF and I wanted to talk about that as well just briefly, Madam Chair. It came at a great time, the possum boxes issue, because we had just completed our review of the SEF program. What we found was a lot of challenges there affecting design time, value for money, the cost recovery model and financial predictability for SEF projects.

I think it was a bit of a watershed moment, because we said, yes, you know what, Councillor GRIFFITHS actually has a point. I'm very happy, Madam Chair, to share in the glory with Councillor GRIFFITHS here. We can call these the GRIFFITHS guidelines that are coming through, because SEF is changing. We are moving from this difficult-to-understand, cost-recovery model to a direct-cost model, where the predictability, the repeatability, the standardisation of SEF projects will be a lot easier for Councillors to understand, for Ward Officers to access and to track as they go on. We don't want to see projects that take years to design that are simple. We don't want to see projects that are for a footpath that Chair:

Councillor CASSIDY:

ends up doing driveway reconstruction and landscaping and lighting and signage and a million other things that are extra, over and above what the footpath is. We want to see more of that money spent delivering for the residents of Brisbane and less of it being sucked up in back-office costs.

So that is what the first stage of simpler SEF is about and there are more stages coming. Councillors will see that as it comes through in the budget process. So I want to thank all Councillors on both sides of this Chamber who have provided direct and sometimes very frank feedback to their outcome managers or the leadership hierarchy within Infrastructure Services Group. We have heard loud and clear that you want to be spending less time chasing up these projects and finding out what their status is and more time actually delivering them, consulting with your communities, doing the work on the ground and that we also need to have costs that are robust and defendable in the public arena because, as has been said by multiple Councillors on both sides of the aisle today, this is public money, we are spending public money and we need to be able to justify that to the public.

So I think one thing we can all agree on, that some of the things that were happening in SEF no one actually had agreed to and we are winding those back and we are making SEF simpler, more easy to understand for all Councillors. So thanks to those Councillors who contributed to the process.

Councillor MURPHY, your time has expired.

Any further speakers?

Councillor CASSIDY.

Yes, thanks very much, Chair. I just rise to speak on a petition that was in the Infrastructure Committee today and unfortunately, we didn't get to debate because the LNP changed the rules of this place and restricted the time for Councillors to be able to debate these things. The petition was from residents calling on Council to improve the safety of the pedestrian crossing on Logan Road near Glindemann Park, a really important petition.

On 21 November last year, a 12-year-old boy was hit by a driver while crossing Logan Road near Glindemann Park. He crossed cautiously with his friend, waited for traffic to stop. A driver changed lanes to overtake the stopped vehicle and drove straight through the marked crossing, striking him at speed. He was knocked unconscious and suffered a fractured arm, facial injuries and a concussion. That was Hugo. I met Hugo and his dad, Jody, alongside Joe Kelly, the State Member for Greenslopes, at the site where this occurred—and Kate who started the petition as well. Five months have passed since then. We see this petition come through in the recess period, a response rubber stamped by the E&amp;C Committee, by Civic Cabinet, with no debate to occur in that Committee or subsequently here in the Council Chamber. So that's 5 months ago, Chair.

Now, locals to that area have known for a very long time that that pedestrian crossing was very dangerous. In fact, Council knew for a very long time, when Councillor Cooper was the Chair of the Infrastructure Committee, that was identified as a crossing which did not meet guidelines by this Council. But what did they do? What did they do? Well, here's just one example which is 10 months ago, so some 5 months before Hugo was hit by that car and almost killed. This is a post by a local: "If anyone is living in Holland Park and uses the pedestrian crossing at Logan Road near Glindemann Park, you'll know how dangerous it is to cross 4 lanes of traffic with your visibility inhibited by road design and shrubs. A lady and her daughter had 10-plus cars zoom past. Eventually the outer traffic stopped, but as she crossed the inner lane, the traffic kept blowing past and then experienced the exact same thing crossing in the opposite direction. There was a flashing light a few years back, but that was hit by a car and not replaced. It gives you an idea of the safety of the area. I've experienced this too many times."

Some of the responses really to that post, 10 months ago, are really quite instructive. Somebody said: "I've also reported it to Council today"—this is 10 months ago—"my wife reported it about a year ago to Krista ADAMS after a car was rear-ended while I was crossing. Her response was essentially"—and this is the quote—"nothing I can do, not a priority, might put up some more signage."

Councillor interjecting.

Councillor CASSIDY:

Chair:

So just last week, this is 10 months ago, this person was crossing with their newborn in a pram. The exact situation that was mentioned in that previous post above happened to this person. They say if they weren't already aware of those issues there and the danger at that crossing, that mother and child might be dead.

Lots of people go on to say they've had the exact same experience in reporting it to Council and reporting it to Councillor Krista ADAMS and having the exact same response. So then we're shocked to see in the response all years and years and years later in this petition, it's a significant petition, with a huge amount of community support, to say that Council does agree that there is a significant problem at this intersection. They're going to have to do some reviews on site and recommend some changes there. But I guess the question that those people are asking themselves, those people who have reported it 5 months before this near fatality, people who have reported it for years and years before and know that Council identified this as a dangerous pedestrian crossing, that they'll still have to wait and they will still have to approach a Councillor who they would expect to advocate for funding to the LORD MAYOR—

— and they will find out that that's not going to be the case, that that local Councillor has checked out, has largely left the job and won't be advocating for that community over the next few years.

People often say, what will it take? What will it take for this to be upgraded, somebody to die there? Well, somebody almost did 5 months ago, a 12-year-old boy, Hugo. We've heard these stories from mothers and babies who have almost died at this intersection. For that LNP Council to throw their hands up in the air, who was the Deputy Mayor of Brisbane at the time when all these requests were made and say, apparently there's nothing that Councillor Krista ADAMS could do, because the LORD MAYOR wouldn't allocate any funding to upgrade that crossing. What an incredible situation. What a deeply disappointing situation for that community.

It's just one of the stories we're hearing as we're spending more time out on the Holland Park Ward, whether it's about people who are being ignored about community consultation, whose lives are being put in danger through an action of that Councillor.

Councillor CASSIDY, your time has expired.

Are there any further speakers?

I now call the meeting closed.

## QUESTIONS OF WHICH DUE NOTICE HAS BEEN GIVEN

(Questions of which due notice has been given are printed as supplied and are not edited)

## Submitted by Councillor Jared Cassidy (received on 7 May 2026)

- Q1. Please advise the number of staff currently employed in each of the following groups, branches and sections of BCC:

|                                | Full  Time   | Part  Time   | Casual    | Contract Total  FTE   |
|--------------------------------|--------------|---------------|-----------|-----------------------|
| Public Transport Services      |              |               |           |                       |
| Commercial & Contract Services |              |               |           |                       |
| Engineering & Asset Management |              |               |           |                       |
| Strategy and Network Services  |              |               |           |                       |
| Transport Operations           |              |               |           |                       |
| Infrastructure Services        |              |               |           |                       |
| Asset Management               |              |               |           |                       |
| Transport Assets & Operations  |              |               |           |                       |
| Planning & Design              |              |               |           |                       |
| Project Management             |              |               |           |                       |
| Asphalt & Aggregates           |              |               |           |                       |

|                                                           | Full  Time   | Part  Time   | Casual    | Contract Total  FTE   |
|-----------------------------------------------------------|--------------|---------------|-----------|-----------------------|
| Construction                                              |              |               |           |                       |
| Public Space Operations                                   |              |               |           |                       |
| Safety Environment & Risk                                 |              |               |           |                       |
| Fleet Solutions                                           |              |               |           |                       |
| Strategy & Alignment                                      |              |               |           |                       |
| Environment, Parks and Sustainability  Services           |              |               |           |                       |
| Waste & Resource Recovery Services                        |              |               |           |                       |
| Natural Environment, Water &  Sustainability              |              |               |           |                       |
| City Resilience                                           |              |               |           |                       |
| City Planning and Economic  Development Services          |              |               |           |                       |
| City Planning & Design                                    |              |               |           |                       |
| Development Services                                      |              |               |           |                       |
| 2032 Host City, Global Relations &  Economic Partnerships |              |               |           |                       |
| Community and the Arts Services                           |              |               |           |                       |
| Arts & Community Development                              |              |               |           |                       |
| Sport & Recreation                                        |              |               |           |                       |
| Customer Services                                         |              |               |           |                       |
| Compliance & Regulatory Services                          |              |               |           |                       |
| Library & Customer Services                               |              |               |           |                       |
| Cemeteries                                                |              |               |           |                       |
| Services Portfolio & Business Innovation                  |              |               |           |                       |
| Community Experience                                      |              |               |           |                       |
| Corporate Services                                        |              |               |           |                       |
| Business Engagement & Performance                         |              |               |           |                       |
| Strategic Finance                                         |              |               |           |                       |
| Information Services                                      |              |               |           |                       |
| People & Culture                                          |              |               |           |                       |
| Corporate Property                                        |              |               |           |                       |
| Strategic Procurement                                     |              |               |           |                       |
| Support Services                                          |              |               |           |                       |
| Governance and Legal Services                             |              |               |           |                       |
| Assurance Services                                        |              |               |           |                       |
| City Communication                                        |              |               |           |                       |
| City Legal                                                |              |               |           |                       |
| Ethical Standards                                         |              |               |           |                       |
| Governance, Council & Committee Services                  |              |               |           |                       |
| Lord Mayor’s Administration &                             |              |               |           |                       |
| Engagement                                                |              |               |           |                       |

- Q2. How many total staff have ended employment with Brisbane City Council since 12 November 2024, including voluntary &amp; involuntary separation, contract completion or early termination by either party, etc? Please provide actual staff and FTE numbers.
- Q3. How many staff have voluntarily tendered resignation to Brisbane City Council since 12 November 2024? Please provide actual staff and FTE numbers.
- Q4. Please advise the total cost of the recent mural installation in the basement of City Hall (located in the private corridor en route to City Hall Parking), including any breakdown e.g. materials, consulting, artist labour etc?
- Q5. When did BCC formally change the Emma Street precinct LATM- Holland Park West from the original design proposal shared with residents in 2022, to the current design which only was provided to affected residents in March 2026 Construction Notice papers?

- Q6. Regarding Emma Street precinct LATM- Holland Park West, if BCC proceeds with the current proposal and does not undertake any further community requested consultation, when can affected residents expect the works to begin? It is noted that the BCC public website currently states "Works are scheduled from early April to late May 2026, subject to weather and site conditions. Hours are 9am to 2pm Monday to Friday, and 6.30am to 6.30pm on Saturdays". As this window is underway, can any further details be provided to residents?
- Q7. Please advise the total amount spent on Metro advertising of any kind during the month of April 2026. Please provide breakdown by channel.
- Q8. Please advise the total amount spent on Metro advertising of any kind during the month of January 2026. Please provide breakdown by channel.
- Q9. Please advise the total amount spent on Metro advertising of any kind during the month of October 2025. Please provide breakdown by channel.
- Q10. Please advise the total amount spent on Metro advertising of any kind during the month of July 2025. Please provide breakdown by channel.
- Q11. Please advise the average, shortest, and longest wait times for a BCC cemetery burial allotment in the 25/26 FY?
- Q12. Please advise the average, shortest, and longest wait times for a BCC cemetery burial allotment in the 23/24 FY?
- Q13. Please advise the average, shortest, and longest wait times for a BCC cemetery cremation allotment in the 25/26 FY?
- Q14. Please advise the average, shortest, and longest wait times for a BCC cemetery cremation allotment in the 23/24 FY?
- Q15. Please confirm the current number of pickleball locations in Brisbane, including their locations.
- Q16. Please advise where on the BCC Public website the public can access a list of pickleball locations?
- Q17. In a July 11, 2023, press release, the Lord Mayor &amp; Cr. Adams highlighted the popularity, fitness benefits and low cost of access when announcing 4 new pickleball courts being installed, on location at the then -recently opened Joachim Street Park courts, bringing the total courts BCC had installed to 8. Cr. Adams noted the importance of convenient local access to low cost sport options. Please advise why the decision to renew the existing pickleball courts in Joachim St Park has been made in favour of expanding BCC's pickleball court access to suburbs without convenient local access?
- Q18. Following from the previous question, please advise the business reasoning to decline the local community's request for consultation prior to renewing these courts, to ensure concerns surrounding noise, light pollution and increased people and vehicle traffic to the area?
- Q19. In relation to the expansion of the existing Joachim St Park pickleball courts, if BCC proceeds with the current proposal and does not undertake any of the community requested consultation, when can affected residents expect the works to begin?
- Q20. Regarding the proposed pickleball courts installation at Cox Park, Lota – given the 4.6km distance to the nearest BCC provided pickleball location, please advise why the decision to replace these hard courts with pickleball courts has been made in favour of expanding BCC's pickleball court access to suburbs without convenient local access?
- Q21. Following from the previous question, please advise the business reasoning to decline the local community's request for consultation prior to renewing these courts, to ensure concerns surrounding the existing use of the courts, noise, light pollution and increased people and vehicle traffic to the area are addressed?
- Q22. In relation to the installation of pickleball courts at Cox Park if BCC proceeds with the current proposal and does not undertake any of the community requested consultation, when can affected residents expect the works to begin?

- Q23. Provide the total amount of revenue from e-mobility providers for the financial year 2023-2024.
- Q24. Provide the total amount of revenue from e-mobility providers for the financial year 2024-2025.
- Q25. Provide the total amount of revenue from e-mobility providers for the financial year 2025-2026 YTD.

RISING OF COUNCIL:

6.27pm.

PRESENTED:

19 MAY 2026

and CONFIRMED

<!-- image -->

Based on the image provided, here is a description:

The image displays a signature that reads **"Sandy Landers"**. The text is written in a cursive, handwritten style with a light blue, slightly faded or sketched appearance. Beneath the signature is a solid, dark grey horizontal line.

There are no project names, budget figures, locations, procurement indicators, or council decisions visible in this image. It appears to be a personal signature or a signature logo.

CHAIR

## Council officers in attendance:

Victor Tan (Council and Committee Coordinator) Dorian Maruda (Senior Council and Committee Officer) Ethan Van Roo Douglas (Senior Policy Advisor to the Chair of Council) Billy Peers (Personal Support Officer to the Lord Mayor and Council Orderly)